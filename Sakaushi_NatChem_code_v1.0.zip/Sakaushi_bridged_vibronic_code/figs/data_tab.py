"""Tabulated numbers used in Figs 3 and 4 (no model is evaluated here).
Tags: [fit] = fitted, [model] = model calculation, [arith] = arithmetic.
"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import json as _json
import numpy as np

# 2026-09-29 (Ken): every number shown in the figures must agree with the manuscript (v6.3). Hence:
#   K = k_H/k_D with the donor concentration ratio (doc 57 item E, doc 61) in Figs 2a, 2b, 3d and 4b;
#   Fig. 4c/4d acid values: doc 59 refit with the 0.05 M D2SO4 data (manuscript v6.4, item D3, Ken 2026-09-29;
#   before: doc 47/49, kept in data_tab_before_D.py);
#   bridged Delta alpha at lambda 0.3 eV = +0.1066 (doc 47, manuscript +0.107); MHC-alone rms from the unrounded fit.

# ---- measured local apparent transfer coefficients [fit; doc 26, 27, 34]
OBS = {
    ("H", "alk"): ([0.29, 0.33, 0.37, 0.41, 0.45], [0.592, 0.583, 0.587, 0.604, 0.624]),
    ("D", "alk"): ([0.28, 0.32, 0.40, 0.44, 0.48, 0.52, 0.56], [0.464, 0.475, 0.472, 0.466, 0.437, 0.412, 0.386]),
    ("H", "acid"): ([0.09, 0.11, 0.13, 0.15, 0.17, 0.19, 0.21, 0.23, 0.25, 0.27],
                    [0.789, 0.753, 0.690, 0.620, 0.548, 0.491, 0.442, 0.413, 0.401, 0.397]),
    # acid D: 0.05 M D2SO4 file, 13 points 0.11-0.35 V (40 mV windows, back-reaction corrected) [fit; doc 58,
    # acidD_update.json]. Used by Fig. 3b from 2026-09-29; before: doc 34, 4 points 0.16-0.22 V
    # ([0.16, 0.18, 0.20, 0.22], [0.730, 0.737, 0.730, 0.731]).
    ("D", "acid"): ([0.11, 0.13, 0.15, 0.17, 0.19, 0.21, 0.23, 0.25, 0.27, 0.29, 0.31, 0.33, 0.35],
                    [0.5842, 0.5552, 0.6851, 0.7317, 0.7344, 0.7329, 0.752, 0.805, 0.7921, 0.6609, 0.5067, 0.4011,
                     0.3502]),
}
# measured alkaline log (j_H/j_D) at equal overpotential (H vs RHE, D vs RDeE) [arith; doc 27]
# 0.25 V added 2026-09-30 (Ken: KIE from the lowest possible overpotential; the D file starts at 0.2496 V)
# [arith; H and D files, linear interpolation at equal |eta|]
# 2026-10-01 (Ken): both instrumental steps removed, choice A (lower-current segment shifted onto the higher-current
# segment): H +0.02298 dec below 0.25944 V, D +0.05689 dec below 0.36944 V [fit; work/stepA/corrA.py].
# As recorded: [1.119, 1.261, 1.328, 1.369, 1.494, 1.576]
KIE_ALK = ([0.25, 0.30, 0.35, 0.40, 0.45, 0.479], [1.085, 1.204, 1.272, 1.369, 1.494, 1.576])
# instrumental steps in the alkaline log j (|eta| of the first point above the step, height in decades): straight line
# + step fitted over the common window 0.24956-0.47856 V [fit; work/stepA/steps_window.json, doc 70 method].
# Choice A (Ken, 2026-10-01): points below the step are raised by the height (used for plotting in Fig. 2).
STEPS_ALK = {"H": (0.259436010599, 0.022978333986358436), "D": (0.36944, 0.0568885166466749)}
# K = k_H/k_D with the donor concentration ratio [arith; work/conc/k_fig.py -> k_fig.json]
#   acid: c_D/c_H = 0.895 (central factor K/R 0.8956-0.8968); alkali: KOD 98 % D (97-99 %: log K within +-0.0014)
_KF = _json.load(open(_PKG + '/figs/k_fig.json'))
KACID = (_KF['acid']['eta'], _KF['acid']['logK'])
KALK = (_KF['alk']['eta'], _KF['alk']['KOD98']['logK'])
K1_CROSS_ACID = _KF['acid']['K1_cross']      # K = 1 at 0.2485 V
# 2026-09-30 (Ken): alkaline common window matched to the D file, 0.2496-0.4786 V (was 0.30-0.479 V: 0.100, 0.125)
# 2026-10-01 (Ken): the paper uses the data with both instrumental steps removed: +0.1263 (as recorded +0.1052,
# D step only removed +0.1274) [fit; steps_window.json, corrA.json]
DALPHA_ALK_MEAS = 0.126   # common window 0.24956-0.47856 V, both steps removed
DALPHA_ACID_MEAS = -0.20           # [fit; doc 34]

# ---- bond-stretching (B-M, WKB through the O-H/Au-H crossing) at the measured eta [fit+model; doc 42, fit_bm.log]
BM = {
    "alk": dict(dE0=0.242, d=0.72, rms=0.119,
                H=[0.60, 0.51, 0.47, 0.45, 0.42], D=[0.64, 0.61, 0.56, 0.54, 0.52, 0.50, 0.48]),
    # acid: refit 2026-09-29 with the 13 alpha_D points, same procedure as doc 42 [fit+model; fit3b_bm.json]
    #   (doc 42 with 4 alpha_D points: dE0 0.129 eV, d 0.65 A, rms 0.083)
    "acid": dict(dE0=0.1230, d=0.762, rms=0.1106, rmsH=0.0630, rmsD=0.1364,
                 H=[0.732, 0.718, 0.674, 0.686, 0.566, 0.540, 0.520, 0.503, 0.488, 0.474],
                 D=[0.659, 0.649, 0.645, 0.628, 0.618, 0.608, 0.599, 0.590, 0.580, 0.572, 0.562, 0.553, 0.544]),
}
# ---- MHC kernel alone, single configuration (semiclassical; isotope offset fitted) [fit+model; doc 42 row 1, logM0]
MHC = {
    # rms: from the unrounded per-series rms of fit3b_mhc.json (H 0.02727, D 0.02434) -> 0.0256 (manuscript 0.026)
    "alk": dict(lam=0.257, f0=0.614, dG0=0.638, dD=-0.200, rmsH=0.027, rmsD=0.024, rms=0.02561,
                H=[0.60, 0.59, 0.59, 0.58, 0.57], D=[0.52, 0.50, 0.47, 0.45, 0.43, 0.41, 0.39]),
    # acid: refit 2026-09-29 with the 13 alpha_D points, same procedure as doc 42 M0 [fit+model; fit3b_mhc.json]
    #   (doc 42 with 4 alpha_D points: lam 0.100 (bound), f0 0.939, dG0 0.203, dD +0.088, rms H 0.035, D 0.042)
    "acid": dict(lam=0.100, f0=0.795, dG0=0.217, dD=+0.105, rmsH=0.0617, rmsD=0.1200, rms=0.09894,
                 H=[0.677, 0.653, 0.626, 0.598, 0.568, 0.537, 0.504, 0.471, 0.437, 0.402],
                 D=[0.766, 0.756, 0.743, 0.728, 0.710, 0.690, 0.667, 0.642, 0.615, 0.586, 0.555, 0.523, 0.490]),
}

# ---- lambda profiles, alkaline [fit; doc 47 (3a, 3b), doc 50 table 1 (bridged, omega 2600, delta_D 27.97 meV)]
LAM_GRID = [0.05, 0.075, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.7, 1.0, 1.5, 2.0]
RMS_3A_ALK = [0.030, 0.033, 0.036, 0.042, 0.046, 0.053, 0.057, 0.060, 0.061, 0.063, 0.066, 0.069]
BND_3A_ALK = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1]      # 1 = a parameter at its bound
RMS_3B_ALK = [0.053, 0.052, 0.052, 0.055, 0.058, 0.063, 0.066, 0.068, 0.070, 0.073, 0.075, 0.076]
BND_3B_ALK = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1]
BR_LAM = [0.1, 0.2, 0.3, 0.5, 0.7, 1.0]
BR_RMS_HD = [(0.030, 0.034), (0.029, 0.038), (0.032, 0.042), (0.037, 0.046), (0.041, 0.049), (0.045, 0.053)]
# window 0.2496-0.4786 V, log K at 0.25 and 0.479 V (2026-09-30): 0.3 eV = doc 47 fit re-evaluated [model];
# other lambda: doc 50 table 1 refitted (same optimum: rms, Delta alpha and log K of doc 50 reproduced) [fit;
# work/winD/recalc_winD.json]. Before (0.30-0.48 V, doc 50): 0.142, 0.118, 0.1066, 0.095, 0.089, 0.083;
# log K (1.26, 1.67), (1.35, 1.70), (1.39, 1.71), (1.41, 1.70), (1.41, 1.68), (1.41, 1.66)
BR_DALPHA = [0.1279, 0.1124, 0.1047, 0.0950, 0.0888, 0.0827]
BR_LOGK = [(1.21, 1.67), (1.28, 1.70), (1.31, 1.71), (1.33, 1.70), (1.34, 1.68), (1.34, 1.66)]


def rms_comb(rh, rd, nh=5, nd=7):
    """combined alkaline rms from H and D rms [arith]"""
    return float(np.sqrt((nh * rh ** 2 + nd * rd ** 2) / (nh + nd)))


BR_RMS = [rms_comb(h, d) for h, d in BR_RMS_HD]

# Delta alpha over the common window 0.2496-0.4786 V and log K at 0.25 and 0.479 V, alkaline: doc 47 fits
# re-evaluated (2026-09-30) [model; recalc_winD.json]. Before (0.30-0.48 V): DA_3A 0.050, 0.034, 0.026, 0.019;
# DA_3B 0.027, 0.015, 0.007; FREE_3A 0.130, (2.13, 2.51); FREE_3B 0.088, (0.97, 1.22); BRIDGED_03 0.107, (1.39, 1.71)
DA_3A = dict(lam=[0.3, 0.5, 0.7, 1.0], val=[0.049, 0.034, 0.026, 0.019])   # 0.7, 1.0: interior solutions (d* <= 1.0 A)
DA_3B = dict(lam=[0.3, 0.5, 1.0], val=[0.027, 0.016, 0.007])
FREE_3A = dict(lam=0.050, dalpha=0.126, rms=0.030, logK=(2.07, 2.51))      # lambda at lower bound
FREE_3B = dict(lam=0.088, dalpha=0.085, rms=0.052, logK=(0.93, 1.22))      # rms from doc 47 profile (0.050/0.053)
BRIDGED_03 = dict(lam=0.3, dalpha=0.105, logK=(1.31, 1.71), rmsH=0.032, rmsD=0.042)   # doc 47 (delta_D 28 meV)

# ---- Fig 4 -------------------------------------------------------------
# bridged model alpha at measured eta, alkaline, media-separate, lambda 0.3 eV, delta_D = 27.97 meV
# [fit+model; doc 47, results_47.json 'T4|base|alk': rms H 0.0322, D 0.0416, Delta alpha +0.1066]. Used in Fig. 4a
# from 2026-09-29.
BR_ALPHA_DOC47 = {"H": [0.5575, 0.5685, 0.5754, 0.5763, 0.5705],
                  "D": [0.4603, 0.4631, 0.4673, 0.4690, 0.4703, 0.4712, 0.4716]}
# before: delta_D = 16.2 meV (ZPE only) [fit+model; doc 45 sec. 3]
BR_ALPHA_DOC45 = {"H": [0.560, 0.571, 0.577, 0.578, 0.572], "D": [0.460, 0.462, 0.466, 0.468, 0.469, 0.470, 0.470]}
# d logK / d delta_D per meV at the window ends 0.25 and 0.479 V, from the doc 47 fits T1 at delta_D = 16.19 and
# 28.00 meV [arith; recalc_winD.json] (2026-09-30; before: 0.0132 at both ends, the value at 0.30 V)
KIE_SENS = (0.01345, 0.01256)
DELTA_D = 27.97        # meV
DELTA_RANGE = (0.0, 32.0)
# current-weighted distance <d> at window ends, delta_D 28 meV, media-separate, lambda 0.3 [model; doc 47]
# alkaline: window ends 0.25 and 0.479 V (2026-09-30, recalc_winD.json; before 0.30/0.48 V: H 0.589/0.642, D 0.498/0.543)
DMEAN = {
    ("H", "alk"): ((0.25, 0.479), (0.571, 0.642)),
    ("D", "alk"): ((0.25, 0.479), (0.485, 0.543)),
    # acid: doc 59 sec. 3, refit with the 0.05 M D2SO4 data (manuscript v6.4) [model]; window ends 0.12 and 0.248 V.
    #       before (doc 47, alpha_D 0.16-0.22 V): H 0.420 -> 0.406, D 0.350 -> 0.341
    ("H", "acid"): ((0.12, 0.248), (0.4175, 0.4003)),
    ("D", "acid"): ((0.12, 0.248), (0.3485, 0.3362)),
}
# acid Delta alpha decomposition (window 0.12-0.248 V), parameters fixed at the doc 59 refit with the 0.05 M D2SO4
# data [model; doc 59 sec. 3.1] = the manuscript v6.4 (paragraph 45: -0.060; 58 %, 26 %, remaining 17 %; 0.342 against
# 0.409 A). Percentages rounded one by one (57.7, 25.5, 4.8, 12.0 %), so they add to 101 %.
# Before (doc 47 base, doc 49 sec. 3): -0.0347, -0.0155, -0.0019, -0.0044, total -0.0564, 61/27/3/8 %, 0.345 vs 0.413 A.
DECOMP = [("thermodynamic offset\n" + r"$\delta_{\rm D}$ = 28 meV", -0.03471),
          ("shorter D distance\n(0.342 vs 0.409 Å)", -0.01535),
          ("excited vibronic states", -0.00287),
          ("distance distribution,\n" + r"$f(R)$, $A_{\rm acid}$", -0.00722)]
DECOMP_TOTAL = -0.06014
DECOMP_PCT = [58, 25, 5, 12]      # doc 59 sec. 3.1, unrounded 57.7, 25.5, 4.8, 12.0 %; 2026-10-02 (Ken, doc 57/C4):
#   rounded by largest remainder so that they add to 100 % (before: one by one, 58/26/5/12 = 101 %)
DECOMP_DIST = (0.342, 0.409)      # <d>_D, <d>_H at 0.184 V (A) [model; doc 59 sec. 3]
# ablation, alkaline, delta_D 28 meV, lambda 0.3 [fit; doc 47 sec. 5]
ABL = [("excited vibronic states\n(0,0) only", 3.5, 3.5), ("distance distribution\nfixed d*", 7.9, 7.9),
       (r"$f(R)$ slope" + "\n" + r"$f_1=0$", 8.4, 9.6)]     # (label, dAICc, dBIC)
