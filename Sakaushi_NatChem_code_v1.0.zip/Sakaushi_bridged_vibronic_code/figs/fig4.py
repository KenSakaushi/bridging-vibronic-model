"""Fig. 4 - what the bridged expression explains. Tabulated values only (data_tab.py); no model is evaluated.
Panel a model points: doc 47 (delta_D = 27.97 meV, results_47.json 'T4|base|alk'), from 2026-09-29
(before: doc 45, delta_D = 16.2 meV).
2026-09-29 (Ken): numbers agree with the manuscript: panel b measured K = k_H/k_D with the donor concentration ratio;
panels c and d acid values of the doc 59 refit with the 0.05 M D2SO4 data (manuscript v6.4, item D3), window
0.12-0.248 V (the decomposition window; the common window of the text is 0.088-0.297 V). Before: doc 47/49.
2026-09-30 (Ken): panel b shows only the delta_D band (0-32 meV; model/measured 0.57-1.51 [arith]); the grey band
(measured x/÷ 2) was removed, and the text says "within a factor of 1.8" (manuscript v7.1).
2026-09-30 (Ken): previous D data kept; panel b measured log K drawn from 0.25 V (the lowest overpotential of
the D file) instead of 0.30 V; model values and band unchanged.
2026-09-30 (Ken): alkaline common window matched to the D file (0.2496-0.4786 V): panel b model values and band at
0.25 and 0.479 V (was 0.30 and 0.48 V); band from the delta_D sensitivity at each end (0.0134, 0.0126 /meV;
was 0.0132 at both); panel c water <d> at 0.25 and 0.479 V [model; recalc_winD.json].
"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
from style import C, MM, setup, panel_label
import data_tab as T

setup()
fig = plt.figure(figsize=(183 * MM, 118 * MM))
outer = GridSpec(2, 1, figure=fig, height_ratios=[1, 0.92], left=0.07, right=0.985, top=0.93,
                 bottom=0.085, hspace=0.62)
r1 = outer[0].subgridspec(1, 3, width_ratios=[1, 1, 1], wspace=0.40)
r2 = outer[1].subgridspec(1, 4, width_ratios=[0.60, 1.0, 0.62, 0.78], wspace=0.04)
LSA, LSC = (0, (4, 2)), "-"
ax_a, ax_b, ax_c = (fig.add_subplot(r1[0, i]) for i in range(3))
ax_d, ax_e = fig.add_subplot(r2[0, 1]), fig.add_subplot(r2[0, 3])


def tidy(ax, ygrid=True):
    if ygrid:
        ax.grid(axis="y", color=C["grid"], lw=0.4)
    ax.set_axisbelow(True)


# ---------------- (a) alkaline alpha: measured vs bridged
for iso in ("H", "D"):
    e, a = T.OBS[(iso, "alk")]
    m = T.BR_ALPHA_DOC47[iso]
    ax_a.plot(e, m, color=C[iso], lw=1.1, ls=LSA, marker="o", ms=3.4, mfc="white", mec=C[iso], mew=0.9, zorder=2,
              gid=f"{iso} bridged fit (alkaline; doc 47, delta_D 27.97 meV)")
    ax_a.plot(e, a, ls="none", marker="o", ms=3.8, color=C[iso], mec="white", mew=0.4, zorder=4,
              gid=f"{iso} measured (alkaline)")
ax_a.text(0.455, 0.628, "H", fontsize=6.3, ha="left", va="center")
ax_a.text(0.567, 0.386, "D", fontsize=6.3, ha="left", va="center")
ax_a.text(0.03, 0.97, r"bridged, $\lambda$ = 0.3 eV" + "\nno isotope-specific parameter", transform=ax_a.transAxes,
          fontsize=5.8, ha="left", va="top", color=C["ink2"])
hk = [Line2D([], [], ls="none", marker="o", ms=3.8, color=C["ink2"], mec="white", mew=0.4),
      Line2D([], [], color=C["ink2"], lw=1.0, ls=LSA, marker="o", ms=3.4, mfc="white", mec=C["ink2"])]
ax_a.legend(hk, ["measured", "bridged (fit)"], loc="lower left", fontsize=5.8, handlelength=2.4,
            borderaxespad=0.3)
ax_a.set_xlim(0.20, 0.60); ax_a.set_ylim(0.30, 0.70)
ax_a.set_xticks([0.2, 0.3, 0.4, 0.5, 0.6]); ax_a.set_yticks(np.arange(0.30, 0.701, 0.05))
ax_a.set_xlabel(r"$|\eta|$ (V)", labelpad=1.5); ax_a.set_ylabel(r"$\alpha$", labelpad=2)
ax_a.set_title("Water donor: transfer coefficients", fontsize=6.6, pad=3, loc="left")
tidy(ax_a)
panel_label(ax_a, "a", x=-0.19, y=1.03)

# ---------------- (b) alkaline log KIE: prediction with delta_D range
e, k = np.array(T.KALK[0]), np.array(T.KALK[1])    # K = k_H/k_D with the donor concentration ratio [arith; k_fig.json]
ends = np.array([0.25, 0.479])                    # common window ends (2026-09-30; was 0.30, 0.48)
y28 = np.array(T.BRIDGED_03["logK"])
sens = np.array(T.KIE_SENS)                       # per meV, at each end
lo = y28 + sens * (T.DELTA_RANGE[0] - T.DELTA_D)
hi = y28 + sens * (T.DELTA_RANGE[1] - T.DELTA_D)
ax_b.fill_between(ends, lo, hi, color=C["bridged"], alpha=0.18, lw=0)
ax_b.plot(ends, y28, color=C["bridged"], lw=1.2, ls=LSA, marker="o", ms=3.8, mec="white", mew=0.4, zorder=3,
          gid="bridged prediction, delta_D 28 meV (window ends)")
ax_b.plot(e, k, color=C["ink"], lw=0.8, ls=LSA, marker="o", ms=3.8, mec="white", mew=0.4, zorder=4,
          gid="measured log K (alkaline)")
ax_b.text(0.487, y28[1], r"bridged, $\delta_{\rm D}$ = 28 meV", fontsize=5.8, ha="left", va="center")
ax_b.text(0.487, hi[1] + 0.05, r"32 meV", fontsize=5.6, ha="left", va="center", color=C["ink2"])
ax_b.text(0.487, lo[1], r"$\delta_{\rm D}$ = 0", fontsize=5.6, ha="left", va="center", color=C["ink2"])
ax_b.text(0.487, k[-1] - 0.09, "measured", fontsize=5.8, ha="left", va="center")
ax_b.set_xlim(0.20, 0.62); ax_b.set_ylim(0.8, 2.0)
ax_b.set_xticks([0.2, 0.3, 0.4, 0.5, 0.6]); ax_b.set_yticks(np.arange(0.8, 2.001, 0.2))
ax_b.set_xlabel(r"$|\eta|$ (V)", labelpad=1.5)
ax_b.set_ylabel(r"log $K$", labelpad=2)
ax_b.set_title("Water donor: absolute KIE predicted", fontsize=6.6, pad=3, loc="left")
tidy(ax_b)
panel_label(ax_b, "b", x=-0.19, y=1.03)

# ---------------- (c) current-weighted tunnelling distance
for (iso, med), ((e0, e1), (d0, d1)) in T.DMEAN.items():
    ls = LSA if med == "alk" else LSC
    ax_c.plot([e0, e1], [d0, d1], color=C[iso], lw=1.2, ls=ls, marker="o", ms=3.6, mec="white", mew=0.4,
              zorder=2, gid=f"<d> {iso} ({'alkaline' if med == 'alk' else 'acid'}), window ends")
ax_c.text(0.49, 0.642, "H", fontsize=6.3, ha="left", va="center")
ax_c.text(0.49, 0.543, "D", fontsize=6.3, ha="left", va="center")
ax_c.text(0.258, T.DMEAN[("H", "acid")][1][1], "H", fontsize=6.3, ha="left", va="center")
ax_c.text(0.258, T.DMEAN[("D", "acid")][1][1], "D", fontsize=6.3, ha="left", va="center")
ax_c.text(0.39, 0.675, "water:\nmoves outward", fontsize=5.8, ha="center", va="bottom", color=C["ink2"])
ax_c.text(0.125, 0.445, "hydronium:\nD closer than H", fontsize=5.8, ha="center", va="bottom", color=C["ink2"])  # 2026-10-02: moved left (was 0.185; touched the water D marker at 0.25 V)
ax_c.set_xlim(0.0, 0.53); ax_c.set_ylim(0.30, 0.74)
ax_c.set_xticks([0.0, 0.1, 0.2, 0.3, 0.4, 0.5]); ax_c.set_yticks([0.3, 0.4, 0.5, 0.6, 0.7])
ax_c.set_xlabel(r"$|\eta|$ (V)", labelpad=1.5)
ax_c.set_ylabel(r"$\langle d\rangle$ (Å)", labelpad=2)
ax_c.set_title("Current-weighted tunnelling distance", fontsize=6.6, pad=3, loc="left")
lk = [Line2D([], [], color=C["ink2"], lw=1.1, ls=LSC), Line2D([], [], color=C["ink2"], lw=1.1, ls=LSA)]
ax_c.legend(lk, ["acid", "alkaline"], loc="lower right", fontsize=5.8, handlelength=2.4, borderaxespad=0.3)
tidy(ax_c)
panel_label(ax_c, "c", x=-0.19, y=1.03)

# ---------------- (d) acid Delta alpha decomposition (horizontal waterfall)
labels = ["thermodynamic offset " + r"$\delta_{\rm D}$ (28 meV)",
          "shorter D distance (%.3f vs %.3f Å)" % T.DECOMP_DIST,
          "excited vibronic states", r"distance distribution, $f(R)$, $A_{\rm acid}$", "bridged model, total"]
vals = [v for _, v in T.DECOMP]
pct = T.DECOMP_PCT            # doc 59 sec. 3.1: 58, 25, 5, 12 % (largest remainder, sum 100 %; 2026-10-02, before 58/26/5/12)
cum = np.concatenate([[0], np.cumsum(vals)])
ys = np.arange(len(labels))[::-1]
for i, v in enumerate(vals):
    ax_d.barh(ys[i], v, left=cum[i], height=0.58, color=C["bridged"], edgecolor="none", zorder=3)
    ax_d.plot([cum[i + 1], cum[i + 1]], [ys[i] - 0.29, ys[i + 1] + 0.29], color=C["ink2"], lw=0.5, zorder=2,
              gid="shape")
    ax_d.text(cum[i + 1] - 0.004, ys[i], f"{v:+.3f}".replace("-", "−") + f"  ({pct[i]}%)", fontsize=5.7,
              ha="right", va="center")
ax_d.barh(ys[-1], T.DECOMP_TOTAL, height=0.58, color="white", edgecolor=C["bridged"], lw=1.0, zorder=3)
ax_d.text(T.DECOMP_TOTAL - 0.004, ys[-1], f"{T.DECOMP_TOTAL:+.3f}".replace("-", "−"), fontsize=5.7,
          ha="right", va="center")
ax_d.axvline(T.DALPHA_ACID_MEAS, color=C["ink"], lw=0.9, ls=LSC, zorder=2)
ax_d.text(T.DALPHA_ACID_MEAS + 0.004, ys[0] + 0.1, "measured\n−0.20", fontsize=5.8, ha="left", va="center")
ax_d.axvline(0, color=C["axis"], lw=0.6)
ax_d.set_yticks(ys)
ax_d.set_yticklabels(labels, fontsize=5.8)
ax_d.tick_params(axis="y", length=0)
ax_d.set_ylim(-0.5, len(labels) - 0.5)
ax_d.set_xlim(-0.25, 0.0)
ax_d.set_xticks([-0.25, -0.20, -0.15, -0.10, -0.05, 0.0])
ax_d.set_xticklabels(["−0.25", "−0.20", "−0.15", "−0.10", "−0.05", "0.00"])
ax_d.set_xlabel(r"contribution to $\Delta\alpha$ (acid, 0.12–0.248 V)", labelpad=1.5)

ax_d.spines["left"].set_visible(False)
ax_d.grid(axis="x", color=C["grid"], lw=0.4); ax_d.set_axisbelow(True)

# ---------------- (e) ablation, alkaline
labs = [l for l, _, _ in T.ABL]
aic = [v for _, v, _ in T.ABL]
ys = np.arange(len(labs))[::-1]
ax_e.barh(ys, aic, height=0.55, color=C["bridged"], zorder=3)
for y, v, (_, _, bic) in zip(ys, aic, T.ABL):
    ax_e.text(v + 0.2, y, f"+{v:.1f}", fontsize=5.8, ha="left", va="center")
ax_e.axvline(2, color=C["ink2"], lw=0.6, ls=(0, (1, 1.5)), zorder=2)
ax_e.text(2.1, len(labs) - 0.52, "2", fontsize=5.6, ha="left", va="bottom", color=C["ink2"])
ax_e.set_yticks(ys)
ax_e.set_yticklabels([r"excited vibronic states $\rightarrow$ (0,0) only", r"distance distribution $\rightarrow$ fixed $d^*$",
                     r"$f(R)$ slope $\rightarrow$ $f_1=0$"], fontsize=5.8)
ax_e.tick_params(axis="y", length=0)
ax_e.set_xlim(0, 10.5)
ax_e.set_xticks([0, 2, 4, 6, 8, 10])
ax_e.set_ylim(-0.5, len(labs) - 0.5)
ax_e.set_xlabel(r"$\Delta$AICc on removal", labelpad=1.5)
ax_e.grid(axis="x", color=C["grid"], lw=0.4); ax_e.set_axisbelow(True)
ax_e.spines["left"].set_visible(False)

fig.canvas.draw()
for ax_, lab, ttl in ((ax_d, "d", r"Hydronium donor: origin of $\Delta\alpha<0$ in the model"),
                      (ax_e, "e", "Water donor: removing any element worsens the fit")):
    bb = ax_.get_tightbbox(fig.canvas.get_renderer()).transformed(fig.transFigure.inverted())
    y_ = ax_.get_position().y1 + 0.012
    fig.text(bb.x0 - 0.004, y_, lab, fontsize=8, fontweight="bold", ha="right", va="bottom")
    fig.text(bb.x0 + 0.004, y_, ttl, fontsize=6.6, ha="left", va="bottom")

if __name__ == "__main__":
    for ext in ("png", "pdf", "svg"):
        fig.savefig(f"{_PKG}/figs/Fig4_bridged.{ext}", dpi=600 if ext == "png" else None)
    print("ok", lo, hi)
