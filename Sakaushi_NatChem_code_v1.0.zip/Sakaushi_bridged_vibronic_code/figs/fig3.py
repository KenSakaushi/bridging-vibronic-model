"""Fig. 3 - each lineage alone. Tabulated values only (data_tab.py); no model is evaluated.
Axis ranges start at a tick (PowerPoint charts place ticks from the axis minimum).
gid of a data line = series name in the PowerPoint chart; gid "shape" = drawn as a shape.
2026-09-29 (Ken): numbers agree with the manuscript: rms of B-M to two decimals (0.12, 0.11) as in the text, rms of
MHC alone from the unrounded fit (0.026, 0.099); panel d: measured K = k_H/k_D with the donor concentration ratio.
2026-09-30 (Ken): panel d measured log K drawn from 0.25 V.
2026-09-30 (Ken): alkaline common window matched to the D file (0.2496-0.4786 V): panel c Delta alpha over this
window (measured band +0.105 to +0.127); panel d model values at 0.25 and 0.479 V; the arrow is at 0.25 V (x9, was x7
at 0.30 V) [model; recalc_winD.json].
2026-10-01 (Ken, choice A: both instrumental steps removed): panel c measured Delta alpha +0.126 drawn as a line (was a
band +0.105 to +0.127) [fit; corrA.json]; panel d measured log K from the corrected data, arrow x10 at 0.25 V
(10**(2.07 - 1.0863) = 9.6; was x9) [arith; k_fig.json].
2026-10-01 (Ken: panel a is the hydronium donor in Fig. 2 but was the water donor in Fig. 3; make them consistent): panels a and
b swapped, so that a is the hydronium donor (acid) and b the water donor (alkaline), as in Fig. 2.
"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
from style import C, MM, setup, panel_label
import data_tab as T

setup()
fig = plt.figure(figsize=(183 * MM, 138 * MM))
outer = GridSpec(2, 1, figure=fig, height_ratios=[1.0, 1.05], left=0.065, right=0.985, top=0.905,
                 bottom=0.075, hspace=0.50)
top = outer[0].subgridspec(1, 5, width_ratios=[1, 1, 0.10, 1, 1], wspace=0.20)
bot = outer[1].subgridspec(1, 3, width_ratios=[1, 1, 1.12], wspace=0.42)

LS = {"alk": (0, (4, 2)), "acid": "-"}
MED = {"alk": "alkaline", "acid": "acid"}
FADE = "#e3c27f"   # lighter step of the medium-reorganization colour: parameter at its bound


def overlay(ax, med, model, name, mname, note, show_y):
    for iso in ("H", "D"):
        e, a = T.OBS[(iso, med)]
        ax.plot(e, model[iso], color=C[iso], lw=1.0, ls=LS[med], marker="o", ms=3.4, mfc="white", mec=C[iso],
                mew=0.9, zorder=2, gid=f"{iso} {mname} fit ({MED[med]})")
        ax.plot(e, a, ls="none", marker="o", ms=3.8, color=C[iso], mec="white", mew=0.4, zorder=4,
                gid=f"{iso} measured ({MED[med]})")
    ax.set_title(name, fontsize=6.6, pad=3, loc="left", color=C["ink"])
    ax.text(0.03, 0.03, note, transform=ax.transAxes, fontsize=5.7, va="bottom", ha="left",
            color=C["ink2"], linespacing=1.25)
    ax.set_xlabel(r"$|\eta|$ (V)", labelpad=1.5)
    if show_y:
        ax.set_ylabel(r"$\alpha$", labelpad=2)
    else:
        ax.tick_params(labelleft=False)
    ax.grid(axis="y", color=C["grid"], lw=0.4)
    ax.set_axisbelow(True)


# ---------------- (a) hydronium donor, (b) water donor (order of Fig. 2; swapped 2026-10-01)
axes_top = []
for j, (med, col0) in enumerate((("acid", 0), ("alk", 3))):
    bm, mh = T.BM[med], T.MHC[med]
    ax1 = fig.add_subplot(top[0, col0])
    ax2 = fig.add_subplot(top[0, col0 + 1], sharey=ax1)
    n_bm = (f"$\\Delta E_0$ = {bm['dE0']:.2f} eV, $d$ = {bm['d']:.2f} Å\n"
            f"rms {bm['rms']:.2f}")                                   # manuscript: 0.12 (alkali), 0.11 (acid)
    if med == "alk":
        n_bm = r"model $\alpha_{\rm D}>\alpha_{\rm H}$ ($\Delta\alpha<0$)" + "\n" + n_bm
    lam_txt = f"$\\lambda$ = {mh['lam']:.2f} eV" + (" (bound)" if mh["lam"] <= 0.1001 else "")
    dD_txt = (f"isotope offset fitted:\n$\\delta_{{\\rm D}}$ = {mh['dD']:+.2f} eV".replace("-", "−")
              + (" (bound)" if abs(mh["dD"] + 0.2) < 1e-6 else ""))
    nh, nd = len(T.OBS[("H", med)][0]), len(T.OBS[("D", med)][0])
    n_mh = f"{lam_txt}\n{dD_txt}\nrms {mh['rms']:.3f}"                     # manuscript: 0.026 (water), 0.099 (hydronium)
    overlay(ax1, med, bm, "bond-stretching (B-M)", "B-M", n_bm, True)
    overlay(ax2, med, mh, "MHC alone (semiclassical)", "MHC alone", n_mh, False)
    if med == "alk":
        ax2.texts[-1].set_position((0.03, 0.97)); ax2.texts[-1].set_va("top")
        for ax_ in (ax1, ax2):
            ax_.set_xlim(0.20, 0.60); ax_.set_xticks([0.2, 0.3, 0.4, 0.5, 0.6])
        ax1.set_ylim(0.30, 0.72); ax1.set_yticks(np.arange(0.30, 0.701, 0.05))
    else:
        for ax_ in (ax1, ax2):     # alpha_D now reaches 0.35 V (0.05 M D2SO4 file, 13 points)
            ax_.set_xlim(0.0, 0.40); ax_.set_xticks([0.0, 0.1, 0.2, 0.3, 0.4])
            ax_.set_xticklabels(["0.0", "0.1", "0.2", "0.3", "0.4"])
        ax1.set_ylim(0.20, 0.86); ax1.set_yticks(np.arange(0.2, 0.801, 0.1))   # room for the notes below the data
    axes_top.append((ax1, ax2))

(a1, a2), (b1, b2) = axes_top
fig.text(a1.get_position().x0, 0.945, "Hydronium donor (acid)", fontsize=7.5, fontweight="bold", ha="left", va="bottom")
fig.text(b1.get_position().x0, 0.945, "Water donor (alkaline)", fontsize=7.5, fontweight="bold", ha="left", va="bottom")
fig.text(a1.get_position().x0 - 0.045, 0.945, "a", fontsize=8, fontweight="bold", ha="left", va="bottom")
fig.text(b1.get_position().x0 - 0.045, 0.945, "b", fontsize=8, fontweight="bold", ha="left", va="bottom")
# direct isotope labels (measured data)
a1.text(0.275, 0.397, "H", fontsize=6.3, ha="left", va="center")
a1.text(0.25, 0.828, "D", fontsize=6.3, ha="center", va="bottom")
b1.text(0.455, 0.628, "H", fontsize=6.3, ha="left", va="center")
b1.text(0.565, 0.386, "D", fontsize=6.3, ha="left", va="center")
# key for marker meaning
hk = [Line2D([], [], ls="none", marker="o", ms=3.8, color=C["ink2"], mec="white", mew=0.4),
      Line2D([], [], color=C["ink2"], lw=1.0, marker="o", ms=3.4, mfc="white", mec=C["ink2"])]
fig.legend(hk, ["measured", "model (fit)"], loc="upper right", bbox_to_anchor=(0.985, 0.975), ncol=2,
           fontsize=6.2, handlelength=2.2, columnspacing=1.2)

# ---------------- (c) lambda profiles, alkaline: Delta alpha and rms
c1 = fig.add_subplot(bot[0, 0])
c2 = fig.add_subplot(bot[0, 1])
d1 = fig.add_subplot(bot[0, 2])
LSA = (0, (4, 2))
c1.axhline(T.DALPHA_ALK_MEAS, color=C["ink"], lw=0.9, zorder=1, gid="measured Delta alpha (steps removed)")
c1.text(2.6, T.DALPHA_ALK_MEAS + 0.004, "measured", fontsize=6.0, ha="right", va="bottom", color=C["ink2"])
c1.plot(T.BR_LAM, T.BR_DALPHA, color=C["bridged"], ls=LSA, lw=1.1, marker="o", ms=3.8, mec="white", mew=0.4,
        gid="bridged (alkaline)")
c1.plot(T.DA_3A["lam"], T.DA_3A["val"], color=C["medium"], ls=LSA, lw=1.0, marker="s", ms=3.4, mec="white", mew=0.4,
        gid="vibronic, fixed R")
c1.plot(T.DA_3B["lam"], T.DA_3B["val"], color=C["medium"], ls=LSA, lw=1.0, marker="D", ms=3.2, mfc="white",
        mec=C["medium"], mew=0.9, gid="vibronic, thermal P(R)")
c1.plot([T.FREE_3A["lam"]], [T.FREE_3A["dalpha"]], ls="none", marker="s", ms=4.4, color=C["medium"], mec=C["ink"],
        mew=0.6, gid="fixed R, lambda free (at bound 0.05 eV)")
c1.plot([T.FREE_3B["lam"]], [T.FREE_3B["dalpha"]], ls="none", marker="D", ms=4.0, mfc="white", mec=C["ink"], mew=0.8,
        gid="thermal P(R), lambda free (0.088 eV)")
c1.text(T.FREE_3A["lam"], T.FREE_3A["dalpha"] - 0.011, r"$\lambda$ free", fontsize=5.7, ha="center", va="top")
c1.text(T.FREE_3B["lam"], T.FREE_3B["dalpha"] - 0.010, r"$\lambda$ free", fontsize=5.7, ha="center", va="top")
c1.axvline(0.3, color=C["ink2"], lw=0.5, ls=(0, (1, 1.5)))
c1.text(1.13, 0.083, "bridged", fontsize=6.0, ha="left", va="center")
c1.text(1.13, 0.025, "fixed $R$", fontsize=6.0, ha="left", va="center")
c1.text(1.13, 0.006, "thermal $P(R)$", fontsize=6.0, ha="left", va="center")
c1.set_xscale("log")
c1.set_xlim(0.03, 3.0)
c1.set_ylim(0.0, 0.18)
c1.set_xticks([0.03, 0.3, 3.0]); c1.set_xticklabels(["0.03", "0.3", "3"])
c1.set_yticks([0, 0.05, 0.10, 0.15]); c1.set_yticklabels(["0.00", "0.05", "0.10", "0.15"])
c1.minorticks_off()
c1.set_xlabel(r"$\lambda$ (eV)", labelpad=1.5)
c1.set_ylabel(r"$\Delta\alpha$ (0.25–0.48 V)", labelpad=2)
c1.grid(axis="y", color=C["grid"], lw=0.4); c1.set_axisbelow(True)
panel_label(c1, "c", x=-0.20, y=1.05)
c1.set_title("Water donor: isotope difference", fontsize=6.6, pad=3, loc="left")

# rms profile (all points, then the points with a parameter at its bound drawn faded on top)
lam = np.array(T.LAM_GRID)
for vals, bnd, mk, filled, nm in ((T.RMS_3A_ALK, T.BND_3A_ALK, "s", True, "vibronic, fixed R"),
                                  (T.RMS_3B_ALK, T.BND_3B_ALK, "D", False, "vibronic, thermal P(R)")):
    vals, bnd = np.array(vals), np.array(bnd, bool)
    c2.plot(lam, vals, color=C["medium"], ls=LSA, lw=1.0, marker=mk, ms=3.4 if filled else 3.2,
            mfc=C["medium"] if filled else "white", mec="white" if filled else C["medium"],
            mew=0.4 if filled else 0.9, zorder=2, gid=nm)
    c2.plot(lam[bnd], vals[bnd], ls="none", marker=mk, ms=3.4 if filled else 3.2,
            mfc=FADE if filled else "white", mec="white" if filled else FADE, mew=0.4 if filled else 0.9,
            zorder=3, gid=nm + ", parameter at bound")
c2.plot(T.BR_LAM, T.BR_RMS, color=C["bridged"], ls=LSA, lw=1.1, marker="o", ms=3.8, mec="white", mew=0.4, zorder=4,
        gid="bridged (alkaline)")
c2.axvline(0.3, color=C["ink2"], lw=0.5, ls=(0, (1, 1.5)))
c2.text(0.31, 0.0215, r"$\lambda$ used", fontsize=5.8, ha="left", va="bottom", color=C["ink2"])
c2.text(2.6, 0.0775, "thermal $P(R)$", fontsize=6.0, ha="right", va="bottom")
c2.text(0.85, 0.0575, "fixed $R$", fontsize=6.0, ha="center", va="top")
c2.text(1.05, 0.0470, "bridged", fontsize=6.0, ha="left", va="center")
c2.text(2.9, 0.0212, "faded: a parameter\nat its bound", fontsize=5.5, ha="right", va="bottom", color=C["ink2"])
c2.set_xscale("log")
c2.set_xlim(0.03, 3.0)
c2.set_ylim(0.02, 0.08)
c2.set_xticks([0.03, 0.3, 3.0]); c2.set_xticklabels(["0.03", "0.3", "3"])
c2.set_yticks(np.arange(0.02, 0.0801, 0.01))
c2.minorticks_off()
c2.set_xlabel(r"$\lambda$ (eV)", labelpad=1.5)
c2.set_ylabel(r"rms of $\alpha$ (H and D)", labelpad=2)
c2.grid(axis="y", color=C["grid"], lw=0.4); c2.set_axisbelow(True)
c2.set_title("Water donor: fit quality", fontsize=6.6, pad=3, loc="left")

# ---------------- (d) absolute KIE, alkaline
e, k = T.KALK                                     # K = k_H/k_D with the donor concentration ratio [arith; k_fig.json]
d1.plot(e, k, color=C["ink"], ls=LSA, lw=0.8, marker="o", ms=3.8, mec="white", mew=0.4, zorder=5,
        gid="measured log K (alkaline)")
ends = (0.25, 0.479)                              # common window ends (2026-09-30; was 0.30, 0.48)
series = [(T.BRIDGED_03["logK"], C["bridged"], "o", True, "bridged, lambda 0.3 eV"),
          (T.FREE_3A["logK"], C["medium"], "s", True, "fixed R, lambda free (0.05 eV, bound)"),
          (T.FREE_3B["logK"], C["medium"], "D", False, "thermal P(R), lambda free (0.088 eV)")]
for (y0, y1), col, mk, filled, nm in series:
    d1.plot(ends, (y0, y1), color=col, lw=1.1, ls=LSA, marker=mk, ms=3.8 if mk != "D" else 3.4,
            mfc=col if filled else "white", mec="white" if filled else col, mew=0.4 if filled else 0.9, zorder=3,
            gid=nm)
d1.text(0.39, 2.57, "fixed $R$, " + r"$\lambda$" + " = 0.05 eV (free, at bound)", fontsize=5.8, ha="center",
        va="bottom")
d1.text(0.49, 1.74, "bridged,\n" + r"$\lambda$" + " = 0.3 eV", fontsize=5.8, ha="left", va="center")
d1.text(0.49, 1.555, "measured", fontsize=5.8, ha="left", va="center")
d1.text(0.39, 0.90, "thermal $P(R)$, " + r"$\lambda$" + " = 0.088 eV (free)", fontsize=5.8, ha="center", va="top")
k25 = float(np.interp(0.25, e, k))              # measured log K at the lower window end, 0.25 V
y3a = T.FREE_3A["logK"][0]                      # fixed-distance model, lambda free, at 0.25 V
for xx, ya, yb in ((0.244, k25, y3a),):                                    # 10**(2.07 - 1.0863) = 9.6
    d1.annotate("", xy=(xx, yb), xytext=(xx, ya), arrowprops=dict(arrowstyle="<|-|>", color=C["ink2"], lw=0.6,
                                                                    mutation_scale=5, shrinkA=0, shrinkB=0))
    d1.text(xx - 0.006, (ya + yb) / 2, r"$\times$%d" % round(10 ** (yb - ya)), fontsize=6.0, ha="right", va="center",
            color=C["ink"])
d1.set_xlim(0.20, 0.60)
d1.set_ylim(0.5, 2.75)
d1.set_xticks([0.2, 0.3, 0.4, 0.5, 0.6])
d1.set_yticks([0.5, 1.0, 1.5, 2.0, 2.5])
d1.set_xlabel(r"$|\eta|$ (V)", labelpad=1.5)
d1.set_ylabel(r"log $K$", labelpad=2)
d1.grid(axis="y", color=C["grid"], lw=0.4); d1.set_axisbelow(True)
panel_label(d1, "d", x=-0.17, y=1.05)
d1.set_title("Water donor: absolute KIE", fontsize=6.6, pad=3, loc="left")

if __name__ == "__main__":
    for ext in ("png", "pdf", "svg"):
        fig.savefig(f"{_PKG}/figs/Fig3_single_lineages.{ext}", dpi=600 if ext == "png" else None)
    print("ok")
