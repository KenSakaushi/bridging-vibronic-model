"""Shared style for Figs 1, 3, 4 (Nature-style, 183 mm double column)."""
import matplotlib as mpl
import matplotlib.pyplot as plt

MM = 1 / 25.4  # inch per mm

# Palette (validated with dataviz/scripts/validate_palette.js, light surface)
C = dict(
    H="#2a78d6",        # protium
    D="#e34948",        # deuterium
    bridged="#4a3aa7",  # bridged (unified) expression
    bond="#1baf7a",     # bond-stretching lineage
    medium="#c98500",   # medium-reorganization lineage
    iface="#e87ba4",    # interface ingredients (Fig 1 only)
    ink="#0b0b0b",
    ink2="#52514e",
    muted="#898781",
    grid="#e1e0d9",
    axis="#c3c2b7",
    au_fill="#eadcae",
)


def setup():
    mpl.rcParams.update({
        "font.family": "Liberation Sans",
        "font.size": 7,
        "axes.titlesize": 7,
        "axes.labelsize": 7,
        "xtick.labelsize": 6.5,
        "ytick.labelsize": 6.5,
        "legend.fontsize": 6.5,
        "axes.linewidth": 0.6,
        "axes.edgecolor": C["ink2"],
        "axes.labelcolor": C["ink"],
        "xtick.color": C["ink2"],
        "ytick.color": C["ink2"],
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.major.size": 2.5,
        "ytick.major.size": 2.5,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "lines.linewidth": 1.0,
        "lines.markersize": 4,
        "legend.frameon": False,
        "mathtext.fontset": "custom",
        "mathtext.rm": "Liberation Sans",
        "mathtext.it": "Liberation Sans:italic",
        "mathtext.bf": "Liberation Sans:bold",
        "mathtext.cal": "DejaVu Sans:italic",
        "savefig.dpi": 600,
        "pdf.fonttype": 42,
        "svg.fonttype": "none",
    })


def panel_label(ax, s, x=-0.02, y=1.02, **kw):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=8, fontweight="bold",
            va="bottom", ha="right", color=C["ink"], **kw)
