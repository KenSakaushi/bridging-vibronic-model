"""Checks of model_ext.py [model calculation]. Printed labels are in Japanese (the author's working language).
1. With the default settings (δ_D = Δ_ZPE, full, boltz, A_acid) it returns the same α and ln j as
   model.Model(dist="boltz").
2. Implementation of δ_D: at d = 0.5 Å and η = 0, ΔG − ΔE0 of the D (0,0) channel equals δ_D.
3. dist="delta" placed on a grid point agrees with model.Model(dist="gauss", σ = 0.003 Å) at d = d* (limit 1 of doc 43).
4. Smoothness of the interpolation between grid points (α as d* moves in steps of 0.001 Å)."""
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from model import Model, MHC, OBS                    # noqa: E402
from model_ext import ModelX, DDG_ADS, LEV            # noqa: E402

p = dict(dE0_acid=0.2136, f0_acid=1.0, f1_acid=0.2821, dE0_alk=0.6122, f0_alk=0.6091, f1_alk=1.1721)
mhc = MHC(0.3)
M0 = Model(lev=LEV, dist="boltz")
MX = ModelX()
print(f"Δ_ZPE = {MX.zpe*1000:.3f} meV；ΔΔG_ads = {DDG_ADS*1000:.3f} meV")
dmax = 0.0
for (iso, med), (e, _) in OBS.items():
    l0, a0 = M0.lnj_alpha(iso, med, e, p, mhc)
    l1, a1 = MX.lnj_alpha(iso, med, e, p, mhc)
    dmax = max(dmax, np.abs(a0 - a1).max(), np.abs(l0 - l1).max())
print("1. 既定の ModelX と model.Model の差（α と ln j の最大）:", dmax)

for dD in (0.0162, 0.022, 0.028, DDG_ADS):
    M = ModelX(delta_D=dD)
    k0 = int(np.argmin(np.abs(M.d - 0.5)))
    print(f"2. δ_D = {dD*1000:.2f} meV：D の (0,0) の ΔG − ΔE0（d = 0.5, η = 0）= {M.ch['D']['G'][k0,0,0]*1000:.3f} meV；"
          f"H は {M.ch['H']['G'][k0,0,0]*1000:.3f} meV；D に足したずれ {M.shift['D']*1000:.3f} meV")

Md = ModelX(dist="delta")
for ds in (0.3, 0.5, 0.7):
    pg = dict(p, dc_alk=ds, sig_alk=0.003, dc_acid=ds, sig_acid=0.003)
    Mg = Model(lev=LEV, dist="gauss")
    pd = dict(p, dstar_alk=ds, dstar_acid=ds)
    out = []
    for (iso, med), (e, _) in OBS.items():
        _, ag = Mg.lnj_alpha(iso, med, e, pg, mhc)
        _, ad = Md.lnj_alpha(iso, med, e, pd, mhc)
        out.append(np.abs(ag - ad).max())
    print(f"3. d* = {ds}：delta と Gauss(σ = 0.003 Å) の α の差 最大 {max(out):.2e}")

pd = dict(p)
for med, iso in (("alk", "H"), ("alk", "D"), ("acid", "H")):
    vals = []
    for ds in np.arange(0.495, 0.5151, 0.001):
        pd["dstar_" + med] = ds
        vals.append(Md.lnj_alpha(iso, med, [0.37 if med == "alk" else 0.17], pd, mhc)[1][0])
    v = np.array(vals)
    print(f"4. {iso}-{med}：d* = 0.495〜0.515 Å の α", np.round(v, 4), " 2 階差の最大", f"{np.abs(np.diff(v, 2)).max():.1e}")
