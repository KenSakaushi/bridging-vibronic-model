"""Checks of doc 47 [arithmetic] [model calculation]. Printed labels are in Japanese (the author's working language).
1. The stored model α are recomputed with a new ModelX from the stored parameters and compared.
2. RSS, AICc and BIC are recomputed independently of the stored values.
3. Pairs that are the same model (alkaline: 4c and 3b (λ = 0.3), 4b and 3a (λ = 0.3); acid: 4c, 4d and 3b (λ = 0.3))
   reach the same optimum.
4. Equation (2): the increase of log KIE agrees with Δα × Δη/(kT ln10/e) (task 1).
5. Check of the 3a solutions at the bound: fits restricted to d* ≤ 1.0 Å at λ = 0.7 and 1.0 eV (interior optima);
   written to check_3a_interior.json.
6. Estimate of Δα in acid: with Marcus β = 1/2 + ΔG/(2λ), a driving-force offset δ of D gives Δα ≈ −f δ/(2λ)."""
import os
import sys
import json
import math
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from model import OBS, KT                                            # noqa: E402
import model_ext as mx                                               # noqa: E402

RES = [r for r in json.load(open(os.path.join(HERE, "results_47.json"))) if "error" not in r]
R = {r["tag"]: r for r in RES}
N = {"acid": 14, "alk": 12}

# 1 and 2
dmax, icmax = 0.0, 0.0
cache = {}
for r in RES:
    key = json.dumps(r["model"], sort_keys=True)
    if key not in cache:
        cache[key] = mx.ModelX(**r["model"])
    M = cache[key]
    mhc = mx.get_mhc(r["lam"])
    for med in r["meds"]:
        rss = 0.0
        for iso in "HD":
            e, a = OBS[(iso, med)]
            _, am = M.lnj_alpha(iso, med, e, r["p"], mhc)
            dmax = max(dmax, float(np.abs(am - np.array(r["per"][f"{iso}-{med}"]["model"])).max()))
            rss += float(((am - np.array(a)) ** 2).sum())
        if len(r["meds"]) == 1:
            n, k = N[med], len(r["names"])
            aicc = n * math.log(rss / n) + 2 * k + 2 * k * (k + 1) / (n - k - 1)
            bic = n * math.log(rss / n) + k * math.log(n)
            icmax = max(icmax, abs(aicc - r["ic"][med]["AICc"]), abs(bic - r["ic"][med]["BIC"]), abs(rss - r["ic"][med]["RSS"]))
print(f"1. 保存した α と再計算の差の最大 {dmax:.1e}（保存は小数 4 桁に丸めている）")
print(f"2. RSS・AICc・BIC の保存値と独立計算の差の最大 {icmax:.1e}")

# 3
pairs = [("T4|4c|alk", "T3|3b|alk|lam=0.3"), ("T4|4b|alk", "T3|3a|alk|lam=0.3"),
         ("T4|4c|acid", "T4|4d|acid"), ("T4|4c|acid", "T3|3b|acid|lam=0.3"), ("T4|4b|acid", "T3|3a|acid|lam=0.3"),
         ("T1|dD=28|acid", "T4|base|acid"), ("T1|dD=28|alk", "T4|base|alk")]
for a, b in pairs:
    print(f"3. {a} と {b}：rms {R[a]['rms']:.5f} / {R[b]['rms']:.5f}")

# 4
print("4. 式 (2) の検算：log KIE の増分 と Δα × Δη /(kT ln10)")
for t in ("T1|dD=zpe|alk", "T1|dD=22|alk", "T1|dD=28|alk", "T1|dD=28|acid", "T3|3a|alk|lam=free", "T4|4c|alk"):
    med = R[t]["meds"][0]
    f = R[t]["features"][med]
    e0, e1 = (0.30, 0.48) if med == "alk" else (0.13, 0.245)
    w0, w1 = mx.WIN[med]
    print(f"   {t:22s} Δlog KIE {f['lkie'][-1]-f['lkie'][0]:+.3f}；Δα(揃えた窓) × Δη/(kT ln10) = {f['dA']*(e1-e0)/(KT*math.log(10)):+.3f}")
f16, f28 = R["T1|dD=zpe|alk"]["features"]["alk"], R["T1|dD=28|alk"]["features"]["alk"]
sens = (f28["lkie"][0] - f16["lkie"][0]) / (28.0 - R["T1|dD=zpe|alk"]["zpe"] * 1000)
rb = R["T1|dD=28|alk"]
fD = rb["p"]["f0_alk"] + rb["p"]["f1_alk"] * (rb["features"]["alk"]["Rstar"]["D"][0] - 0.5)
bD = np.mean(rb["per"]["D-alk"]["model"][:2]) / fD
print(f"   アルカリの log KIE(0.30 V) の δ_D への感度 {sens:.4f} /meV；目安 β_D/(kT ln10) = (α_D/f(<d>_D))/(kT ln10) = "
      f"{bD:.2f}/{KT*math.log(10)*1000:.1f} meV = {bD/(KT*math.log(10))/1000:.4f} /meV（ΔG のずれには f ではなく β が掛かる）")

# 5
print("5. 3a の境界解の点検（d* ≤ 1.0 Å に制限）")
mx.BND["dstar"] = (0.0, 1.0)
chk = []
for lam in (0.7, 1.0):
    for med in ("acid", "alk"):
        base = R[f"T3|3a|{med}|lam={lam}"]
        cfg = dict(tag=f"chk|3a|{med}|lam={lam}|d*<=1.0", model=base["model"], meds=[med],
                   names=[f"dE0_{med}", f"f0_{med}", f"dstar_{med}"], fixed={f"f1_{med}": 0.0},
                   lam=lam, nstart=48, seed=777, warm=[{f"dE0_{med}": 0.6, f"f0_{med}": 0.69, f"dstar_{med}": ds} for ds in (0.3, 0.5, 0.7)])
        r = mx.run_fit(cfg)
        chk.append(r)
        ft = r["features"][med]
        print(f"   λ {lam} {med}: rms {r['rms']:.4f}（H {r['per'][f'H-{med}']['rms']:.3f} / D {r['per'][f'D-{med}']['rms']:.3f}）"
              f" 境界解 {base['rms']:.4f}；p " + " ".join(f"{n}={v:.3f}" for n, v in zip(r["names"], r["x"]))
              + f" bound {r['at_bound']}；Δα {ft['dA']:+.3f}；log KIE {ft['lkie'][0]:.2f}→{ft['lkie'][-1]:.2f}；AICc {r['ic'][med]['AICc']:.1f} BIC {r['ic'][med]['BIC']:.1f}")
json.dump(chk, open(os.path.join(HERE, "check_3a_interior.json"), "w"), indent=1, default=float)

# 6
for lam in (0.3,):
    for dD in (R["T1|dD=zpe|acid"]["zpe"], 0.028):
        print(f"6. λ = {lam}、f = 1、δ = {dD*1000:.1f} meV：Marcus の目安 Δα ≈ −δ/(2λ) = {-dD/(2*lam):+.3f}")
print("   模型（酸、媒質別）：Δα", {t: round(R[t]["features"]["acid"]["dA"], 3) for t in ("T1|dD=zpe|acid", "T1|dD=22|acid", "T1|dD=28|acid")})
