"""F1: acid refit at lambda = 0.3 eV with the updated D data (sets: old, new, trim). [fit]"""
import json, numpy as np
from acid59_model import *
from run_tasks import W45

M = ModelX(delta_D=DDG_ADS)
w47 = dict(dE0_acid=0.2167, f0_acid=0.99999, f1_acid=0.2014)
names = ["dE0_acid", "f0_acid", "f1_acid"]
out = {}
for i, s in enumerate(("old", "new", "trim")):
    r = fit(SETS[s], names, {"lam": 0.3}, M, nstart=32, seed=5900 + i, warm=[W45["acid"], w47])
    mhc = get_mhc(0.3)
    fe = features(M, r["p"], mhc)
    pw = point_vs_window(M, SETS[s], r["p"], mhc)
    r["features"] = fe; r["point_vs_window"] = pw
    out[s] = r
    print(f"{s:5s} n={r['n']:2d} rms {r['rms']:.4f} (H {r['rmsH']:.4f} D {r['rmsD']:.4f})  p",
          {k: round(v, 4) for k, v in r['p'].items() if k != 'lam'}, f"bound {r['at_bound']} conv {r['nconv']}  {r['sec']} s")
    print(f"      AICc {r['AICc']:.1f} BIC {r['BIC']:.1f} | dA 0.12-0.248 {fe['dA_old']:+.4f} (obs -0.201), 0.09-0.297 {fe['dA_full']:+.4f} (obs -0.205)")
    print("      logK model:", ' '.join(f"{e:.3f}:{v:.2f}" for e, v in fe['logK'].items()), "| K=1 cross", fe['K1_cross'], "min logK %.2f" % fe['logK_min'])
    print("      alpha_D peak %.3f at %.3f V; steepest slope H %.2f at %.3f, D %.2f at %.3f V" % (*fe['a_D_peak'], *fe['slope_H_min'], *fe['slope_D_min']))
    print("      alpha H at", {k: round(v, 3) for k, v in fe['a_H_at'].items()})
    print("      alpha D at", {k: round(v, 3) for k, v in fe['a_D_at'].items()})
    print("      <d> H", [round(v, 3) for v in fe['d_H']], "D", [round(v, 3) for v in fe['d_D']], "(0.12, 0.184, 0.248, 0.30, 0.35 V)")
    print("      mu>=1 H", [round(v, 2) for v in fe['mu1_H']], "D", [round(v, 2) for v in fe['mu1_D']], "| nu>=1 D", [round(v, 2) for v in fe['nu1_D']])
    print("      f at <d>(0.184):", {k: round(v, 3) for k, v in fe['f_at_d'].items()}, "| point vs window max |diff|", {k: round(v, 4) for k, v in pw.items()})
    print("      residuals D:", ' '.join(f"{e:.2f}:{v:+.3f}" for e, v in zip(SETS[s]['D'][0], r['res'][len(SETS[s]['H'][0]):])), flush=True)
json.dump(out, open("f1_59.json", "w"), indent=1, default=float)
