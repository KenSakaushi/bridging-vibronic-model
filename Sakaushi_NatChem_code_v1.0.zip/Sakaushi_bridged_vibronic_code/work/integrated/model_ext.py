"""doc 47: the integrated model (equations 3–6 of doc 46) with switches for calculations 1, 3 and 4.
model.py (docs 43 and 45) is unchanged. With the default settings (delta_D=None, ladder="full", dist="boltz",
A_acid=True) it returns the same values as model.Model(dist="boltz") (checked by check_ext.py).

Switches
  delta_D : δ_D [eV] of equation (5) of doc 46. (δ_D − Δ_ZPE) is added to ΔG of every D channel.
            Δ_ZPE is the zero-point shift (D − H) of ΔG of the (0,0) channel at d = 0.5 Å, computed from the levels
            (16.19 meV). None gives δ_D = Δ_ZPE (as in docs 43 and 45).
  ladder  : "full" (μ ≤ 2, ν ≤ 7) or "00" (the (0,0) channel only; task 4a)
  dist    : "boltz" (Boltzmann distribution of stage 3a, doc 45) or "delta" (P(R) = δ(d − d*); tasks 3a and 4b)
            With "delta", levels and overlaps are interpolated linearly from the 0.01 Å grid to d*
            (ΔG linearly; |S|² logarithmically where S keeps its sign, S linearly where it changes sign).
  A_acid  : True multiplies the acid rate by the H3O+ accumulation A = exp[(1 − f) e|η|/kT]; False sets A = 1
            (tasks 3 and 4d)
  f(R)    : f0 + f1 (d − d0), clipped to [0, 1]. To leave f1 unfitted, pass f1 = 0 in fixed (tasks 3 and 4c).
Source of numbers: [model calculation] [fit]"""
import os
import sys
import time
import numpy as np
from scipy.optimize import least_squares

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from model import MHC, OBS, KT, WIN, LKIE_OBS          # noqa: E402

LEV = os.path.join(HERE, "levels_ext.npz")
EV_KCAL = 23.060548
DDG_ADS = 0.645 / EV_KCAL                            # 27.97 meV (thermodynamic ΔΔG_ads)
BND = {"dE0": (-0.6, 1.2), "f0": (0.1, 1.0), "f1": (-2.0, 2.0), "dstar": (0.0, 1.32), "lam": (0.05, 2.0)}
NPT = {"acid": 14, "alk": 12}


class ModelX:
    def __init__(self, delta_D=None, ladder="full", dist="boltz", A_acid=True, lev=LEV,
                 mu_max=3, nu_max=8, d0=0.5, beta_el=1.0):
        z = np.load(lev)
        self.d = z["d"]
        self.d0, self.dist, self.A_acid, self.ladder, self.beta_el = d0, dist, A_acid, ladder, beta_el
        k0 = int(np.argmin(np.abs(self.d - d0)))
        self.Eref = float(z["eP_H"][k0, 0] - z["eR_H"][k0, 0])
        self.zpe = float(z["eP_D"][k0, 0] - z["eR_D"][k0, 0]) - self.Eref
        self.delta_D = self.zpe if delta_D is None else float(delta_D)
        self.shift = {"H": 0.0, "D": self.delta_D - self.zpe}
        if dist == "boltz":
            sys.path.insert(0, os.path.join(HERE, "..", "stage3a_R_integral"))
            sys.path.insert(0, os.path.join(HERE, "..", "stage1_morse_overlap"))
            from proton_potentials import ProtonPotentials
            pot = ProtonPotentials()
            self.Wa = {iso: z["eR_" + iso][:, 0] - pot.E_a0_inf(iso) / EV_KCAL for iso in ("H", "D")}
            self.lnPB = {iso: -self.Wa[iso] / KT for iso in ("H", "D")}
        h = np.diff(self.d)
        w = np.zeros(len(self.d))
        w[:-1] += h / 2
        w[1:] += h / 2
        self.lnw = np.log(w)
        if ladder == "00":
            mu_max, nu_max = 1, 1
        self.ch = {}
        for iso in ("H", "D"):
            eRall = z["eR_" + iso]
            eR = eRall[:, :mu_max]
            eP = z["eP_" + iso][:, :nu_max]
            S = z["S_" + iso][:, :mu_max, :nu_max]
            G = eP[:, None, :] - eR[:, :, None] - self.Eref + self.shift[iso]
            lnPmu = (-(eR - eRall[:, :1]) / KT
                     - np.log(np.exp(-(eRall - eRall[:, :1]) / KT).sum(1))[:, None])
            lnWc = (np.log(np.maximum(S ** 2, 1e-300)) + lnPmu[:, :, None]
                    + (-beta_el * (self.d - d0))[:, None, None])
            self.ch[iso] = dict(G=G, lnWc=lnWc, S=S, lnPmu=lnPmu)

    # ---- interpolation to d* (dist = "delta") ----
    def at(self, iso, ds):
        c = self.ch[iso]
        k = int(np.clip(np.searchsorted(self.d, ds) - 1, 0, len(self.d) - 2))
        t = (ds - self.d[k]) / (self.d[k + 1] - self.d[k])
        G = (1 - t) * c["G"][k] + t * c["G"][k + 1]
        S0, S1 = c["S"][k], c["S"][k + 1]
        l0, l1 = np.log(np.maximum(S0 ** 2, 1e-300)), np.log(np.maximum(S1 ** 2, 1e-300))
        Sl = (1 - t) * S0 + t * S1
        lnS2 = np.where(S0 * S1 > 0, (1 - t) * l0 + t * l1, np.log(np.maximum(Sl ** 2, 1e-300)))
        lnPmu = (1 - t) * c["lnPmu"][k] + t * c["lnPmu"][k + 1]
        lnW = lnS2 + lnPmu[:, None] - self.beta_el * (ds - self.d0)
        return G, lnW

    def f_of(self, p, med, d=None):
        d = self.d if d is None else d
        return np.clip(p["f0_" + med] + p.get("f1_" + med, 0.0) * (d - self.d0), 0.0, 1.0)

    def lnj_alpha(self, iso, med, eta, p, mhc, detail=False):
        eta = np.atleast_1d(np.asarray(eta, dtype=float))
        if self.dist == "delta":
            ds = float(p["dstar_" + med])
            G0, lnW = self.at(iso, ds)
            G0, lnW = G0[None], lnW[None]
            f = np.atleast_1d(self.f_of(p, med, np.array([ds])))
            lnP = np.zeros(1)
        else:
            c = self.ch[iso]
            G0, lnW = c["G"], c["lnWc"] + self.lnw[:, None, None]
            f = self.f_of(p, med)
            lnP = self.lnPB[iso]
        a = (1.0 - f) if (med == "acid" and self.A_acid) else np.zeros_like(f)
        G = p["dE0_" + med] + G0[None] - f[None, :, None, None] * eta[:, None, None, None]
        lnF, dlnF = mhc(G)
        lnjc = (lnW[None] + lnP[None, :, None, None]
                + (a[None, :] * eta[:, None] / KT)[:, :, None, None] + lnF)
        m = lnjc.max(axis=(1, 2, 3), keepdims=True)
        wgt = np.exp(lnjc - m)
        J = wgt.sum(axis=(1, 2, 3))
        ac = a[None, :, None, None] + f[None, :, None, None] * (-KT * dlnF)
        alpha = (wgt * ac).sum(axis=(1, 2, 3)) / J
        lnj = m[:, 0, 0, 0] + np.log(J)
        if detail:
            return lnj, alpha, wgt / J[:, None, None, None]
        return lnj, alpha

    def Rstar(self, iso, med, etas, p, mhc):
        if self.dist == "delta":
            return np.full(len(np.atleast_1d(etas)), float(p["dstar_" + med]))
        _, _, w = self.lnj_alpha(iso, med, etas, p, mhc, detail=True)
        return (w.sum(axis=(2, 3)) * self.d[None, :]).sum(1)


def features_med(M, p, mhc, med):
    """Features of medium med, with the same definitions as doc 45 (model.features, analyze_b.py)."""
    r = {}
    a, b = WIN[med]
    g = np.linspace(a, b, 41)
    aw = {}
    for iso in "HD":
        lj, _ = M.lnj_alpha(iso, med, g, p, mhc)
        aw[iso] = KT * np.polyfit(g, lj, 1)[0]
    r["dA"] = float(aw["H"] - aw["D"])
    r["aw"] = (float(aw["H"]), float(aw["D"]))
    e, _ = LKIE_OBS[med]
    lh, _ = M.lnj_alpha("H", med, e, p, mhc)
    ld, _ = M.lnj_alpha("D", med, e, p, mhc)
    r["lkie"] = [float(v) for v in (lh - ld) / np.log(10)]
    r["Rstar"] = {iso: [float(v) for v in M.Rstar(iso, med, [a, b], p, mhc)] for iso in "HD"}
    if med == "acid":
        _, aD = M.lnj_alpha("D", "acid", [0.16, 0.18, 0.20, 0.22], p, mhc)
        r["acidD_mean"], r["acidD_range"] = float(aD.mean()), float(aD.max() - aD.min())
        _, aH = M.lnj_alpha("H", "acid", [0.09, 0.27], p, mhc)
        r["acidH_ends"] = (float(aH[0]), float(aH[1]))
        eg = np.linspace(0.09, 0.27, 91)
        _, ag = M.lnj_alpha("H", "acid", eg, p, mhc)
        r["acidH_smin"] = float(np.gradient(ag, eg).min())
    else:
        for iso in "HD":
            e, _ = OBS[(iso, "alk")]
            _, am = M.lnj_alpha(iso, "alk", e, p, mhc)
            r["c2_" + iso] = float(np.polyfit(e, am, 2)[0])
    return r


def info(rss, n, k):
    """AICc and BIC (definitions of calculation plan A)."""
    aicc = n * np.log(rss / n) + 2 * k + 2 * k * (k + 1) / (n - k - 1)
    bic = n * np.log(rss / n) + k * np.log(n)
    return float(aicc), float(bic)


def expand(names, x, fixed, meds):
    p = dict(fixed)
    for n, v in zip(names, map(float, x)):
        if n == "lam" or n.endswith("_acid") or n.endswith("_alk"):
            p[n] = v
        else:                                    # parameter shared by the media (e.g. f1)
            for med in meds:
                p[f"{n}_{med}"] = v
    return p


def bounds(names):
    lo = np.array([BND[n.split("_")[0]][0] for n in names])
    hi = np.array([BND[n.split("_")[0]][1] for n in names])
    return lo, hi


_MHC = {}


def get_mhc(lam):
    key = round(float(lam), 12)
    if key not in _MHC:
        if len(_MHC) > 40:
            for k in list(_MHC)[:20]:
                _MHC.pop(k)
        _MHC[key] = MHC(key)
    return _MHC[key]


def residuals(M, names, fixed, meds, curves, x):
    p = expand(names, x, fixed, meds)
    mhc = get_mhc(p["lam"])
    r = []
    for (iso, med) in curves:
        e, a = OBS[(iso, med)]
        _, am = M.lnj_alpha(iso, med, e, p, mhc)
        r.extend(am - np.array(a))
    return np.array(r)


def run_fit(cfg, M=None):
    """cfg: tag, model (dict), meds (list), names (list), fixed (dict), lam (float), nstart, seed, warm (list of dict).
    lam is fixed (fits with λ free are refined by refine_free())."""
    t0 = time.time()
    M = M or ModelX(**cfg["model"])
    meds, names = list(cfg["meds"]), list(cfg["names"])
    fixed = dict(cfg.get("fixed", {}))
    if "lam" not in names:
        fixed["lam"] = float(cfg["lam"])
    curves = [c for c in OBS if c[1] in meds]
    lo, hi = bounds(names)
    rng = np.random.default_rng(cfg.get("seed", 0))
    starts = [lo + (hi - lo) * rng.random(len(lo)) for _ in range(cfg.get("nstart", 16))]
    for w in cfg.get("warm", []):
        if all(n in w for n in names):
            starts.append(np.clip(np.array([w[n] for n in names], dtype=float), lo + 1e-9, hi - 1e-9))
    best = None
    for x0 in starts:
        try:
            s = least_squares(lambda x: residuals(M, names, fixed, meds, curves, x), x0,
                              bounds=(lo, hi), x_scale="jac", max_nfev=cfg.get("max_nfev", 200))
        except Exception:
            continue
        if best is None or s.cost < best.cost:
            best = s
    return summarize(cfg, M, names, fixed, meds, curves, best, lo, hi, time.time() - t0)


def summarize(cfg, M, names, fixed, meds, curves, best, lo, hi, sec):
    p = expand(names, best.x, fixed, meds)
    mhc = get_mhc(p["lam"])
    per, rss = {}, {m: 0.0 for m in meds}
    for (iso, med) in curves:
        e, a = OBS[(iso, med)]
        _, am = M.lnj_alpha(iso, med, e, p, mhc)
        res = am - np.array(a)
        per[f"{iso}-{med}"] = dict(rms=float(np.sqrt(np.mean(res ** 2))), model=[round(float(v), 4) for v in am])
        rss[med] += float((res ** 2).sum())
    k = len(names)
    ic = {}
    if len(meds) == 1:
        ic[meds[0]] = dict(zip(("AICc", "BIC"), info(rss[meds[0]], NPT[meds[0]], k))) | dict(RSS=rss[meds[0]], n=NPT[meds[0]], k=k)
    else:
        n = sum(NPT[m] for m in meds)
        ic["total"] = dict(zip(("AICc", "BIC"), info(sum(rss.values()), n, k))) | dict(RSS=sum(rss.values()), n=n, k=k)
    at_b = [n for n, v, l, h in zip(names, best.x, lo, hi) if min(v - l, h - v) < 1e-3 * (h - l)]
    feats = {med: features_med(M, p, mhc, med) for med in meds}
    return dict(tag=cfg["tag"], meds=meds, names=names, x=[float(v) for v in best.x], p=p, lam=p["lam"],
                rms=float(np.sqrt(2 * best.cost / len(best.fun))), per=per, rss=rss, ic=ic, at_bound=at_b,
                features=feats, delta_D=M.delta_D, zpe=M.zpe, model=cfg["model"], sec=round(sec, 1))


LAMGRID = [0.05, 0.075, 0.10, 0.15, 0.20, 0.30, 0.40, 0.50, 0.70, 1.00, 1.50, 2.00]


def refine_free(cfg, grid_results):
    """λ free: starting from the two best fits on the λ grid (grid_results), λ is also varied and the fit is refined
    locally."""
    t0 = time.time()
    M = ModelX(**cfg["model"])
    meds = list(cfg["meds"])
    names = list(cfg["names"]) + ["lam"]
    fixed = {k: v for k, v in cfg.get("fixed", {}).items()}
    curves = [c for c in OBS if c[1] in meds]
    lo, hi = bounds(names)
    best = None
    for g in sorted(grid_results, key=lambda r: r["rms"])[:2]:
        x0 = np.clip(np.array([g["p"][n] if n != "lam" else g["lam"] for n in names], dtype=float), lo + 1e-9, hi - 1e-9)
        s = least_squares(lambda x: residuals(M, names, fixed, meds, curves, x), x0,
                          bounds=(lo, hi), x_scale="jac", max_nfev=300)
        if best is None or s.cost < best.cost:
            best = s
    c2 = dict(cfg)
    c2["tag"] = cfg["tag"].replace("lam=grid", "lam=free")
    return summarize(c2, M, names, fixed, meds, curves, best, lo, hi, time.time() - t0)
