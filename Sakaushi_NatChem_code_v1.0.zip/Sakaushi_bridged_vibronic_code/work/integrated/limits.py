"""Limits of the integrated model and an early curvature bound (the bound of equation (9) of the paper is evaluated
in work/acid59/l1_bound.py). Source of numbers: [model calculation] (only (4) is arithmetic on measured [fit] values).
Printed labels are in Japanese (the author's working language). Writes levels_harm.npz (harmonic test levels).

(0) Curvature of the MHC kernel: (ln F)'' ≥ −1/(2λkT) (a mixture of Gaussian kernels). → for any sum of channels
    dα/d|η| ≥ −f_max²/(2λ)  [V⁻¹, λ in eV] (the sum only adds terms with Var ≥ 0)
(1) Narrow P(R) → the standard vibronic theory (sum over μν at a single fixed R)
(2) Single channel + harmonic potentials → Marcus type (MHC). Overlaps are compared with the analytical expression
(3) Small λ → B-M-like threshold (α falls where (0,0) turns from endergonic to exergonic)
(4) From the slopes between neighbouring measured local α, the upper bound on λ that they require
"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "stage3a_R_integral"))
sys.path.insert(0, os.path.join(HERE, "..", "stage1_morse_overlap"))
sys.path.insert(0, _PKG + "/pack/model")
from model import Model, MHC, KT, OBS                                  # noqa: E402
from proton_potentials import ProtonPotentials                         # noqa: E402
from morse_dvr import solve_1d, hbar2_over_2m, CM1_TO_KCAL             # noqa: E402
import ext2                                                            # noqa: E402  independent MHC implementation of (1)

EV = 23.060548
np.set_printoptions(precision=3, suppress=True, linewidth=150)

print("(0) MHC 核の曲率  2λkT·(lnF)'' の範囲（−1 を下回らないはず）")
for lam in (0.05, 0.1, 0.3, 0.6, 1.0):
    m = MHC(lam)
    c = np.gradient(m.dlnF, m.dx)
    sel = (m.x > -2.0) & (m.x < 2.5)
    print(f"   λ = {lam:4.2f} eV : min {(c[sel]*2*lam*KT).min():+.4f}  max {(c[sel]*2*lam*KT).max():+.4f}"
          f"   → |dα/dη| の上限 f²/(2λ) = {1/(2*lam):.2f} f² V⁻¹")

M = Model()
print(f"\nEref = εP0^H − εR0^H (d0=0.5) = {M.Eref:.4f} eV")

print("\n(1) P(R) を狭くする → 固定 R の標準の振電理論")
pot = ProtonPotentials()
mhc = MHC(0.3)
eta = np.array([0.25, 0.35, 0.45, 0.55])


def standard(iso, eta, dE0, f, mhc, mu_max=3, nu_max=8):
    er, ep, S = pot.solve(iso, pot.R_of_d(0.5))
    er, ep = er / EV, ep / EV
    lnP = -(er[:mu_max] - er[0]) / KT - np.log(np.exp(-(er - er[0]) / KT).sum())
    G = dE0 + ep[None, :nu_max] - er[:mu_max, None] - M.Eref
    a = []
    for e in eta:
        lnF, dl = mhc(G - f * e)
        lw = lnP[:, None] + np.log(S[:mu_max, :nu_max] ** 2) + lnF
        w = np.exp(lw - lw.max())
        a.append((w * f * (-KT * dl)).sum() / w.sum())
    return np.array(a)


base = dict(dE0_alk=0.15, f0_alk=0.7, f1_alk=1.0, dc_alk=0.5, dE0_acid=0.15, f0_acid=0.7, f1_acid=1.0, dc_acid=0.5)
for iso in "HD":
    p = dict(base, sig_alk=0.003)
    _, a_int = M.lnj_alpha(iso, "alk", eta, p, mhc)
    a_std = standard(iso, eta, 0.15, 0.7, mhc)
    print(f"   {iso}: σ=0.003 Å の統合模型 {a_int}  固定 R の標準形 {a_std}  最大差 {np.abs(a_int-a_std).max():.1e}")
print("   σ を広げたときの α（η = 0.40 V、λ = 0.3、f0 = 0.7、f1 = 1.0 /Å、ΔE0 = 0.15 eV、d_c = 0.5 Å）")
print("     σ(Å)  | アルカリ α_H  α_D   Δα    <d>_H  <d>_D | 酸 α_H  α_D   Δα    <d>_H  <d>_D")
for sig in (0.003, 0.05, 0.10, 0.15, 0.20, 0.30):
    p = dict(base, sig_alk=sig, sig_acid=sig)
    row = []
    for med in ("alk", "acid"):
        aH = M.lnj_alpha("H", med, [0.40], p, mhc)[1][0]
        aD = M.lnj_alpha("D", med, [0.40], p, mhc)[1][0]
        RH = M.Rstar("H", med, [0.40], p, mhc)[0]
        RD = M.Rstar("D", med, [0.40], p, mhc)[0]
        row.append(f"{aH:.3f} {aD:.3f} {aH-aD:+.3f}  {RH:.3f} {RD:.3f}")
    print(f"     {sig:5.3f} | " + " | ".join(row))
p = dict(base, sig_alk=0.15, sig_acid=0.15)
for med in ("alk", "acid"):
    rs = {iso: M.Rstar(iso, med, [0.30, 0.50], p, mhc) for iso in "HD"}
    print(f"   σ=0.15: {med:4s} d<R*> の動き 0.30→0.50 V: H {rs['H'][0]:.3f}→{rs['H'][1]:.3f}, "
          f"D {rs['D'][0]:.3f}→{rs['D'][1]:.3f} Å  (∂<d>/∂|η| H {(rs['H'][1]-rs['H'][0])/0.2:+.2f}, "
          f"D {(rs['D'][1]-rs['D'][0])/0.2:+.2f} Å/V)")

print("\n(2) 単一チャネル＋調和ポテンシャル → Marcus 型")
x = np.arange(-0.9, 3.2 + 1e-9, 0.0025)
CH = hbar2_over_2m("H")
kR = (2600 * CM1_TO_KCAL) ** 2 / (2 * CH)          # kcal/mol/Å² (force constant matching the frequency with the H mass)
kP = (1600 * CM1_TO_KCAL) ** 2 / (2 * CH)
dh = np.round(np.arange(0.46, 0.5401, 0.01), 4)
harm = {"d": dh}
for iso in "HD":
    C = hbar2_over_2m(iso)
    ep, cp = solve_1d(x, 0.5 * kP * x ** 2, iso, 10)
    eR = np.zeros((len(dh), 10)); eP = np.zeros_like(eR); S = np.zeros((len(dh), 10, 10))
    for k, dk in enumerate(dh):
        er, cr = solve_1d(x, 0.5 * kR * (x - dk) ** 2, iso, 10)
        eR[k], eP[k], S[k] = er / EV, ep / EV, cr.T @ cp
    harm["eR_" + iso], harm["eP_" + iso], harm["S_" + iso] = eR, eP, S
    aR, aP = np.sqrt(kR / (2 * C)), np.sqrt(kP / (2 * C))
    S00 = np.sqrt(2 * np.sqrt(aR * aP) / (aR + aP)) * np.exp(-aR * aP * 0.5 ** 2 / (2 * (aR + aP)))
    k = int(np.argmin(np.abs(dh - 0.5)))
    print(f"   {iso}: |S00|(d=0.5) DVR {abs(S[k,0,0]):.6e}  解析式 {S00:.6e}  相対差 {abs(abs(S[k,0,0])/S00-1):.1e}")
np.savez(os.path.join(HERE, "levels_harm.npz"), **harm)
Mh = Model(lev=os.path.join(HERE, "levels_harm.npz"), mu_max=1, nu_max=1)
for lam in (0.3, 0.6):
    mh = MHC(lam)
    for dE0 in (0.0, 0.2):
        p = dict(dE0_alk=dE0, f0_alk=0.8, f1_alk=0.0, dc_alk=0.5, sig_alk=0.003)
        e = np.linspace(0.05, 0.6, 12)
        _, a_int = Mh.lnj_alpha("H", "alk", e, p, mh)
        h = 1e-3
        a_mhc = KT * (np.log(ext2.mhc(dE0 - 0.8 * (e + h), lam)) - np.log(ext2.mhc(dE0 - 0.8 * (e - h), lam))) / (2 * h) * (-1)
        a_mhc = -a_mhc
        a_mar = 0.8 * (lam + dE0 - 0.8 * e) / (2 * lam)
        print(f"   λ={lam}, ΔE0={dE0}: 最大|α_統合 − α_MHC(①の別実装)| = {np.abs(a_int-a_mhc).max():.1e}"
              f"   最大|α_統合 − α_Marcus(Fermi なし)| = {np.abs(a_int-a_mar).max():.3f}")

print("\n(3) λ を小さくする → B-M 的なしきい値（アルカリ形、f = 1、σ = 0.003 Å、ΔE0 = 0.20 eV）")
k0 = int(np.argmin(np.abs(M.d - 0.5)))
z = np.load(os.path.join(HERE, "levels.npz"))
thr = {iso: 0.20 + (z["eP_" + iso][k0, 0] - z["eR_" + iso][k0, 0]) - M.Eref for iso in "HD"}
print(f"   (0,0) が発熱に変わる |η|：H {thr['H']:.3f} V, D {thr['D']:.3f} V（差 {1000*(thr['D']-thr['H']):.0f} mV、零点エネルギーによる）")
e = np.round(np.arange(0.02, 0.601, 0.005), 3)
p = dict(dE0_alk=0.20, f0_alk=1.0, f1_alk=0.0, dc_alk=0.5, sig_alk=0.003)
show = [0.10, 0.15, 0.18, 0.20, 0.22, 0.25, 0.30, 0.35, 0.40, 0.50]
print("   λ(eV) iso  α at |η| = " + " ".join("%.2f" % s for s in show) + "   | α が最初に 0.5 を切る |η|")
for lam in (0.6, 0.3, 0.1, 0.03, 0.01):
    mh = MHC(lam)
    for iso in "HD":
        _, a = M.lnj_alpha(iso, "alk", e, p, mh)
        idx = [int(np.argmin(np.abs(e - s))) for s in show]
        cross = e[np.argmax(a < 0.5)] if (a < 0.5).any() else np.nan
        print(f"   {lam:5.2f}  {iso}   " + " ".join("%.2f" % a[i] for i in idx) + f"   | {cross:.3f}")

print("\n(4) 実測から：隣り合う点の傾き dα/d|η| と、それを許す λ の上限（f = 1 のとき λ ≤ 1/(2|傾き|)）")
for key, (et, al) in OBS.items():
    et, al = np.array(et), np.array(al)
    s = np.diff(al) / np.diff(et)
    i = int(np.argmin(s))
    print(f"   {key[0]}-{key[1]:4s}: 傾き " + " ".join("%+.2f" % v for v in s)
          + f"  | 最も負 {s[i]:+.2f} V⁻¹（{et[i]:.2f}–{et[i+1]:.2f} V）→ λ ≤ {1/(2*abs(s[i])) if s[i]<0 else np.inf:.3f} f² eV")
