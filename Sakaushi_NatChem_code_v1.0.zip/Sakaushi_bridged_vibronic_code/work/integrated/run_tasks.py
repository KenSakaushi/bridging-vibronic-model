"""doc 47: runs the fits of calculations 1, 3 and 4 in one go. Results in results_47.json.
  T1 : δ_D = Δ_ZPE (16.19 meV), 22 and 28 meV × {per medium (acid, alkaline), joint}, λ = 0.3 eV, Boltzmann P(R)
  T4 : δ_D = 27.97 meV, per medium, λ = 0.3 eV. Base model and the ablations 4a–4d
  T3 : δ_D = 27.97 meV, per medium. 3a (P = δ(d − d*), f = f0, A = 1) and 3b (Boltzmann, f1 = 0, A = 1) are fitted on
       the λ grid (LAMGRID) and then refined from the two best grid points with λ free (lower bound 0.05 eV).
Random seeds follow the rule of doc 45 (fit_b.py); the doc 45 optima (W45) are added as warm starts.
Source of numbers: [fit]"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys                                            # noqa: E402
import json                                           # noqa: E402
import time                                           # noqa: E402
import multiprocessing as mp                          # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from model_ext import run_fit, refine_free, DDG_ADS, LAMGRID      # noqa: E402

OUT = os.path.join(HERE, "results_47.json")
W45 = {"acid": dict(dE0_acid=0.21355, f0_acid=0.99999, f1_acid=0.28213),
       "alk": dict(dE0_alk=0.61222, f0_alk=0.60914, f1_alk=1.17208),
       "joint": dict(dE0_acid=0.18177, dE0_alk=0.59424, f0_acid=0.99999, f0_alk=0.66880, f1=0.68060)}
SEED = {"acid": 2255, "alk": 2425, "joint": 2085}


def names3(med):
    return [f"dE0_{med}", f"f0_{med}", f"f1_{med}"]


def warm_delta(med):
    w = W45[med]
    return [{f"dE0_{med}": w[f"dE0_{med}"], f"f0_{med}": min(w[f"f0_{med}"], 0.999), f"dstar_{med}": ds}
            for ds in (0.2, 0.4, 0.6, 0.8)]


def configs():
    C = []
    # ---- task 1 ----
    for dD, lab in ((None, "zpe"), (0.022, "22"), (0.028, "28")):
        for med in ("acid", "alk"):
            C.append(dict(tag=f"T1|dD={lab}|{med}", model=dict(delta_D=dD), meds=[med], names=names3(med),
                          lam=0.3, nstart=16, seed=SEED[med], warm=[W45[med]]))
        C.append(dict(tag=f"T1|dD={lab}|joint", model=dict(delta_D=dD), meds=["acid", "alk"],
                      names=["dE0_acid", "dE0_alk", "f0_acid", "f0_alk", "f1"], lam=0.3, nstart=16,
                      seed=SEED["joint"], warm=[W45["joint"]]))
    # ---- task 4 (base model and 4a–4d) ----
    for med in ("acid", "alk"):
        C.append(dict(tag=f"T4|base|{med}", model=dict(delta_D=DDG_ADS), meds=[med], names=names3(med),
                      lam=0.3, nstart=16, seed=SEED[med], warm=[W45[med]]))
        C.append(dict(tag=f"T4|4a|{med}", model=dict(delta_D=DDG_ADS, ladder="00"), meds=[med], names=names3(med),
                      lam=0.3, nstart=16, seed=SEED[med] + 1, warm=[W45[med]]))
        C.append(dict(tag=f"T4|4b|{med}", model=dict(delta_D=DDG_ADS, dist="delta"), meds=[med],
                      names=[f"dE0_{med}", f"f0_{med}", f"dstar_{med}"], fixed={f"f1_{med}": 0.0},
                      lam=0.3, nstart=32, seed=SEED[med] + 2, warm=warm_delta(med)))
        C.append(dict(tag=f"T4|4c|{med}", model=dict(delta_D=DDG_ADS), meds=[med],
                      names=[f"dE0_{med}", f"f0_{med}"], fixed={f"f1_{med}": 0.0},
                      lam=0.3, nstart=16, seed=SEED[med] + 3, warm=[W45[med]]))
    C.append(dict(tag="T4|4d|acid", model=dict(delta_D=DDG_ADS, A_acid=False), meds=["acid"], names=names3("acid"),
                  lam=0.3, nstart=16, seed=SEED["acid"] + 4, warm=[W45["acid"]]))
    # ---- task 3 (λ grid) ----
    for i, lam in enumerate(LAMGRID):
        for med in ("acid", "alk"):
            C.append(dict(tag=f"T3|3a|{med}|lam={lam}", model=dict(delta_D=DDG_ADS, dist="delta", A_acid=False),
                          meds=[med], names=[f"dE0_{med}", f"f0_{med}", f"dstar_{med}"], fixed={f"f1_{med}": 0.0},
                          lam=lam, nstart=32, seed=5000 + 31 * i + (0 if med == "acid" else 7), warm=warm_delta(med)))
            C.append(dict(tag=f"T3|3b|{med}|lam={lam}", model=dict(delta_D=DDG_ADS, A_acid=False),
                          meds=[med], names=[f"dE0_{med}", f"f0_{med}"], fixed={f"f1_{med}": 0.0},
                          lam=lam, nstart=16, seed=6000 + 31 * i + (0 if med == "acid" else 7), warm=[W45[med]]))
    return C


def work(cfg):
    try:
        return run_fit(cfg)
    except Exception as ex:                          # failures are recorded too
        return dict(tag=cfg["tag"], error=repr(ex))


def work_free(args):
    cfg, grid = args
    try:
        return refine_free(cfg, grid)
    except Exception as ex:
        return dict(tag=cfg["tag"], error=repr(ex))


def log(r):
    if "error" in r:
        print(f"{r['tag']}: ERROR {r['error']}", flush=True)
        return
    print(f"{r['tag']:28s} rms {r['rms']:.4f} " + " ".join(f"{k} {v['rms']:.3f}" for k, v in r["per"].items())
          + f"  λ {r['lam']:.3f}  p " + " ".join(f"{n}={v:.3f}" for n, v in zip(r["names"], r["x"]))
          + f"  bound {r['at_bound']}  {r['sec']} s", flush=True)


if __name__ == "__main__":
    t0 = time.time()
    C = configs()
    out = []
    with mp.Pool(os.cpu_count()) as pool:
        for r in pool.imap_unordered(work, C):
            out.append(r)
            log(r)
            json.dump(out, open(OUT, "w"), indent=1, default=float)
        # λ free (task 3)
        jobs = []
        for var in ("3a", "3b"):
            for med in ("acid", "alk"):
                grid = [r for r in out if r["tag"].startswith(f"T3|{var}|{med}|lam=") and "error" not in r]
                base = [c for c in C if c["tag"] == f"T3|{var}|{med}|lam=0.3"][0]
                cfg = dict(base, tag=f"T3|{var}|{med}|lam=grid")
                jobs.append((cfg, grid))
        for r in pool.imap_unordered(work_free, jobs):
            out.append(r)
            log(r)
            json.dump(out, open(OUT, "w"), indent=1, default=float)
    print(f"DONE {time.time() - t0:.0f} s", flush=True)
