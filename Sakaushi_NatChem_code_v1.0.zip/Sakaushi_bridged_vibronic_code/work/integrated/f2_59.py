"""F2: doc 49 decomposition (M0-M3) redone at the refitted acid parameters (set new, lambda = 0.3). [model calculation]"""
import json, numpy as np
from acid59_model import *

F1 = json.load(open("f1_59.json"))
M = ModelX(delta_D=DDG_ADS)
mhc = get_mhc(0.3)
out = {}
for s in ("old", "new", "trim"):
    p = F1[s]["p"]
    pb = {"lam": 0.3, "dE0_acid": p["dE0_acid"], "f0_acid": p["f0_acid"], "f1_acid": p["f1_acid"]}
    dH, _ = rstar(M, "H", [0.184], pb, mhc); dD, _ = rstar(M, "D", [0.184], pb, mhc)
    res = {}
    for win in ((0.12, 0.248), (0.09, 0.297)):
        g = np.linspace(*win, 41)
        def dA(ladder, dh, dd):
            Mx = ModelX(delta_D=DDG_ADS, ladder=ladder, dist="delta", A_acid=False)
            aw = {}
            for iso, ds in (("H", dh), ("D", dd)):
                q = {"dE0_acid": pb["dE0_acid"], "f0_acid": 1.0, "f1_acid": 0.0, "dstar_acid": ds}
                lj, _ = Mx.lnj_alpha(iso, "acid", g, q, mhc)
                aw[iso] = KT * np.polyfit(g, lj, 1)[0]
            return aw["H"] - aw["D"]
        m = [dA("00", 0.5, 0.5), dA("00", dH[0], dD[0]), dA("full", dH[0], dD[0]), dalpha_win(M, pb, mhc, *win)[0]]
        steps = [m[0], m[1] - m[0], m[2] - m[1], m[3] - m[2]]
        res[f"{win[0]}-{win[1]}"] = dict(M=m, steps=steps, frac=[v / m[3] for v in steps])
    # effective offset of the ground channel at <d> (eta = 0)
    Mx = ModelX(delta_D=DDG_ADS, ladder="00", dist="delta", A_acid=False)
    GH, _ = Mx.at("H", dH[0]); GD, _ = Mx.at("D", dD[0])
    G5H, _ = Mx.at("H", 0.5)
    deff = float(GD[0, 0] - GH[0, 0])
    out[s] = dict(dH=float(dH[0]), dD=float(dD[0]), delta_eff=deff, GH_rel=float(GH[0, 0] - G5H[0, 0]),
                  GD_rel=float(GD[0, 0] - G5H[0, 0]), windows=res)
    print(f"{s:4s} <d>_H {dH[0]:.4f} <d>_D {dD[0]:.4f} | delta_eff {deff*1e3:.1f} meV (dG00 vs d0: H {out[s]['GH_rel']*1e3:+.1f}, D {out[s]['GD_rel']*1e3:+.1f} meV)")
    for w, v in res.items():
        print(f"     window {w}: M0 {v['M'][0]:+.4f} M1 {v['M'][1]:+.4f} M2 {v['M'][2]:+.4f} M3 {v['M'][3]:+.4f} | shares "
              + " ".join(f"{100*x:.0f}%" for x in v['frac']))
json.dump(out, open("f2_59.json", "w"), indent=1, default=float)
