"""doc 59: acid refit with the updated D data (pD 1, 0.0875-0.389 V) and the Limit 1 re-examination.
Uses model_ext.ModelX (doc 47) unchanged: delta_D = 27.97 meV, Boltzmann P(R), mu <= 2, nu <= 7, gamma = 1.0 A^-1,
Delta E_pzc = 0, omega = 2600 cm^-1, D_e = 119 kcal/mol. Only the data sets and the fitting driver are new.
Sources: [fit] [model calculation] [arithmetic]."""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import os
import sys
import json
import time
import numpy as np
from scipy.optimize import least_squares

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from model import MHC, KT, OBS as OBS47                     # noqa: E402
from model_ext import ModelX, DDG_ADS, info                 # noqa: E402

# ---------------------------------------------------------------- data sets  [fit; doc 26, 34, 58]
H_E, H_A = OBS47[("H", "acid")]
D_OLD = OBS47[("D", "acid")]
_upd = json.load(open(_PKG + '/figs/acidD_update.json'))
D_NEW = (list(_upd['cD']), list(_upd['aD']))
D_TRIM = ([e for e in D_NEW[0] if e >= 0.149], [a for e, a in zip(*D_NEW) if e >= 0.149])
SETS = {"old": {"H": (H_E, H_A), "D": D_OLD},
        "new": {"H": (H_E, H_A), "D": D_NEW},
        "trim": {"H": (H_E, H_A), "D": D_TRIM}}
LOGK_OBS = dict(zip(_upd['eg'], _upd['logK']))              # [arith; doc 58]
BND = {"dE0": (-0.6, 1.2), "f0": (0.1, 1.0), "f1": (-2.0, 2.0), "lam": (0.005, 2.0), "ddD": (-0.2, 0.4)}
MED = "acid"


def npts(obs):
    return sum(len(v[0]) for v in obs.values())


_MHC = {}


def get_mhc(lam, dx=0.001):
    key = (round(float(lam), 10), dx)
    if key not in _MHC:
        if len(_MHC) > 30:
            for k in list(_MHC)[:15]:
                _MHC.pop(k)
        _MHC[key] = MHC(key[0], dx=dx)
    return _MHC[key]


def pars(names, x, fixed):
    p = dict(fixed)
    p.update({n: float(v) for n, v in zip(names, x)})
    return p


def pmodel(p, iso):
    """parameters seen by the model for isotope iso (ddD: extra isotope offset for D, diagnostic L3 only)"""
    q = {"dE0_acid": p["dE0_acid"] + (p.get("ddD", 0.0) if iso == "D" else 0.0),
         "f0_acid": p["f0_acid"], "f1_acid": p.get("f1_acid", 0.0)}
    return q


def model_alpha(M, iso, e, p, mhc, mode="point"):
    q = pmodel(p, iso)
    e = np.atleast_1d(np.asarray(e, float))
    if mode == "point":
        return M.lnj_alpha(iso, MED, e, q, mhc)[1]
    out = []                                                   # 40 mV window, as for the data
    for c in e:
        g = np.linspace(c - 0.02, c + 0.02, 9)
        lj, _ = M.lnj_alpha(iso, MED, g, q, mhc)
        out.append(KT * np.polyfit(g, lj, 1)[0])
    return np.array(out)


def lnj(M, iso, e, p, mhc):
    return M.lnj_alpha(iso, MED, np.atleast_1d(np.asarray(e, float)), pmodel(p, iso), mhc)[0]


def residuals(M, obs, names, fixed, x, mode="point"):
    p = pars(names, x, fixed)
    mhc = get_mhc(p["lam"])
    r = []
    for iso in ("H", "D"):
        e, a = obs[iso]
        r.extend(model_alpha(M, iso, e, p, mhc, mode) - np.array(a))
    return np.array(r)


def fit(obs, names, fixed, M=None, nstart=32, seed=0, warm=(), mode="point", max_nfev=200):
    t0 = time.time()
    M = M or ModelX(delta_D=DDG_ADS)
    lo = np.array([BND[n.split("_")[0]][0] for n in names])
    hi = np.array([BND[n.split("_")[0]][1] for n in names])
    rng = np.random.default_rng(seed)
    starts = [lo + (hi - lo) * rng.random(len(lo)) for _ in range(nstart)]
    for w in warm:
        if all(n in w for n in names):
            starts.append(np.clip(np.array([w[n] for n in names], float), lo + 1e-9, hi - 1e-9))
    sols = []
    for x0 in starts:
        try:
            s = least_squares(lambda x: residuals(M, obs, names, fixed, x, mode), x0, bounds=(lo, hi),
                              x_scale="jac", max_nfev=max_nfev)
        except Exception:
            continue
        sols.append(s)
    best = min(sols, key=lambda s: s.cost)
    nconv = sum(1 for s in sols if np.sqrt(2 * s.cost / len(s.fun)) - np.sqrt(2 * best.cost / len(best.fun)) < 5e-4)
    p = pars(names, best.x, fixed)
    at_b = [n for n, v, l, h in zip(names, best.x, lo, hi) if min(v - l, h - v) < 1e-3 * (h - l)]
    res = residuals(M, obs, names, fixed, best.x, mode)
    nH = len(obs["H"][0])
    rss = float((res ** 2).sum())
    n, k = len(res), len(names)
    aicc, bic = info(rss, n, k)
    return dict(names=names, x=[float(v) for v in best.x], p=p, at_bound=at_b, rms=float(np.sqrt(np.mean(res ** 2))),
                rmsH=float(np.sqrt(np.mean(res[:nH] ** 2))), rmsD=float(np.sqrt(np.mean(res[nH:] ** 2))),
                res=[float(v) for v in res], rss=rss, n=n, k=k, AICc=aicc, BIC=bic, nconv=f"{nconv}/{len(sols)}",
                mode=mode, sec=round(time.time() - t0, 1))


def dalpha_win(M, p, mhc, lo, hi):
    g = np.linspace(lo, hi, 41)
    aw = {iso: KT * np.polyfit(g, lnj(M, iso, g, p, mhc), 1)[0] for iso in "HD"}
    return float(aw["H"] - aw["D"]), (float(aw["H"]), float(aw["D"]))


def rstar(M, iso, e, p, mhc):
    _, _, w = M.lnj_alpha(iso, MED, np.atleast_1d(e), pmodel(p, iso), mhc, detail=True)
    return (w.sum(axis=(2, 3)) * M.d[None, :]).sum(1), w


def features(M, p, mhc):
    r = {}
    r["dA_old"], r["aw_old"] = dalpha_win(M, p, mhc, 0.12, 0.248)
    r["dA_full"], r["aw_full"] = dalpha_win(M, p, mhc, 0.09, 0.297)
    ek = [0.09, 0.13, 0.15, 0.21, 0.245, 0.25, 0.27, 0.29, 0.31, 0.33, 0.35]
    lk = (lnj(M, "H", ek, p, mhc) - lnj(M, "D", ek, p, mhc)) / np.log(10)
    r["logK"] = dict(zip(ek, [float(v) for v in lk]))
    g = np.round(np.arange(0.05, 0.4001, 0.0025), 4)
    lkg = (lnj(M, "H", g, p, mhc) - lnj(M, "D", g, p, mhc)) / np.log(10)
    cr = [float(g[i] + (g[i + 1] - g[i]) * lkg[i] / (lkg[i] - lkg[i + 1])) for i in range(len(g) - 1)
          if lkg[i] > 0 >= lkg[i + 1]]
    r["K1_cross"] = cr[0] if cr else None
    r["logK_min"] = float(lkg.min())
    curves = {}
    for iso in "HD":
        a = model_alpha(M, iso, g, p, mhc)
        s = np.gradient(a, g)
        curves[iso] = a
        r[f"a_{iso}_peak"] = (float(a[g >= 0.10].max()), float(g[g >= 0.10][np.argmax(a[g >= 0.10])]))
        r[f"slope_{iso}_min"] = (float(s.min()), float(g[np.argmin(s)]))
        r[f"a_{iso}_at"] = {e: float(np.interp(e, g, a)) for e in (0.09, 0.15, 0.21, 0.25, 0.27, 0.29, 0.31, 0.35)}
    r["curve"] = dict(g=g.tolist(), H=curves["H"].round(5).tolist(), D=curves["D"].round(5).tolist(),
                      logK=lkg.round(5).tolist())
    for iso in "HD":
        d, w = rstar(M, iso, [0.12, 0.184, 0.248, 0.30, 0.35], p, mhc)
        r[f"d_{iso}"] = [float(v) for v in d]
        r[f"mu1_{iso}"] = [float(v) for v in w[:, :, 1:, :].sum(axis=(1, 2, 3))]      # mu >= 1 fraction
        r[f"nu1_{iso}"] = [float(v) for v in w[:, :, :, 1:].sum(axis=(1, 2, 3))]      # nu >= 1 fraction
    fg = M.f_of(pmodel(p, "H"), MED)
    r["f_at_d"] = {iso: float(np.interp(r[f"d_{iso}"][1], M.d, fg)) for iso in "HD"}
    return r


def point_vs_window(M, obs, p, mhc):
    out = {}
    for iso in "HD":
        e, _ = obs[iso]
        out[iso] = float(np.abs(model_alpha(M, iso, e, p, mhc, "point") - model_alpha(M, iso, e, p, mhc, "window")).max())
    return out


def curvature_split(M, iso, e, p, mhc):
    """d alpha/d|eta| = Var_p(alpha_c)/kT (handover) + sum_c p_c f_c^2 kT (ln F)''(G_c) (within channels).
    Returns (total, handover, within, finite-difference check)."""
    q = pmodel(p, iso)
    c = M.ch[iso]
    G0, lnW = c["G"], c["lnWc"] + M.lnw[:, None, None]
    f = M.f_of(q, MED)
    a = (1.0 - f) if M.A_acid else np.zeros_like(f)
    G = q["dE0_acid"] + G0 - f[:, None, None] * e
    lnF = np.interp(G, mhc.x, mhc.lnF)
    dlnF = np.interp(G, mhc.x, mhc.dlnF)
    d2 = np.interp(G, mhc.x, np.gradient(mhc.dlnF, mhc.dx))
    lnjc = lnW + M.lnPB[iso][:, None, None] + (a * e / KT)[:, None, None] + lnF
    w = np.exp(lnjc - lnjc.max()); w /= w.sum()
    ac = a[:, None, None] + f[:, None, None] * (-KT * dlnF)
    al = (w * ac).sum()
    hand = (w * (ac - al) ** 2).sum() / KT
    within = (w * (f[:, None, None] ** 2) * KT * d2).sum()
    h = 1e-3
    fd = (model_alpha(M, iso, e + h, p, mhc)[0] - model_alpha(M, iso, e - h, p, mhc)[0]) / (2 * h)
    return float(hand + within), float(hand), float(within), float(fd)
