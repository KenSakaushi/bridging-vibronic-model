"""Preparation of the integrated model: with the same proton potentials as (2) (O–H and Au–H Morse + the non-bonded
terms of stage 3a), computes the eigenlevels εR_μ(R), εP_ν(R) and overlaps S_μν(R) on a grid of d_tunn (using the
existing stage3a/stage1 code). Printed labels are in Japanese (the author's working language).

Output levels.npz
  d            : d_tunn = R − r_AH − r_MH [Å]
  eR_H, eP_H   : reactant and product eigenvalues [eV] (absolute, not from the bottom of the well; zero-point
                 energies and non-bonded terms included)
  S_H          : S[k, μ, ν] = <χR_μ | χP_ν>
  (likewise for D)
Source of numbers: [model calculation]
"""
import os
import sys
import time
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "stage3a_R_integral"))
sys.path.insert(0, os.path.join(HERE, "..", "stage1_morse_overlap"))
from proton_potentials import ProtonPotentials          # noqa: E402

EV = 23.060548          # kcal/mol per eV


def main(d0=0.12, d1=1.32, dd=0.01, n_states=10):
    pot = ProtonPotentials(n_states=n_states)
    d = np.round(np.arange(d0, d1 + dd / 2, dd), 4)
    out = {"d": d}
    t0 = time.time()
    for iso in ("H", "D"):
        eR = np.zeros((len(d), n_states))
        eP = np.zeros_like(eR)
        S = np.zeros((len(d), n_states, n_states))
        for k, dk in enumerate(d):
            er, ep, s = pot.solve(iso, pot.R_of_d(float(dk)))
            eR[k], eP[k], S[k] = er / EV, ep / EV, s
        out["eR_" + iso], out["eP_" + iso], out["S_" + iso] = eR, eP, S
        print(f"{iso}: {len(d)} points, {time.time() - t0:.0f} s", flush=True)
    np.savez(os.path.join(HERE, "levels.npz"), **out)

    # summary (for doc 43)
    k0 = int(np.argmin(np.abs(d - 0.5)))
    print("\n[d = 0.50 Å, R = %.3f Å] 絶対準位 (eV)" % pot.R_of_d(0.5))
    for iso in ("H", "D"):
        print(f"  {iso}: εR0 {out['eR_'+iso][k0,0]:.4f}  εR1−εR0 {out['eR_'+iso][k0,1]-out['eR_'+iso][k0,0]:.4f}"
              f"  εP0 {out['eP_'+iso][k0,0]:.4f}  εP1−εP0 {out['eP_'+iso][k0,1]-out['eP_'+iso][k0,0]:.4f}")
    sh = ((out["eP_D"][k0, 0] - out["eR_D"][k0, 0]) - (out["eP_H"][k0, 0] - out["eR_H"][k0, 0]))
    print(f"  零点エネルギーによる (0,0) の ΔG のずれ D−H = {sh*1000:.1f} meV ({sh*EV:.3f} kcal/mol)")
    print("\n  d(Å)  |S00|²_H     |S00|²_D     κ_H(1/Å) κ_D(1/Å)  2(κD−κH)")
    for dk in (0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.2):
        k = int(np.argmin(np.abs(d - dk)))
        s2 = {i: out["S_" + i][:, 0, 0] ** 2 for i in "HD"}
        kap = {i: -0.5 * np.gradient(np.log(s2[i]), d)[k] for i in "HD"}
        print(f"  {dk:.2f}  {s2['H'][k]:.3e}  {s2['D'][k]:.3e}  {kap['H']:7.2f}  {kap['D']:7.2f}  {2*(kap['D']-kap['H']):7.2f}")
    for iso in "HD":
        g = out["eP_" + iso][:, 0] - out["eR_" + iso][:, 0]
        print(f"  {iso}: εP0−εR0 at d=0.12/0.30/0.50/0.80/1.20: "
              + " ".join("%.3f" % g[int(np.argmin(np.abs(d - x)))] for x in (0.12, 0.3, 0.5, 0.8, 1.2)) + " eV")


if __name__ == "__main__":
    main()
