"""Integrated model ((1) Marcus type + (2) Bockris-Matthews (B-M) + (3) DKL/vibronic)

Based on the vibronic rate expression of (3):

  j_i^m(η) = Σ_μν ∫dR P(R) A_m(R,η) P_μ^i(R) |V_el(R)|² |S_μν^i(R)|² F_λ(ΔG_μν^i(R,η))

  From (2): the proton potentials (O–H and Au–H Morse + non-bonded terms, stage 3a). The levels ε and overlaps S are
            those computed by levels.py with the existing code; zero-point energies and the thresholds where levels
            cross enter automatically.
  From (1): F_λ is the MHC kernel (with the Fermi integral)
            F_λ(x) = ∫dε f_FD(ε) (4πλkT)^(-1/2) exp[−(x + λ − ε)²/(4λkT)]
  From (3): the sum over channels (R, μ, ν) and the distance distribution P(R)

  ΔG_μν^i(R,η) = ΔE0_m + [εP_ν^i(R) − εR_μ^i(R)] − [εP_0^H(R0) − εR_0^H(R0)] − f_m(R) e|η|
      ΔE0_m is the reaction free energy of the H (0,0) channel at R0 (d0 = 0.5 Å) and η = 0 in medium m.
  f_m(R) = f0_m + f1_m (d − d0) (clipped to [0, 1]): fraction of the potential drop up to the donor (Stern layer).
  Work terms w (set by the donor; point-charge electrostatics):
      acid    : H3O+ at position R. Initial-state work W_a = −(1 − f(R)) e|η|.
                Population factor A_acid = exp[−W_a/kT] = exp[(1 − f(R)) e|η|/kT] (accumulation of H3O+); −W_a enters ΔG.
      alkaline: H2O is neutral (A_alk = 1). The work of the product OH−, W_P = +(1 − f(R)) e|η|, enters ΔG.
      In both media the potential dependence of ΔG is −e|η| + (1 − f)e|η| = −f(R) e|η|, as in the expression above.
      R-dependent chemical work (non-bonded repulsion and the R dependence of the zero-point energies) is in ε(R).
  P(R) ∝ exp[−(d − d_c)²/(2σ²)], d ∈ [0.12, 1.32] Å (lower end in place of the steric wall). This Gaussian is the
      option dist="gauss"; the paper uses dist="boltz" (the Boltzmann distribution described in Model.__init__).
  P_μ^i(R): Boltzmann distribution over the vibrational levels of the reactant
  |V_el(R)|² ∝ exp[−β_el (d − d0)], β_el = 1 Å⁻¹ (the stage 3a default)

Apparent transfer coefficient (doc 40): α = kT ∂ln j/∂(e|η|) = Σ_c p_c α_c,
      α_c = a_c + f_c·β_c, β_c = −kT ∂lnF/∂x (channel symmetry factor), a_c = 1 − f (acid) or 0 (alkaline).
Units: eV, Å. T = 298.15 K.
"""
import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
KT = 8.617333262e-5 * 298.15          # eV

# Measured local α [fit; doc 26, 27, 34]. The acid D entry is an earlier 4-point set; the hydronium fits reported in
# the paper use the 13-point set in figs/acidD_update.json (work/integrated/acid59_model.py).
OBS = {("H", "alk"): ([0.29, 0.33, 0.37, 0.41, 0.45], [0.592, 0.583, 0.587, 0.604, 0.624]),
       ("D", "alk"): ([0.28, 0.32, 0.40, 0.44, 0.48, 0.52, 0.56],
                      [0.464, 0.475, 0.472, 0.466, 0.437, 0.412, 0.386]),
       ("H", "acid"): ([0.09, 0.11, 0.13, 0.15, 0.17, 0.19, 0.21, 0.23, 0.25, 0.27],
                       [0.789, 0.753, 0.690, 0.620, 0.548, 0.491, 0.442, 0.413, 0.401, 0.397]),
       ("D", "acid"): ([0.16, 0.18, 0.20, 0.22], [0.730, 0.737, 0.730, 0.731])}
WIN = {"acid": (0.12, 0.248), "alk": (0.30, 0.48)}        # common windows for Δα (earlier choice; the alkaline window of the paper, 0.2496–0.4786 V, is used in work/winD/recalc_winD.py)
DA_OBS = {"acid": -0.20, "alk": +0.11}
LKIE_OBS = {"acid": ([0.13, 0.16, 0.19, 0.22, 0.245], [0.46, 0.46, 0.36, 0.22, 0.07]),
            "alk": ([0.30, 0.48], [1.26, 1.58])}


class MHC:
    """MHC kernel of (1): tabulates ln F and d lnF/dx on a grid of x = ΔG [eV] (ε integral in log space)."""

    def __init__(self, lam, xmin=-3.0, xmax=3.5, dx=0.001):
        self.lam = lam
        x = np.arange(xmin, xmax + dx / 2, dx)
        s2 = 2.0 * lam * KT
        s = np.sqrt(s2)
        L = 2.0 * lam + 12.0 * s
        dz = min(s / 12.0, KT / 6.0)
        z = np.arange(-L, L + dz / 2, dz)
        lnG = -z ** 2 / (2 * s2) - 0.5 * np.log(2 * np.pi * s2) + np.log(dz)
        out = np.empty_like(x)
        for i in range(0, len(x), 400):
            eps = x[i:i + 400, None] + lam + z[None, :]
            a = lnG[None, :] - np.logaddexp(0.0, eps / KT)
            m = a.max(1)
            out[i:i + 400] = m + np.log(np.exp(a - m[:, None]).sum(1))
        self.x, self.dx, self.lnF = x, dx, out
        self.dlnF = np.gradient(out, dx)

    def __call__(self, g):
        return np.interp(g, self.x, self.lnF), np.interp(g, self.x, self.dlnF)


class Model:
    def __init__(self, lev=None, mu_max=3, nu_max=8, d0=0.5, beta_el=1.0, dist="gauss"):
        z = np.load(lev or os.path.join(HERE, "levels.npz"))
        self.d = z["d"]
        self.d0 = d0
        self.dist = dist
        self.lnPB = None
        if dist == "boltz":
            # doc 45: Boltzmann distribution of stage 3a (SI eq 38), P^i(R) ∝ exp[−W_a^i(R)/kT], W_a = E_a0(R) − E_a0(∞).
            # E_a0(R) is the reactant ground level, including the Au–O Buckingham term (repulsive wall + dispersion)
            # and the Au–H non-bonded term. No free parameters (d_c and σ are not used).
            import sys
            sys.path.insert(0, os.path.join(HERE, "..", "stage3a_R_integral"))
            sys.path.insert(0, os.path.join(HERE, "..", "stage1_morse_overlap"))
            from proton_potentials import ProtonPotentials
            pot = ProtonPotentials()
            self.Wa = {iso: z["eR_" + iso][:, 0] - pot.E_a0_inf(iso) / 23.060548 for iso in ("H", "D")}
            self.lnPB = {iso: -self.Wa[iso] / KT for iso in ("H", "D")}
        k0 = int(np.argmin(np.abs(self.d - d0)))
        self.Eref = float(z["eP_H"][k0, 0] - z["eR_H"][k0, 0])
        h = np.diff(self.d)
        w = np.zeros(len(self.d))
        w[:-1] += h / 2
        w[1:] += h / 2
        self.ch = {}
        for iso in ("H", "D"):
            eRall = z["eR_" + iso]
            eR = eRall[:, :mu_max]
            eP = z["eP_" + iso][:, :nu_max]
            S = z["S_" + iso][:, :mu_max, :nu_max]
            G = eP[:, None, :] - eR[:, :, None] - self.Eref                  # (nd, μ, ν)
            lnPmu = (-(eR - eRall[:, :1]) / KT
                     - np.log(np.exp(-(eRall - eRall[:, :1]) / KT).sum(1))[:, None])
            lnW = (np.log(np.maximum(S ** 2, 1e-300)) + lnPmu[:, :, None]
                   + (-beta_el * (self.d - d0) + np.log(w))[:, None, None])
            self.ch[iso] = (G, lnW)

    def f_of(self, p, med):
        return np.clip(p["f0_" + med] + p["f1_" + med] * (self.d - self.d0), 0.0, 1.0)

    def lnj_alpha(self, iso, med, eta, p, mhc, detail=False):
        G0, lnW = self.ch[iso]
        eta = np.atleast_1d(np.asarray(eta, dtype=float))
        f = self.f_of(p, med)
        if self.lnPB is not None:
            lnP = self.lnPB[iso]
        else:
            lnP = -(self.d - p["dc_" + med]) ** 2 / (2.0 * p["sig_" + med] ** 2)
        a = (1.0 - f) if med == "acid" else np.zeros_like(f)
        G = p["dE0_" + med] + G0[None] - f[None, :, None, None] * eta[:, None, None, None]
        lnF, dlnF = mhc(G)
        lnjc = (lnW[None] + lnP[None, :, None, None]
                + (a[None, :] * eta[:, None] / KT)[:, :, None, None] + lnF)
        m = lnjc.max(axis=(1, 2, 3), keepdims=True)
        wgt = np.exp(lnjc - m)
        J = wgt.sum(axis=(1, 2, 3))
        ac = a[None, :, None, None] + f[None, :, None, None] * (-KT * dlnF)
        alpha = (wgt * ac).sum(axis=(1, 2, 3)) / J
        lnj = m[:, 0, 0, 0] + np.log(J)
        if detail:
            return lnj, alpha, wgt / J[:, None, None, None]
        return lnj, alpha

    def alpha_win(self, iso, med, etas, p, mhc, half=0.02, n=9):
        """As for the measurements: α from the slope of a straight-line fit of ln j within a window of width 2·half."""
        out = []
        for e in np.atleast_1d(etas):
            g = np.linspace(e - half, e + half, n)
            lj, _ = self.lnj_alpha(iso, med, g, p, mhc)
            out.append(KT * np.polyfit(g, lj, 1)[0])
        return np.array(out)

    def Rstar(self, iso, med, etas, p, mhc):
        """Current-weighted mean distance <d> (Å)."""
        _, _, w = self.lnj_alpha(iso, med, etas, p, mhc, detail=True)
        return (w.sum(axis=(2, 3)) * self.d[None, :]).sum(1)


def features(M, p, mhc):
    """Evaluates the four features and log KIE."""
    r = {}
    for med in ("acid", "alk"):
        a, b = WIN[med]
        g = np.linspace(a, b, 41)
        aw = {}
        for iso in "HD":
            lj, _ = M.lnj_alpha(iso, med, g, p, mhc)
            aw[iso] = KT * np.polyfit(g, lj, 1)[0]
        r["dA_" + med] = aw["H"] - aw["D"]
        r["aw_" + med] = (aw["H"], aw["D"])
        e, _ = LKIE_OBS[med]
        lh, _ = M.lnj_alpha("H", med, e, p, mhc)
        ld, _ = M.lnj_alpha("D", med, e, p, mhc)
        r["lkie_" + med] = list((lh - ld) / np.log(10))
        r["Rstar_" + med] = {iso: list(M.Rstar(iso, med, [a, b], p, mhc)) for iso in "HD"}
    _, aD = M.lnj_alpha("D", "acid", [0.16, 0.18, 0.20, 0.22], p, mhc)
    r["acidD_mean"], r["acidD_range"] = float(aD.mean()), float(aD.max() - aD.min())
    _, aH = M.lnj_alpha("H", "acid", [0.09, 0.27], p, mhc)
    r["acidH_ends"] = (float(aH[0]), float(aH[1]))
    for iso in "HD":
        e, _ = OBS[(iso, "alk")]
        _, am = M.lnj_alpha(iso, "alk", e, p, mhc)
        r["c2_alk_" + iso] = float(np.polyfit(e, am, 2)[0])
    return r


def obs_c2():
    return {iso: float(np.polyfit(*OBS[(iso, "alk")], 2)[0]) for iso in "HD"}
