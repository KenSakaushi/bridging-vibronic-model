"""Preparation for doc 45: extends levels.npz to d = 0.00–0.11 Å to make levels_ext.npz (so that the grid reaches
the region where the Au–O wall acts; done only if levels_ext.npz is absent), and checks the shape of the Boltzmann
distribution P(R) of stage 3a and the contribution of the ends of the grid. [model calculation]
Printed labels are in Japanese (the author's working language)."""
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "stage3a_R_integral"))
sys.path.insert(0, os.path.join(HERE, "..", "stage1_morse_overlap"))
from proton_potentials import ProtonPotentials, buck      # noqa: E402

EV = 23.060548
ext = os.path.join(HERE, "levels_ext.npz")
if not os.path.exists(ext):
    z = dict(np.load(os.path.join(HERE, "levels.npz")))
    pot = ProtonPotentials(n_states=10)
    dn = np.round(np.arange(0.0, 0.1101, 0.01), 4)
    out = {"d": np.concatenate([dn, z["d"]])}
    for iso in "HD":
        eR, eP, S = [], [], []
        for dk in dn:
            er, ep, s = pot.solve(iso, pot.R_of_d(float(dk)))
            eR.append(er / EV); eP.append(ep / EV); S.append(s)
        out["eR_" + iso] = np.concatenate([np.array(eR), z["eR_" + iso]])
        out["eP_" + iso] = np.concatenate([np.array(eP), z["eP_" + iso]])
        out["S_" + iso] = np.concatenate([np.array(S), z["S_" + iso]])
    np.savez(ext, **out)

from model import Model, MHC, KT                          # noqa: E402
M = Model(lev=ext, dist="boltz")
pot = ProtonPotentials()
print("W_a(d) = E_a0(R) − E_a0(∞) [eV]（段階 3a）と、その中の Au–O の Buckingham 項 V_AuO(R)")
print("   d(Å)  R(Å)   V_AuO    W_a^H    W_a^D   |S00|²_H    |S00|²_D")
z = np.load(ext)
for dk in (0.0, 0.06, 0.12, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.3):
    k = int(np.argmin(np.abs(M.d - dk)))
    R = pot.R_of_d(dk)
    print(f"   {dk:4.2f}  {R:5.3f}  {float(buck(R,'AuO'))/EV:+.4f}  {M.Wa['H'][k]:+.4f}  {M.Wa['D'][k]:+.4f}"
          f"  {z['S_H'][k,0,0]**2:.3e}  {z['S_D'][k,0,0]**2:.3e}")
i = int(np.argmin(M.Wa["H"]))
print(f"   W_a^H の最小：d = {M.d[i]:.2f} Å（R = {pot.R_of_d(M.d[i]):.2f} Å）、{M.Wa['H'][i]:+.4f} eV（格子の上端 1.32 Å までで）")

# with representative parameters (per-medium f and ΔE0 of doc 43 at λ = 0.3): distance distribution of the current and
# the contribution of the ends of the grid
p = dict(dE0_alk=0.614, f0_alk=0.617, f1_alk=1.065, dE0_acid=0.219, f0_acid=1.0, f1_acid=1.057)
mhc = MHC(0.3)
print("\n電流で重みづけた距離の分布（λ = 0.3、doc 43 の媒質別の ΔE0・f を流用）")
for med, etas in (("alk", (0.30, 0.48)), ("acid", (0.12, 0.25))):
    for iso in "HD":
        _, a, w = M.lnj_alpha(iso, med, list(etas), p, mhc, detail=True)
        wd = w.sum(axis=(2, 3))
        for j, e in enumerate(etas):
            m = (wd[j] * M.d).sum()
            s = np.sqrt((wd[j] * (M.d - m) ** 2).sum())
            print(f"   {med:4s} {iso} |η|={e:.2f}: α {a[j]:.3f}  <d> {m:.3f} Å  幅 {s:.3f} Å  "
                  f"d<0.12 の割合 {wd[j][M.d < 0.115].sum():.1e}  d<0.05 {wd[j][M.d < 0.045].sum():.1e}  d>1.0 {wd[j][M.d > 1.0].sum():.1e}")
