import numpy as np, sys, json, time; sys.path.insert(0,'.'); from bm_vec import *
from scipy.optimize import least_squares
pot=ProtonPotentials(nonbonding=True)
OBS={('H','alk'):([0.29,0.33,0.37,0.41,0.45],[0.592,0.583,0.587,0.604,0.624]),
     ('D','alk'):([0.28,0.32,0.40,0.44,0.48,0.52,0.56],[0.464,0.475,0.472,0.466,0.437,0.412,0.386]),
     ('H','acid'):([0.09,0.11,0.13,0.15,0.17,0.19,0.21,0.23,0.25,0.27],[0.789,0.753,0.690,0.620,0.548,0.491,0.442,0.413,0.401,0.397]),
     ('D','acid'):([0.16,0.18,0.20,0.22],[0.730,0.737,0.730,0.731])}
def res(med,dE0,d):
    R=pot.R_of_d(d); out=[]
    for iso in 'HD':
        e,a=OBS[(iso,med)]; m=alpha_curve(pot,R,dE0,iso,np.array(e)); out+=list(np.nan_to_num(m-np.array(a),nan=1.0))
    return np.array(out)
out={}
for med in ('acid','alk'):
    t=time.time(); best=(1e9,None)
    for dE0 in np.arange(-10,25.1,1.0):
        for d in np.arange(0.30,0.801,0.05):
            r=res(med,dE0,d); c=(r**2).sum()
            if c<best[0]: best=(c,(dE0,d))
    s=least_squares(lambda x: res(med,*x),best[1],bounds=([-15,0.25],[30,0.9]),diff_step=[0.02,0.02])
    r=s.fun; out[med]=dict(dE0=float(s.x[0]),d=float(s.x[1]),rms=float(np.sqrt((r**2).mean())))
    print(f"{med}: grid best dE0={best[1][0]:.1f} d={best[1][1]:.2f}; refined dE0={s.x[0]:.2f} kcal/mol ({s.x[0]/EV:.3f} eV), d={s.x[1]:.3f} A, rms={out[med]['rms']:.3f}  [{time.time()-t:.0f}s]",flush=True)
    R=pot.R_of_d(s.x[1])
    for iso in 'HD':
        e,a=OBS[(iso,med)]; m=alpha_curve(pot,R,s.x[0],iso,np.array(e))
        print(f"   {iso} obs "+" ".join("%.2f"%v for v in a)+"\n     mod "+" ".join("%.2f"%v for v in m))
json.dump(out,open("bm_fit.json","w"))
