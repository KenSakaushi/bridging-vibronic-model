"""Bockris-Matthews (doc 06 construction), vectorised: product Morse displaced by shift = dE0 - e|eta|;
rate ~ thermally averaged Kemble-WKB transmission through min(U_R, U_P+shift). kcal/mol, A."""
import os, sys, numpy as np
H=os.path.dirname(os.path.abspath(__file__))
for p in ("stage3a_R_integral","stage2_vibronic_rate","stage1_morse_overlap","stage6_bep_prl"):
    sys.path.insert(0,os.path.join(H,"..",p))
from proton_potentials import ProtonPotentials
from morse_dvr import hbar2_over_2m, KB_KCAL
from bockris_matthews import crossing, barrier_profile
EV=23.060548; T=298.15; kT=KB_KCAL*T
def kappa(pot,R,shift,iso,n=500):
    c=crossing(pot,R,shift)
    if c is None: return np.nan
    xs_,V1,beta,UR0,dE=c
    V,UR,UP=barrier_profile(pot,R,shift); x=pot.x
    iR,iP=int(np.argmin(UR)),int(np.argmin(UP)); lo,hi=(iP,iR) if iP<iR else (iR,iP)
    seg,xs=V[lo:hi+1],x[lo:hi+1]
    E=np.linspace(0.0,V1+25*kT,n); C=hbar2_over_2m(iso)
    th=2*np.trapezoid(np.sqrt(np.clip(seg[None,:]-(UR0+E[:,None]),0,None)/C),xs,axis=1)
    P=1/(1+np.exp(np.clip(th,-600,600))); P[E<max(dE,0.0)]=0.0
    return float(np.trapezoid(P*np.exp(-E/kT),E)/kT)
def lnk_curve(pot,R,dE0,iso,etas):
    return np.array([np.log(kappa(pot,R,dE0-e*EV,iso)) for e in etas])
def alpha_curve(pot,R,dE0,iso,etas,h=0.005):
    lp=lnk_curve(pot,R,dE0,iso,etas+h); lm=lnk_curve(pot,R,dE0,iso,etas-h)
    return kT*(lp-lm)/(2*h*EV)
