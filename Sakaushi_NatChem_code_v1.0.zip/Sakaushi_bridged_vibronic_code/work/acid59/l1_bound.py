"""L1: curvature bound of the MHC rate function, B(lambda) = max_x [-kT (ln F_lambda)''(x)]  [model calculation]
F(x) = int de f_FD(e) exp[-(lambda + x - e)^2 / (4 lambda kT)]  (x = channel Delta G, eV; cathodic)
Exact identity: -kT (ln F)'' = (1/2lambda) [1 - Var_w(e)/(2 lambda kT)], w(e) ~ f_FD(e) N(e; x + lambda, 2 lambda kT).
Two exact caps: B <= 1/(2 lambda) (Gaussian side) and B <= 1/(4 kT) (Fermi side)."""
import json, numpy as np
from scipy.optimize import brentq, minimize_scalar
KT = 0.025693


def var_w(x, lam, n=40001):
    s = np.sqrt(2 * lam * KT)
    mu = x + lam
    e = np.linspace(mu - 12 * s, mu + 12 * s, n)
    lw = -(e - mu) ** 2 / (2 * s * s) - np.logaddexp(0, e / KT)       # log f_FD + log Gaussian
    w = np.exp(lw - lw.max()); w /= w.sum()
    m = (w * e).sum()
    return (w * (e - m) ** 2).sum()


def curv(x, lam):
    return (1 / (2 * lam)) * (1 - var_w(x, lam) / (2 * lam * KT))


def B(lam):
    # the maximum lies near the point where the Gaussian centre x + lambda sits on the Fermi step (x ~ -lambda);
    # scan coarsely, then refine
    xs = np.linspace(-lam - 0.6, lam + 0.6, 481)          # the curvature is symmetric about x = 0 (detailed balance)
    c = np.array([curv(x, lam) for x in xs])
    i = int(np.argmax(c))
    r = minimize_scalar(lambda x: -curv(x, lam), bounds=(xs[max(i - 1, 0)], xs[min(i + 1, len(xs) - 1)]),
                        method='bounded', options=dict(xatol=1e-7))
    return -r.fun, r.x


# ---------------------------------------------------------------- checks
# 1) identity against finite differences of ln F (independent route)
def lnF(x, lam, n=200001):
    s = np.sqrt(2 * lam * KT); mu = x + lam
    e = np.linspace(mu - 14 * s, mu + 14 * s, n)
    lw = -(e - mu) ** 2 / (2 * s * s) - np.logaddexp(0, e / KT)
    M = lw.max()
    return M + np.log(np.exp(lw - M).sum() * (e[1] - e[0]))
print('[check] identity vs finite difference of ln F (h = 2 meV):')
for lam, x in ((0.3, -0.3), (0.3, 0.0), (0.1, -0.1), (0.05, 0.05)):
    h = 0.002
    fd = -KT * (lnF(x + h, lam) - 2 * lnF(x, lam) + lnF(x - h, lam)) / h ** 2
    print('   lam %.2f x %+.2f: identity %.5f  finite diff %.5f' % (lam, x, curv(x, lam), fd))
# 2) doc 43 values
lam_tab = np.array([0.002, 0.003, 0.005, 0.0075, 0.01, 0.015, 0.02, 0.025, 0.03, 0.04, 0.05, 0.062, 0.075, 0.1,
                    0.15, 0.2, 0.3, 0.43, 0.5, 0.7, 1.0, 1.5])
tab = []
for lam in lam_tab:
    b, xm = B(lam)
    tab.append(dict(lam=float(lam), B=float(b), x_at_max=float(xm), gauss_cap=1 / (2 * lam), fermi_cap=1 / (4 * KT)))
print('\nB(lambda) [V^-1 for f = 1]:')
for t in tab:
    print('   lam %.4f eV: B %.3f  (x at max %+.3f eV; caps 1/2lam %.2f, 1/4kT %.2f)' % (t['lam'], t['B'], t['x_at_max'], t['gauss_cap'], t['fermi_cap']))
print('[check] doc 43: B(0.1)=2.72, B(0.3)=1.25, B(1.0)=0.45 ->', ' '.join('%.3f' % B(l)[0] for l in (0.1, 0.3, 1.0)))

# ---------------------------------------------------------------- required lambda for the measured slopes (f = 1)
def lam_req(s):
    """largest lambda with B(lambda) >= s; None if s exceeds the lambda -> 0 cap"""
    if s >= 1 / (4 * KT): return None
    return brentq(lambda l: B(l)[0] - s, 1e-4, 3.0, xtol=1e-6)
d1 = json.load(open('d1d3.json'))
meas = [('H adjacent (0.15-0.17 V)', 3.60, 0), ('H window 0.12-0.248 V', 2.78, 0.18),
        ('H sliding 60 mV (0.13 V)', 3.63, 0.25),
        ('D window 0.25-0.35 V', 6.64, 0.33), ('D adjacent (0.29-0.31 V)', 7.71, 0),
        ('D sliding 60 mV (0.29 V)', 7.81, 0.22), ('D sliding 40 mV (0.29 V)', 8.38, 0.18)]
print('\nrequired lambda (f = 1, the most permissive case):')
req = []
for name, s, se in meas:
    l0 = lam_req(s); lhi = lam_req(s - 2 * se) if se else None; llo = lam_req(s + 2 * se) if se else None
    req.append(dict(name=name, slope=-s, se=se, lam=l0, lam_2se=[llo, lhi]))
    print('   %-28s %+.2f +- %.2f V^-1: lambda <= %s eV%s' % (name, -s, se, '%.4f' % l0 if l0 else '(none)',
          ('  (+-2SE: %s to %s)' % ('%.4f' % llo if llo else 'none', '%.4f' % lhi if lhi else 'none')) if se else ''))
print('   cap at lambda -> 0: 1/(4kT) = %.3f V^-1' % (1 / (4 * KT)))
print('   ratio to B(0.3): H adjacent %.1f, D adjacent %.1f, D window %.1f' % (3.60 / B(0.3)[0], 7.71 / B(0.3)[0], 6.64 / B(0.3)[0]))

# ---------------------------------------------------------------- Delta alpha from a driving-force offset (single channel, f = 1)
# |Delta alpha(eta)| <= f * delta * B(lambda) <= delta / (4 kT)
print('\nDelta alpha from an offset delta (single channel): |Dalpha| <= f delta B(lambda) [arith with B]')
aHo = dict(zip([0.21, 0.23, 0.25, 0.27], [0.442, 0.413, 0.401, 0.397]))
aDn = dict(zip(d1['alpha_D']['c'], d1['alpha_D']['a']))
pts = {e: aHo[e] - aDn[e] for e in (0.21, 0.23, 0.25, 0.27)}
print('   measured pointwise Delta alpha:', ' '.join('%.2f V %+.3f' % (e, v) for e, v in pts.items()))
dres = []
for dname, dl in (('delta_D', 0.02797), ('delta_eff', 0.0407)):
    cap = dl / (4 * KT)
    need = {}
    for tgt in (0.201, 0.205, 0.30, 0.40):
        s = tgt / dl
        need[tgt] = lam_req(s)
    dres.append(dict(name=dname, delta=dl, cap=cap, need=need, B03=dl * B(0.3)[0]))
    print('   %-9s = %.1f meV: max |Dalpha| at lambda = 0.3 eV %.3f; as lambda -> 0 %.3f; lambda needed for |Dalpha| 0.201 / 0.205 / 0.30 / 0.40:'
          % (dname, dl * 1e3, dl * B(0.3)[0], cap), ' / '.join('%.4f' % v if v else 'none' for v in need.values()))
json.dump(dict(table=tab, required=req, dalpha=dres, pointwise=pts), open('l1_bound.json', 'w'), indent=1, default=float)
