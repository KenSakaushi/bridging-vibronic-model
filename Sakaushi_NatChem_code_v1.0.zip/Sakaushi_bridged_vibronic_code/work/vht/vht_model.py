"""doc 67: Volmer-Heyrovsky-Tafel (VHT) extension of the bridged expression (assumptions agreed with Ken, 2026-09-29).

  Volmer, back-Volmer, Heyrovsky: exactly as vh_model.VH (doc 64/65).
  Tafel     : 2L* -> L2, rate 2 k_T theta^2 per site (Langmuir), k_T independent of eta (chemical step); no reverse
              Tafel or reverse Heyrovsky. k_T = 10**lrhoT in the units of the Volmer prefactor C_V.
  isotopes  : k_V, k_Hy from the model (mass, delta_D); for D both are multiplied by c_D/c_H (acid 0.8953, alkali
              0.9960, doc 61) because the donor concentration no longer cancels once the Tafel step is present;
              k_T^D = k_T^H / 10**kieT with kieT = log10(k_T^H/k_T^D) fixed (scan -0.946 ... +0.963).
  steady state: 2 k_T th^2 + S th - k_V = 0, S = k_V + k_-V + k_Hy -> th = 2 k_V / (S + sqrt(S^2 + 8 k_T k_V))
              j = 2 e N_s (k_Hy th + k_T th^2)
  alpha      : analytic (x = e|eta|/kT): th' = -[(aV kV + (aV - 1) kmV + aHy kHy) th - aV kV] / (4 kT th + S)
              alpha = [aHy kHy th + (kHy + 2 kT th) th'] / (kHy th + kT th^2)
              coded as alpha = (1 - wT) aHy + (1 + wT) dln(th)/dx with wT = kT th/(kHy + kT th) (stable form)
  model K    : (j_H/c_H)/(j_D/c_D) = exp(lnj_H - lnj_D) * c_D/c_H.       [model calculation]"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import sys
import numpy as np
from scipy.special import expit

sys.path.insert(0, _PKG + '/work/vh')
sys.path.insert(0, _PKG + '/work/integrated')
from vh_model import VH, _lse, LN10, KT      # noqa: E402

CONC = {'acid': 0.8953, 'alk': 0.9960}       # c_D/c_H [arithmetic; doc 61]


class VHT(VH):
    def __init__(self, conc=None, **kw):
        super().__init__(**kw)
        self.conc = dict(CONC if conc is None else conc)

    def rates(self, iso, med, eta, p, mhc):
        """ln of the pseudo-first-order rate constants and the step transfer coefficients."""
        eta = np.atleast_1d(np.asarray(eta, float))
        pv = {'dE0_' + med: p['dE0_' + med], 'f0_' + med: p['f0_' + med], 'f1_' + med: p['f1_' + med]}
        lkV, aV = self.MV.lnj_alpha(iso, med, eta, pv, mhc)
        lkHy0, aHy = self.lnk_hy(iso, med, eta, p, mhc)
        lkHy = lkHy0 + LN10 * p['lrho_' + med]
        if iso == 'D':
            lc = np.log(self.conc[med])
            lkV = lkV + lc
            lkHy = lkHy + lc
        dI = self.delta_D if iso == 'D' else 0.0
        lkmV = lkV + (p['dE0_' + med] + dI - eta) / KT
        lkT = LN10 * p['lrhoT_' + med] - (LN10 * p.get('kieT', 0.0) if iso == 'D' else 0.0)
        return lkV, lkmV, lkHy, np.full_like(eta, lkT), aV, aHy

    def solve(self, iso, med, eta, p, mhc):
        eta = np.atleast_1d(np.asarray(eta, float))
        lkV, lkmV, lkHy, lkT, aV, aHy = self.rates(iso, med, eta, p, mhc)
        L = _lse(np.vstack([lkV, lkmV, lkHy]), axis=0)            # ln Sigma
        kv, kmv, khy = (np.exp(a - L) for a in (lkV, lkmV, lkHy))  # rates scaled by Sigma (<= 1)
        lq = np.log(8.0) + (lkT - L) + (lkV - L)                   # ln(8 kt kv)
        r = np.sqrt(1.0 + np.exp(np.minimum(lq, 700.0)))           # sqrt(1 + 8 kt kv)
        lth = np.log(2.0) + (lkV - L) - np.log1p(r)                # theta = 2 kv / (1 + r)
        th = np.exp(lth)
        l_hy = lkHy - L                                            # ln khy
        l_t = lkT - L + lth                                        # ln(kt theta)
        wT = expit(l_t - l_hy)                                     # Tafel share of the H2 production
        lR = lth + np.logaddexp(l_hy, l_t)                         # ln(khy th + kt th^2)
        lnj = np.log(2.0) + L + lR
        four_kt_th = 4.0 * np.exp(l_t)                             # = r - 1
        dlth = -((aV * kv + (aV - 1.0) * kmv + aHy * khy) - aV * 0.5 * (1.0 + r)) / (four_kt_th + 1.0)
        alpha = (1.0 - wT) * aHy + (1.0 + wT) * dlth
        return dict(lnj=lnj, alpha=alpha, theta=th, wV=kv, wmV=kmv, wHy=khy, wT=wT, aV=aV, aHy=aHy,
                    lkV=lkV, lkmV=lkmV, lkHy=lkHy, lkT=lkT, dlntheta=dlth)

    def alpha(self, iso, med, eta, p, mhc):
        return self.solve(iso, med, eta, p, mhc)['alpha']

    def lnj(self, iso, med, eta, p, mhc):
        return self.solve(iso, med, eta, p, mhc)['lnj']

    def lnK(self, med, eta, p, mhc):
        """ln K with K = (j_H/c_H)/(j_D/c_D)"""
        return self.lnj('H', med, eta, p, mhc) - self.lnj('D', med, eta, p, mhc) + np.log(self.conc[med])
