"""doc 67: table of the VHT fits (all Tafel KIE values, both dE0 ranges) from out/*.json.   [fit] [model calculation]
Measured references (doc 59): H bend -3.6 V^-1 (0.13-0.17 V), D -7.8 V^-1 (0.29 V), D delay 142 mV at alpha 0.60,
log K 0.42 / 0.02 / -0.27 at 0.13 / 0.245 / 0.29 V (acid), 1.26 -> 1.58 at 0.30 -> 0.479 V (alkali) [arithmetic]."""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import json, glob, os
import numpy as np

OUT = _PKG + '/work/vht/out'
VH = _PKG + '/work/vh'
rows = []
for f in sorted(g for g in glob.glob(f'{OUT}/vht_*.json') if not g.endswith('.orig.json')):
    d = json.load(open(f))
    fe, med = d['features'], d['med']
    g = np.array(fe['grid'])
    lk = dict(zip(fe['logK_vs_meas']['eta'], fe['logK_vs_meas']['model']))
    meas = dict(zip(fe['logK_vs_meas']['eta'], fe['logK_vs_meas']['meas']))
    if med == 'acid':
        pts = [0.13, 0.25, 0.29]
        lkm = [round(float(np.interp(e, g, fe['logK'])), 2) for e in (0.13, 0.245, 0.29)]
    else:
        pts = [0.30, 0.479]
        lkm = [round(float(np.interp(e, g, fe['logK'])), 2) for e in (0.30, 0.479)]
    ratios = np.array(d['features']['ratio_vs_meas'])
    c6 = fe['cross_levels']['0.6']
    delay = None if (med == 'alk' or c6['H'] is None or c6['D'] is None) else round(1000 * (c6['D'] - c6['H']))
    th = {iso: [round(float(np.interp(x, g, fe[iso]['theta'])), 3) for x in ((0.1, 0.2, 0.3) if med == 'acid' else (0.3, 0.4, 0.479))]
          for iso in 'HD'}
    rows.append(dict(which=d['which'], rng=d['rng'], kieT=d['kieT'], rms=d['summary']['rms'],
                     rmsH=d['summary']['per']['H']['rms'], rmsD=d['summary']['per']['D']['rms'],
                     x=[round(v, 3) for v in d['x']], at_bound=d['at_bound'], conv=d['conv'],
                     dAICc_V=d['dAICc_vs_V'], dAICc_VH=d['dAICc_vs_VH'], dBIC_V=d['dBIC_vs_V'], dBIC_VH=d['dBIC_vs_VH'],
                     ref_rms_V=d['ref']['volmer']['rms'], ref_rms_VH=d['ref']['vh']['rms'],
                     steepH=fe['H']['steep_win'], steepD=fe['D']['steep_win'], peakD=fe['D']['peak_win'],
                     wT_max=(fe['H']['wT_max_win'], fe['D']['wT_max_win']), theta=th,
                     logK=lkm, K1=fe['K1_cross'], delay60=delay,
                     ratio_range=(float(ratios.min()), float(ratios.max()))))
# main-text Volmer-only (unrestricted) for the restricted comparison
mainV = {w: json.load(open(f'{VH}/fit_vh_{w}.json'))['volmer']['summary'] for w in ('acid_new', 'acid_trim', 'alk')}
for r in rows:
    r['dAICc_mainV'] = None
lines = []
hdr = (f'{"data":9s} {"rng":4s} {"kieT":>6s} {"rms":>6s} {"H":>6s} {"D":>6s}  {"dE0,f0,f1,lrho,lrhoT":42s} {"bound":22s} '
       f'{"dAICc V/VH":>11s} {"steep H/D":>12s} {"delay":>5s} {"wTmax H/D":>9s} {"logK":>18s} {"K1":>6s} {"K/Kmeas":>11s}')
lines.append(hdr)
for r in sorted(rows, key=lambda r: (r['which'], r['rng'], r['kieT'])):
    k1s = '-' if r['K1'] is None else f"{r['K1']:.3f}"
    lines.append(f'{r["which"]:9s} {r["rng"]:4s} {r["kieT"]:+6.3f} {r["rms"]:6.4f} {r["rmsH"]:6.4f} {r["rmsD"]:6.4f}  '
                 f'{str(r["x"]):42s} {",".join(b.split("_")[0] for b in r["at_bound"]):22s} '
                 f'{r["dAICc_V"]:+5.1f}/{r["dAICc_VH"]:+5.1f} {r["steepH"][0]:+5.2f}/{r["steepD"][0]:+5.2f} '
                 f'{str(r["delay60"]):>5s} {r["wT_max"][0]:.2f}/{r["wT_max"][1]:.2f} {str(r["logK"]):>18s} '
                 f'{k1s:>6s} '
                 f'{r["ratio_range"][0]:4.2f}-{r["ratio_range"][1]:4.1f}')
lines.append('')
lines.append('references: Volmer-only (main text) rms ' + ', '.join(f'{w} {mainV[w]["rms"]:.4f} (AICc {mainV[w]["AICc"]:.1f})' for w in mainV))
for w in ('acid_new', 'acid_trim', 'alk'):
    fv = json.load(open(f'{VH}/fit_vh_{w}.json'))['vh']['summary']
    lines.append(f'            VH (doc 65, full) {w}: rms {fv["rms"]:.4f} AICc {fv["AICc"]:.1f}')
    rr = f'{OUT}/ref_{w}_r035.json'
    if os.path.exists(rr):
        q = json.load(open(rr))
        lines.append(f'            r035 {w}: Volmer rms {q["volmer"]["summary"]["rms"]:.4f} x {np.round(q["volmer"]["x"], 3).tolist()}; '
                     f'VH rms {q["vh"]["summary"]["rms"]:.4f} x {np.round(q["vh"]["x"], 3).tolist()}')
# restricted fits relative to the unrestricted main-text Volmer-only model
lines.append('')
lines.append('restricted VHT (dE0 >= 0.35 eV) vs the main-text Volmer-only fit (unrestricted):')
for r in sorted(rows, key=lambda r: (r['which'], r['kieT'])):
    if r['rng'] != 'r035':
        continue
    d = json.load(open(f'{OUT}/vht_{r["which"]}_r035_{r["kieT"]:+.3f}.json'))
    dA = d['summary']['AICc'] - mainV[r['which']]['AICc']
    lines.append(f'   {r["which"]:9s} kieT {r["kieT"]:+.3f}: rms {r["rms"]:.4f} vs {mainV[r["which"]]["rms"]:.4f}, dAICc {dA:+.1f}')
txt = '\n'.join(lines)
open(_PKG + '/work/vht/summary_vht.log', 'w').write(txt + '\n')
json.dump(rows, open(_PKG + '/work/vht/summary_vht.json', 'w'), indent=1, default=float)
print(txt)
