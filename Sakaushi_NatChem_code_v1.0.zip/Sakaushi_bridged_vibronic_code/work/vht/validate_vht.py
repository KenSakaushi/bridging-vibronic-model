"""doc 67 sec. 5: checks of the VHT model before any fit.   [model calculation]
 1. Tafel off (log10 rhoT = -60): alpha and log K equal those of the VH fits of doc 65 (fit_vh_*.json).
 2. Analytic alpha = numerical derivative of ln j (central difference, h = 1 mV) with the Tafel step active.
 3. Heyrovsky off and Volmer near equilibrium: alpha = 2 (1 - theta) (V-T, Tafel control).
 4. Donor concentration: with the Tafel step off, the c_D/c_H factor leaves alpha_D unchanged."""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import sys, json
import numpy as np
sys.path.insert(0, _PKG + '/work/vht')
from vht_model import VHT, KT
sys.path.insert(0, _PKG + '/work/integrated')
from acid59_model import get_mhc

M = VHT(); mhc = get_mhc(0.3)
out = {}
# ---- 1. Tafel off reproduces VH (doc 65)
for which in ('acid_new', 'acid_trim', 'alk'):
    d = json.load(open(f'{_PKG}/work/vh/fit_vh_{which}.json'))
    med = d['med']; p = dict(d['vh']['p']); p[f'lrhoT_{med}'] = -60.0; p['kieT'] = 0.0
    g = np.array(d['vh']['features']['grid'])
    da = max(float(np.max(np.abs(M.alpha(iso, med, g, p, mhc) - np.array(d['vh']['features'][iso]['alpha'])))) for iso in 'HD')
    dk = float(np.max(np.abs(M.lnK(med, g, p, mhc) / np.log(10) - np.array(d['vh']['features']['logK']))))
    out[f'1_{which}'] = dict(max_dalpha=da, max_dlogK=dk)
    print(f'1. Tafel off vs VH [{which}]: max |d alpha| = {da:.2e}, max |d log K| = {dk:.2e} (VH stored to 5 decimals)')
# ---- 2. analytic vs numerical alpha with the Tafel step active
d = json.load(open(_PKG + '/work/vh/fit_vh_acid_new.json'))
base = dict(d['vh']['p'])
h = 1e-3
for lt, kie in ((-4.0, 0.0), (-2.0, 0.963), (0.0, -0.946), (2.0, 0.5)):
    p = dict(base); p['lrhoT_acid'] = lt; p['kieT'] = kie
    g = np.linspace(0.08, 0.40, 33)
    worst = 0.0
    for iso in 'HD':
        s = M.solve(iso, 'acid', g, p, mhc)
        num = KT * (M.lnj(iso, 'acid', g + h, p, mhc) - M.lnj(iso, 'acid', g - h, p, mhc)) / (2 * h)
        worst = max(worst, float(np.max(np.abs(num - s['alpha']))))
        wmax = float(np.max(s['wT']))
    out[f'2_lrhoT{lt}_kie{kie}'] = dict(max_diff=worst, max_wT=wmax)
    print(f'2. analytic vs numerical alpha (acid, log10 rhoT {lt:+.0f}, kieT {kie:+.3f}): max diff {worst:.1e}; max Tafel share {wmax:.2f}')
# ---- 3. V-T with the Volmer step near equilibrium: alpha -> 2 (1 - theta)
p = dict(base); p['lrho_acid'] = -40.0; p['lrhoT_acid'] = -9.0; p['kieT'] = 0.0
g = np.linspace(0.05, 0.40, 36)
s = M.solve('H', 'acid', g, p, mhc)
dev = np.abs(s['alpha'] - 2 * (1 - s['theta']))
eq = s['wmV']      # back-Volmer share of Sigma: close to 1 - theta when the Volmer step is in equilibrium
out['3_VT'] = dict(max_dev=float(dev.max()), theta_range=[float(s['theta'].min()), float(s['theta'].max())],
                   wT_min=float(s['wT'].min()))
print(f'3. V-T, Volmer near equilibrium: max |alpha - 2(1 - theta)| = {dev.max():.1e} over theta '
      f'{s["theta"].min():.3f}-{s["theta"].max():.3f} (Tafel share >= {s["wT"].min():.3f})')
# ---- 4. concentration factor without the Tafel step
p = dict(base); p['lrhoT_acid'] = -60.0; p['kieT'] = 0.0
M1 = VHT(conc={'acid': 1.0, 'alk': 1.0})
g = np.linspace(0.08, 0.40, 33)
dd = float(np.max(np.abs(M.alpha('D', 'acid', g, p, mhc) - M1.alpha('D', 'acid', g, p, mhc))))
dK = float(np.max(np.abs(M.lnK('acid', g, p, mhc) - M1.lnK('acid', g, p, mhc))))
out['4_conc'] = dict(max_dalphaD=dd, max_dlnK=dK)
print(f'4. c_D/c_H without Tafel: max |d alpha_D| = {dd:.1e}, max |d ln K| = {dK:.1e}')
json.dump(out, open('validate_vht.json', 'w'), indent=1)
