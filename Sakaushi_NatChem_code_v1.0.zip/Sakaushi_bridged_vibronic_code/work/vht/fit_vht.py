"""doc 67: fits of the VHT extension at lambda = 0.3 eV.   [fit] [model calculation]
Jobs
  ref  <which> r035          : Volmer-only and VH fits with dE0 >= 0.35 eV (the full-range ones are those of doc 65)
  vht  <which> <rng> <kieT>  : VHT fit, 5 parameters (dE0, f0, f1, log10 rho, log10 rhoT), Tafel KIE fixed
  prof <which> <rng> <kieT>  : profile over log10 rhoT (fixed on a grid, the other 4 refitted)
which = acid_new | acid_trim | alk ; rng = full (dE0 -0.6-1.2 eV) | r035 (dE0 0.35-1.2 eV)
Data [fit]: as doc 65 (acid H 10 + D 13 values, trim D 11, alkali H 5 + D 7). K is not fitted.
Usage: python3 fit_vht.py <job> <which> [<rng> [<kieT>]]"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import sys, json, time, os
import numpy as np
from scipy.optimize import least_squares
sys.path.insert(0, _PKG + '/work/vht')
sys.path.insert(0, _PKG + '/work/integrated')
from vht_model import VHT, KT
from acid59_model import SETS, get_mhc
from model import OBS
from model_ext import info

LAM = 0.3
BND = {'full': {'dE0': (-0.6, 1.2)}, 'r035': {'dE0': (0.35, 1.2)}}
COMMON = {'f0': (0.1, 1.0), 'f1': (-2.0, 2.0), 'lrho': (-15.0, 15.0), 'lrhoT': (-15.0, 15.0)}
DATA = {'acid_new': ('acid', SETS['new']), 'acid_trim': ('acid', SETS['trim']),
        'alk': ('alk', {'H': OBS[('H', 'alk')], 'D': OBS[('D', 'alk')]})}
WIN = {'acid': {'H': (0.09, 0.27), 'D': (0.11, 0.35)}, 'alk': {'H': (0.29, 0.45), 'D': (0.28, 0.56)}}
KFIG = json.load(open(_PKG + '/figs/k_fig.json'))
OFF = -60.0            # log10 rhoT for "no Tafel step"
M = VHT()
mhc = get_mhc(LAM)
OUT = _PKG + '/work/vht/out'
os.makedirs(OUT, exist_ok=True)


def bounds(names, rng):
    b = dict(COMMON, **BND[rng])
    lo = np.array([b[n.rsplit('_', 1)[0]][0] for n in names]); hi = np.array([b[n.rsplit('_', 1)[0]][1] for n in names])
    return lo, hi


def resid(x, names, med, obs, fixed):
    p = dict(fixed); p.update(zip(names, x))
    r = []
    for iso in 'HD':
        e, a = obs[iso]
        r.extend(M.alpha(iso, med, np.array(e), p, mhc) - np.array(a))
    r = np.array(r)
    return np.where(np.isfinite(r), r, 10.0)


def fit(names, med, obs, fixed, starts, rng, n1=40, keep=4, n2=400):
    """two-stage multistart: every start for n1 function evaluations, then the `keep` best distinct ones refined"""
    lo, hi = bounds(names, rng)
    stage1 = []
    for x0 in starts:
        x0 = np.clip(np.asarray(x0, float), lo + 1e-9, hi - 1e-9)
        try:
            s = least_squares(resid, x0, args=(names, med, obs, fixed), bounds=(lo, hi), x_scale='jac', max_nfev=n1)
        except Exception as ex:
            print('   start failed:', ex, flush=True)
            continue
        stage1.append(s)
    stage1.sort(key=lambda s: s.cost)
    picked, seen = [], []
    for s in stage1:
        key = np.round(s.x, 2)
        if any(np.allclose(key, k) for k in seen):
            continue
        seen.append(key); picked.append(s)
        if len(picked) == keep:
            break
    sols = []
    for s0 in picked:
        s = least_squares(resid, np.clip(s0.x, lo + 1e-9, hi - 1e-9), args=(names, med, obs, fixed), bounds=(lo, hi),
                          x_scale='jac', max_nfev=n2)
        sols.append(s)
    best = min(sols, key=lambda s: s.cost)
    rms_b = np.sqrt(2 * best.cost / len(best.fun))
    allr = [np.sqrt(2 * q.cost / len(q.fun)) for q in stage1]
    nconv = sum(1 for r in allr if r - rms_b < 2e-3)          # starts already within 0.002 of the best after stage 1
    at_b = [n for n, v, l, h in zip(names, best.x, lo, hi) if min(v - l, h - v) < 1e-3 * (h - l)]
    return best, nconv, len(stage1), at_b, sols + stage1


def summary(p, med, obs, k):
    res, per = [], {}
    for iso in 'HD':
        e, a = obs[iso]
        m = M.alpha(iso, med, np.array(e), p, mhc)
        r = m - np.array(a)
        per[iso] = dict(rms=float(np.sqrt(np.mean(r ** 2))), model=np.round(m, 4).tolist(), res=np.round(r, 4).tolist())
        res.extend(r)
    res = np.array(res)
    rss = float((res ** 2).sum()); n = len(res)
    aicc, bic = info(rss, n, k)
    return dict(rms=float(np.sqrt(np.mean(res ** 2))), per=per, rss=rss, n=n, k=k, AICc=aicc, BIC=bic)


def features(p, med):
    g = np.round(np.arange(0.05, 0.6001, 0.0025), 4) if med == 'alk' else np.round(np.arange(0.05, 0.4001, 0.0025), 4)
    S = {iso: M.solve(iso, med, g, p, mhc) for iso in 'HD'}
    f = {'grid': g.tolist()}
    for iso in 'HD':
        s = S[iso]; a = s['alpha']; sl = np.gradient(a, g)
        lo, hi = WIN[med][iso]
        w = (g >= lo - 1e-9) & (g <= hi + 1e-9)
        f[iso] = dict(alpha=np.round(a, 5).tolist(), theta=np.round(s['theta'], 5).tolist(),
                      wHy=np.round(s['wHy'], 5).tolist(), wmV=np.round(s['wmV'], 5).tolist(),
                      wT=np.round(s['wT'], 5).tolist(),
                      steep_win=(float(sl[w].min()), float(g[w][np.argmin(sl[w])])),
                      peak_win=(float(a[w].max()), float(g[w][np.argmax(a[w])])),
                      wT_max_win=float(s['wT'][w].max()))
    lnK = M.lnK(med, g, p, mhc)
    f['logK'] = np.round(lnK / np.log(10), 5).tolist()
    cr = [float(g[i] + (g[i + 1] - g[i]) * lnK[i] / (lnK[i] - lnK[i + 1])) for i in range(len(g) - 1)
          if lnK[i] > 0 >= lnK[i + 1]]
    f['K1_cross'] = cr[0] if cr else None
    f['cross_levels'] = {}
    for lev in (0.75, 0.70, 0.60, 0.50, 0.42):
        row = {}
        for iso in 'HD':
            a = np.array(f[iso]['alpha'])
            idx = [i for i in range(len(g) - 1) if a[i] >= lev > a[i + 1]]
            row[iso] = (float(g[idx[-1]] + (g[idx[-1] + 1] - g[idx[-1]]) * (a[idx[-1]] - lev) / (a[idx[-1]] - a[idx[-1] + 1]))
                        if idx else None)
        f['cross_levels'][str(lev)] = row
    if med == 'acid':
        e, lk = KFIG['acid']['eta'], KFIG['acid']['logK']
    else:
        e, lk = KFIG['alk']['eta'], KFIG['alk']['KOD98']['logK']
    lm = M.lnK(med, np.array(e), p, mhc) / np.log(10)
    f['logK_vs_meas'] = dict(eta=e, model=np.round(lm, 4).tolist(), meas=lk)
    f['ratio_vs_meas'] = [float(10 ** (m - o)) for m, o in zip(lm, lk)]
    return f


def rand_starts(names, rng, n, seed):
    lo, hi = bounds(names, rng)
    r = np.random.default_rng(seed)
    return [lo + (hi - lo) * r.random(len(names)) for _ in range(n)]


def ref(which, rng):
    """Volmer-only and VH with the restricted dE0 range (dE0 >= 0.35 eV)."""
    t0 = time.time()
    med, obs = DATA[which]
    n3 = [f'dE0_{med}', f'f0_{med}', f'f1_{med}']
    fixedV = {'lam': LAM, f'lrho_{med}': 15.0, f'lrhoT_{med}': OFF, 'kieT': 0.0}
    old = json.load(open(f'{_PKG}/work/vh/fit_vh_{which}.json'))
    stV = [old['volmer']['x']] + rand_starts(n3, rng, 12, 6700 + len(which))
    bV, ncV, nsV, abV, _ = fit(n3, med, obs, fixedV, stV, rng)
    pV = dict(fixedV, **dict(zip(n3, bV.x))); sV = summary(pV, med, obs, 3)
    n4 = n3 + [f'lrho_{med}']
    fixedH = {'lam': LAM, f'lrhoT_{med}': OFF, 'kieT': 0.0}
    st = rand_starts(n4, rng, 32, 6710 + len(which)) + [list(bV.x) + [lr] for lr in (10.0, 5.0, 2.0, 0.0, -2.0, -5.0)]
    st += [old['vh']['x']]
    bH, ncH, nsH, abH, solsH = fit(n4, med, obs, fixedH, st, rng)
    pH = dict(fixedH, **dict(zip(n4, bH.x))); sH = summary(pH, med, obs, 4)
    out = dict(which=which, rng=rng, med=med,
               volmer=dict(x=list(map(float, bV.x)), p=pV, summary=sV, conv=f'{ncV}/{nsV}', at_bound=abV, features=features(pV, med)),
               vh=dict(x=list(map(float, bH.x)), p=pH, summary=sH, conv=f'{ncH}/{nsH}', at_bound=abH, features=features(pH, med)),
               sec=round(time.time() - t0, 1))
    json.dump(out, open(f'{OUT}/ref_{which}_{rng}.json', 'w'), indent=1, default=float)
    print(f'[ref {which} {rng}] Volmer rms {sV["rms"]:.4f} x {np.round(bV.x, 4).tolist()} bound {abV} conv {ncV}/{nsV}; '
          f'VH rms {sH["rms"]:.4f} x {np.round(bH.x, 4).tolist()} bound {abH} conv {ncH}/{nsH}; '
          f'dAICc(VH-V) {sH["AICc"] - sV["AICc"]:+.1f}  ({time.time() - t0:.0f} s)', flush=True)


def reference(which, rng):
    if rng == 'full':
        d = json.load(open(f'{_PKG}/work/vh/fit_vh_{which}.json'))
        return d['volmer']['x'], d['volmer']['summary'], d['vh']['x'], d['vh']['summary']
    d = json.load(open(f'{OUT}/ref_{which}_{rng}.json'))
    return d['volmer']['x'], d['volmer']['summary'], d['vh']['x'], d['vh']['summary']


def vht(which, rng, kie):
    t0 = time.time()
    med, obs = DATA[which]
    names = [f'dE0_{med}', f'f0_{med}', f'f1_{med}', f'lrho_{med}', f'lrhoT_{med}']
    fixed = {'lam': LAM, 'kieT': kie}
    xV, sV, xH, sH = reference(which, rng)
    starts = rand_starts(names, rng, 32, 6800 + int(1000 * (kie + 2)) + len(which) + (0 if rng == 'full' else 7))
    starts += [list(xH) + [lt] for lt in (-15.0, -6.0, -4.0, -2.0, 0.0, 2.0, 4.0)]
    starts += [list(xV) + [-15.0, lt] for lt in (-6.0, -3.0, 0.0, 3.0)]
    best, nconv, ns, at_b, sols = fit(names, med, obs, fixed, starts, rng)
    p = dict(fixed, **dict(zip(names, best.x)))
    s = summary(p, med, obs, 5)
    loc = sorted({(round(float(np.sqrt(2 * q.cost / len(q.fun))), 4), tuple(np.round(q.x, 3))) for q in sols})[:10]
    fe = features(p, med)
    out = dict(which=which, rng=rng, kieT=kie, med=med, names=names, x=list(map(float, best.x)), p=p, summary=s,
               conv=f'{nconv}/{ns}', at_bound=at_b, features=fe, locals=[dict(rms=r_, x=list(x_)) for r_, x_ in loc],
               ref=dict(volmer=dict(x=xV, rms=sV['rms'], AICc=sV['AICc'], BIC=sV['BIC']),
                        vh=dict(x=xH, rms=sH['rms'], AICc=sH['AICc'], BIC=sH['BIC'])),
               dAICc_vs_V=s['AICc'] - sV['AICc'], dBIC_vs_V=s['BIC'] - sV['BIC'],
               dAICc_vs_VH=s['AICc'] - sH['AICc'], dBIC_vs_VH=s['BIC'] - sH['BIC'], sec=round(time.time() - t0, 1))
    json.dump(out, open(f'{OUT}/vht_{which}_{rng}_{kie:+.3f}.json', 'w'), indent=1, default=float)
    g = np.array(fe['grid'])
    print(f'[vht {which} {rng} kieT {kie:+.3f}] rms {s["rms"]:.4f} (H {s["per"]["H"]["rms"]:.4f}, D {s["per"]["D"]["rms"]:.4f}) '
          f'x {np.round(best.x, 3).tolist()} bound {at_b} conv {nconv}/{ns}; dAICc vs V {out["dAICc_vs_V"]:+.1f}, '
          f'vs VH {out["dAICc_vs_VH"]:+.1f}; ({time.time() - t0:.0f} s)', flush=True)
    for iso in 'HD':
        F = fe[iso]
        print(f'   {iso}: steepest in window {F["steep_win"][0]:+.2f} V^-1 at {F["steep_win"][1]:.3f} V; peak {F["peak_win"][0]:.3f} '
              f'at {F["peak_win"][1]:.3f}; max Tafel share in window {F["wT_max_win"]:.2f}; theta at '
              f'{[round(float(np.interp(x, g, F["theta"])), 3) for x in ((0.10, 0.20, 0.30, 0.40) if med == "acid" else (0.30, 0.40, 0.48, 0.56))]}')
    print('   log K model/meas:', ' '.join(f'{e:.3f}:{m:+.2f}/{o:+.2f}' for e, m, o in
                                        zip(fe['logK_vs_meas']['eta'], fe['logK_vs_meas']['model'], fe['logK_vs_meas']['meas'])),
          '| K = 1 at', fe['K1_cross'])
    print('   crossings (H, D):', {k: (None if v['H'] is None else round(v['H'], 3), None if v['D'] is None else round(v['D'], 3))
                                  for k, v in fe['cross_levels'].items()})
    for q in loc[:4]:
        print(f'   local: rms {q[0]:.4f} x {list(q[1])}')


def prof(which, rng, kie, grid=(-10.0, -8.0, -6.0, -5.0, -4.0, -3.0, -2.0, -1.0, 0.0, 1.0, 2.0, 4.0)):
    """profile over log10 rhoT: the other four parameters refitted at each fixed value"""
    t0 = time.time()
    med, obs = DATA[which]
    n4 = [f'dE0_{med}', f'f0_{med}', f'f1_{med}', f'lrho_{med}']
    xV, sV, xH, sH = reference(which, rng)
    best_vht = json.load(open(f'{OUT}/vht_{which}_{rng}_{kie:+.3f}.json'))
    rows = []
    prev = None
    for lt in grid:
        fixed = {'lam': LAM, 'kieT': kie, f'lrhoT_{med}': lt}
        st = [list(xH), list(best_vht['x'][:4])] + ([prev] if prev is not None else [])
        st += [list(xV) + [-15.0]] + rand_starts(n4, rng, 4, 6900 + int(10 * lt) + len(which))
        b, nc, ns, ab, _ = fit(n4, med, obs, fixed, st, rng, keep=2, n2=300)
        p = dict(fixed, **dict(zip(n4, b.x)))
        s = summary(p, med, obs, 5)
        fe = features(p, med)
        prev = list(b.x)
        rows.append(dict(lrhoT=lt, x=list(map(float, b.x)), rms=s['rms'], rmsH=s['per']['H']['rms'], rmsD=s['per']['D']['rms'],
                         AICc=s['AICc'], at_bound=ab, conv=f'{nc}/{ns}',
                         wT_max=max(fe['H']['wT_max_win'], fe['D']['wT_max_win']),
                         logK=fe['logK_vs_meas']['model'], steepH=fe['H']['steep_win'][0], steepD=fe['D']['steep_win'][0]))
        print(f'[prof {which} {rng} kieT {kie:+.3f}] lrhoT {lt:+5.1f}: rms {s["rms"]:.4f} (H {s["per"]["H"]["rms"]:.3f}, '
              f'D {s["per"]["D"]["rms"]:.3f}) Tafel share max {rows[-1]["wT_max"]:.2f} x {np.round(b.x, 3).tolist()} '
              f'bound {ab}  ({time.time() - t0:.0f} s)', flush=True)
    json.dump(dict(which=which, rng=rng, kieT=kie, rows=rows, ref_vh_rms=sH['rms'], ref_vh_AICc=sH['AICc'],
                   ref_volmer_rms=sV['rms']), open(f'{OUT}/prof_{which}_{rng}_{kie:+.3f}.json', 'w'), indent=1, default=float)


def polish(which, rng):
    """cross-seeding: refine each Tafel-KIE fit from the solutions found for the other KIE values"""
    t0 = time.time()
    med, obs = DATA[which]
    files = sorted(f for f in os.listdir(OUT) if f.startswith(f'vht_{which}_{rng}_') and f.endswith('.json') and 'orig' not in f)
    sols = {f: json.load(open(f'{OUT}/{f}')) for f in files}
    lo, hi = None, None
    for f, d in sols.items():
        names = d['names']; kie = d['kieT']
        fixed = {'lam': LAM, 'kieT': kie}
        lo, hi = bounds(names, rng)
        cur = 0.5 * d['summary']['rss']
        best, src = None, None
        for g, e in sols.items():
            if g == f:
                continue
            x0 = np.clip(np.asarray(e['x'], float), lo + 1e-9, hi - 1e-9)
            q = least_squares(resid, x0, args=(names, med, obs, fixed), bounds=(lo, hi), x_scale='jac', max_nfev=400)
            if best is None or q.cost < best.cost:
                best, src = q, e['kieT']
        if best is not None and best.cost < cur - 1e-9:
            json.dump(d, open(f'{OUT}/{f[:-5]}.orig.json', 'w'), indent=1, default=float)
            p = dict(fixed, **dict(zip(names, best.x)))
            sm = summary(p, med, obs, 5)
            xV, sV, xH, sH = reference(which, rng)
            at_b = [n for n, v, l, h in zip(names, best.x, lo, hi) if min(v - l, h - v) < 1e-3 * (h - l)]
            d.update(x=list(map(float, best.x)), p=p, summary=sm, at_bound=at_b, features=features(p, med),
                     dAICc_vs_V=sm['AICc'] - sV['AICc'], dBIC_vs_V=sm['BIC'] - sV['BIC'],
                     dAICc_vs_VH=sm['AICc'] - sH['AICc'], dBIC_vs_VH=sm['BIC'] - sH['BIC'], polished_from=src)
            json.dump(d, open(f'{OUT}/{f}', 'w'), indent=1, default=float)
            print(f'[polish {which} {rng} kieT {kie:+.3f}] improved rms {np.sqrt(2 * cur / sm["n"]):.4f} -> {sm["rms"]:.4f} '
                  f'from the kieT {src:+.3f} solution; x {np.round(best.x, 3).tolist()} bound {at_b}  ({time.time() - t0:.0f} s)', flush=True)
        else:
            print(f'[polish {which} {rng} kieT {kie:+.3f}] unchanged (rms {np.sqrt(2 * cur / d["summary"]["n"]):.4f})  '
                  f'({time.time() - t0:.0f} s)', flush=True)


if __name__ == '__main__':
    job, which = sys.argv[1], sys.argv[2]
    if job == 'ref':
        ref(which, sys.argv[3])
    elif job == 'vht':
        vht(which, sys.argv[3], float(sys.argv[4]))
    elif job == 'prof':
        prof(which, sys.argv[3], float(sys.argv[4]))
    elif job == 'polish':
        polish(which, sys.argv[3])
