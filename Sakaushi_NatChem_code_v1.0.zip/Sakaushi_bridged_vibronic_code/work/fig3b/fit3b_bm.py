"""Fig. 3b refit, bond-stretching lineage (Bockris-Matthews, doc 06 construction; bm_vec.py of doc 42).
Same procedure as fit_bm.py (doc 42): grid dE0 = -10..25 kcal/mol (step 1) x d = 0.30..0.80 A (step 0.05),
then least_squares with bounds dE0 [-15, 30] kcal/mol, d [0.25, 0.90] A, diff_step 0.02; a model alpha that
cannot be evaluated (no crossing) enters as a residual of 1.0. Parameters are shared by H and D (no isotope-
specific parameter). Model alpha is the point derivative (h = 5 mV) at the measured |eta|.
Sets: old (validation against bm_fit.json of doc 42), new (13 alpha_D), trim (11 alpha_D).   [fit + model]"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import sys, json, time
import numpy as np
sys.path.insert(0, _PKG + '/work/bm2')
from bm_vec import ProtonPotentials, alpha_curve, EV
from scipy.optimize import least_squares
from sets3b import H_ACID, SETS

pot = ProtonPotentials(nonbonding=True)
LO, HI = np.array([-15.0, 0.25]), np.array([30.0, 0.90])


def model(dE0, d, obs):
    R = pot.R_of_d(d)
    return {iso: alpha_curve(pot, R, dE0, iso, np.array(obs[iso][0])) for iso in 'HD'}


def res(obs, dE0, d):
    m = model(dE0, d, obs)
    return np.concatenate([np.nan_to_num(m[iso] - np.array(obs[iso][1]), nan=1.0) for iso in 'HD'])


out = {}
for name in ('old', 'new', 'trim'):
    obs = {'H': H_ACID, 'D': SETS[name]}
    t = time.time(); best = (1e9, None)
    for dE0 in np.arange(-10, 25.1, 1.0):
        for d in np.arange(0.30, 0.801, 0.05):
            c = (res(obs, dE0, d) ** 2).sum()
            if c < best[0]:
                best = (c, (dE0, d))
    s = least_squares(lambda x: res(obs, *x), best[1], bounds=(LO, HI), diff_step=[0.02, 0.02])
    m = model(*s.x, obs)
    nnan = int(sum(np.isnan(m[i]).sum() for i in 'HD'))
    r = {iso: m[iso] - np.array(obs[iso][1]) for iso in 'HD'}
    rall = s.fun
    atb = [nm for nm, v, lo, hi in zip(('dE0', 'd'), s.x, LO, HI) if min(v - lo, hi - v) < 1e-3 * (hi - lo)]
    out[name] = dict(dE0_kcal=float(s.x[0]), dE0_eV=float(s.x[0] / EV), d=float(s.x[1]),
                     rms=float(np.sqrt((rall ** 2).mean())), n=int(rall.size), n_nan=nnan,
                     rmsH=float(np.sqrt(np.nanmean(r['H'] ** 2))), rmsD=float(np.sqrt(np.nanmean(r['D'] ** 2))),
                     grid_best=[float(best[1][0]), float(best[1][1])], at_bound=atb,
                     etaH=list(obs['H'][0]), H=[float(v) for v in m['H']],
                     etaD=list(obs['D'][0]), D=[float(v) for v in m['D']], sec=round(time.time() - t, 1))
    o = out[name]
    print(f"{name}: grid best dE0={best[1][0]:.1f} d={best[1][1]:.2f}; refined dE0={o['dE0_kcal']:.3f} kcal/mol "
          f"({o['dE0_eV']:.4f} eV), d={o['d']:.4f} A, rms={o['rms']:.4f} (H {o['rmsH']:.4f}, D {o['rmsD']:.4f}; "
          f"n {o['n']}, nan {nnan}) at_bound {atb}  [{o['sec']:.0f}s]", flush=True)
    for iso in 'HD':
        print(f"   {iso} eta " + " ".join('%.2f' % v for v in obs[iso][0]))
        print(f"     obs " + " ".join('%.3f' % v for v in obs[iso][1]))
        print(f"     mod " + " ".join('%.3f' % v for v in m[iso]), flush=True)
ref = json.load(open('bm_fit_doc42.json'))['acid']
print('validation (old vs doc 42 bm_fit.json acid): dE0 %.4f vs %.4f kcal/mol, d %.4f vs %.4f A, rms %.5f vs %.5f'
      % (out['old']['dE0_kcal'], ref['dE0'], out['old']['d'], ref['d'], out['old']['rms'], ref['rms']))
json.dump(out, open('fit3b_bm.json', 'w'), indent=1)
