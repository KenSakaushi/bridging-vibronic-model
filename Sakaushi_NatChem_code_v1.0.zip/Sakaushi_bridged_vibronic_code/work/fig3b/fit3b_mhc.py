"""Fig. 3b refit, medium-reorganization lineage alone: MHC rate function, single configuration (M0 of doc 42;
ext2.py with Rspan = 0), isotope offset d_acid fitted for D (the only isotope-specific parameter).
Same procedure as fitM.py M0 (doc 42): 8 parameters (lam, f0, G0, d for each medium; bounds lam 0.1-1.5 eV,
f0 0.3-1.0, G0 -1.0-1.5 eV, d -0.2-0.3 eV), 30 random starts (numpy default_rng(7)), least_squares
(max_nfev 400, x_scale 'jac'), fitted jointly over both media as in doc 42 (no parameter is shared between
media, so the alkaline part is unchanged by the new acid data; checked below). Model alpha is the point
derivative (h = 2 mV) at the measured |eta|.
Sets: old (validation against best_M0.json of doc 42), new (13 alpha_D), trim (11 alpha_D).   [fit + model]"""
import sys, json, time
import numpy as np
from scipy.optimize import least_squares
import ext2
from sets3b import H_ACID, SETS, ALK

spec = [('lam_acid', 0.1, 1.5), ('lam_alk', 0.1, 1.5), ('f0_acid', 0.3, 1.0), ('f0_alk', 0.3, 1.0),
        ('G0_acid', -1.0, 1.5), ('G0_alk', -1.0, 1.5), ('d_acid', -0.2, 0.3), ('d_alk', -0.2, 0.3)]
names = [s[0] for s in spec]; lo = np.array([s[1] for s in spec]); hi = np.array([s[2] for s in spec])
fixed = {'Rspan': 0.0}


def obs_of(name):
    return {('H', 'alk'): ALK['H'], ('D', 'alk'): ALK['D'], ('H', 'acid'): H_ACID, ('D', 'acid'): SETS[name]}


def resid(p, OBS):
    out = []
    for (iso, med), (e, a) in OBS.items():
        out += list(ext2.alpha(np.array(e), iso, med, p) - np.array(a))
    return np.array(out)


res_all = {}
for name in ('old', 'new', 'trim'):
    OBS = obs_of(name); t = time.time()
    rng = np.random.default_rng(7); best = None; costs = []
    for tr in range(30):
        x0 = lo + (hi - lo) * rng.random(len(lo))
        try:
            s = least_squares(lambda x: resid({**fixed, **dict(zip(names, x))}, OBS), x0, bounds=(lo, hi),
                              max_nfev=400, x_scale='jac')
        except Exception:
            continue
        costs.append(float(np.sqrt(2 * s.cost / len(s.fun))))
        if best is None or s.cost < best.cost:
            best = s
    p = {**fixed, **dict(zip(names, best.x))}
    per = {}
    for (iso, med), (e, a) in OBS.items():
        m = ext2.alpha(np.array(e), iso, med, p); r = m - np.array(a)
        per[f'{iso}-{med}'] = dict(eta=list(e), obs=list(a), model=[float(v) for v in m],
                                   rms=float(np.sqrt((r ** 2).mean())))
    atb = [nm for nm, v, l, h in zip(names, best.x, lo, hi) if min(v - l, h - v) < 1e-3 * (h - l)]
    nb = int(sum(c <= min(costs) + 1e-4 for c in costs))
    res_all[name] = dict(p={k: float(v) for k, v in p.items()}, rms=float(np.sqrt(2 * best.cost / len(best.fun))),
                         n_best=nb, n_trials=len(costs), at_bound=atb, per=per, sec=round(time.time() - t, 1))
    print(f"{name}: rms {res_all[name]['rms']:.4f} (starts reaching the best: {nb}/{len(costs)}) at_bound {atb} "
          f"[{time.time() - t:.0f}s]")
    print('   ', {k: round(v, 4) for k, v in p.items()})
    for k, v in per.items():
        print(f"   {k:7s} obs " + " ".join('%.3f' % x for x in v['obs']))
        print(f"           mod " + " ".join('%.3f' % x for x in v['model']) + f"  rms {v['rms']:.4f}", flush=True)
ref = json.load(open('best_M0_doc42.json'))
print('validation (old vs doc 42 best_M0.json):', ' '.join(f"{k} {res_all['old']['p'][k]:.4f}/{ref[k]:.4f}" for k in names))
print('alkaline part unchanged (new vs old):', ' '.join(f"{k} {res_all['new']['p'][k] - res_all['old']['p'][k]:+.1e}"
                                                        for k in names if k.endswith('alk')))
json.dump(res_all, open('fit3b_mhc.json', 'w'), indent=1)
