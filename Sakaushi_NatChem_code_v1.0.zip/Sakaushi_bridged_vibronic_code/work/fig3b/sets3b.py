"""Data sets for the Fig. 3b refit (hydronium donor). Measured local alpha [fit]:
  H: doc 26/34 (10 points, 0.09-0.27 V), unchanged.
  D old: doc 34 (4 points, 0.16-0.22 V), used in doc 42 (validation only).
  D new: 0.05 M D2SO4 file (13 points, 0.11-0.35 V; acidD_update.json, doc 58), as in doc 59 'new, all points'.
  D trim: new without the two low-current points (0.11, 0.13 V), as in doc 59 'low current excluded'."""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import json

UPD = json.load(open(_PKG + '/figs/acidD_update.json'))
H_ACID = ([0.09, 0.11, 0.13, 0.15, 0.17, 0.19, 0.21, 0.23, 0.25, 0.27],
          [0.789, 0.753, 0.690, 0.620, 0.548, 0.491, 0.442, 0.413, 0.401, 0.397])
D_OLD = ([0.16, 0.18, 0.20, 0.22], [0.730, 0.737, 0.730, 0.731])
D_NEW = (list(UPD['cD']), list(UPD['aD']))
D_TRIM = ([c for c in UPD['cD'] if c > 0.14], [a for c, a in zip(UPD['cD'], UPD['aD']) if c > 0.14])
SETS = {'old': D_OLD, 'new': D_NEW, 'trim': D_TRIM}
# alkaline data (unchanged; needed because the doc 42 MHC-alone fit was run jointly over both media)
ALK = {'H': ([0.29, 0.33, 0.37, 0.41, 0.45], [0.592, 0.583, 0.587, 0.604, 0.624]),
       'D': ([0.28, 0.32, 0.40, 0.44, 0.48, 0.52, 0.56], [0.464, 0.475, 0.472, 0.466, 0.437, 0.412, 0.386])}
