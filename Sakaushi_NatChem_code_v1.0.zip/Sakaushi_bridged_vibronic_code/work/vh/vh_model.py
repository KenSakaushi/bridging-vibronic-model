"""doc 64: Volmer-Heyrovsky extension of the bridged expression (assumptions approved by Ken, 2026-09-29).

  Volmer    : ModelX of doc 47/59, unchanged (delta_D 27.97 meV, Boltzmann P(R), mu <= 2, nu <= 7, gamma 1.0 A^-1).
  back-Volmer: detailed balance, k_-V = k_V exp[(dE0 + delta_i - e|eta|)/kT]  (delta_H = 0, delta_D = 27.97 meV).
  Heyrovsky : the same rate expression with the O-L / L-L Morse levels and overlaps (levels_hy.npz, bonding terms only),
              Delta G_Hy = -dE0 - delta_i + [eP_nu - eR_mu] - (reference) - f_Hy(d) e|eta|, f_Hy(d) = f(d + r_LL),
              acid: A = exp[(1 - f_Hy) e|eta|/kT]; P_Hy(d) = P_V(d); |V_el|^2 and F_lambda as for Volmer;
              prefactor ratio C_Hy/C_V = rho (fitted as log10 rho).
  steady state: theta = k_V/S, S = k_V + k_-V + k_Hy, j = 2 e N_s k_V k_Hy / S,
              alpha = w_Hy alpha_V + (1 - w_Hy) alpha_Hy + w_-V   (w_s = k_s/S).
  The donor concentration multiplies k_V and k_Hy (hence k_-V) of D alike, so it cancels from alpha and from
  K = (j_H/c_H)/(j_D/c_D); the model K below is therefore exp(ln j_H - ln j_D) without it.
Tafel step and the back-Heyrovsky step are excluded; Langmuir adsorption.   [model calculation]"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import os
import sys
import numpy as np

sys.path.insert(0, _PKG + '/work/integrated')
from model import MHC, KT                                   # noqa: E402
from model_ext import ModelX, DDG_ADS                       # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
R_LL = 0.7414
LN10 = np.log(10.0)


def _lse(a, axis=None):
    m = np.max(a, axis=axis, keepdims=True)
    return (m + np.log(np.exp(a - m).sum(axis=axis, keepdims=True))).squeeze(axis) if axis is not None else \
        float(m.ravel()[0] + np.log(np.exp(a - m).sum()))


class VH:
    def __init__(self, lev_hy=os.path.join(HERE, 'levels_hy.npz'), delta_D=DDG_ADS, mu_max=3, nu_max=8, d0=0.5,
                 beta_el=1.0, r_ll=R_LL):
        self.MV = ModelX(delta_D=delta_D, mu_max=mu_max, nu_max=nu_max, d0=d0, beta_el=beta_el)
        z = np.load(lev_hy)
        assert np.allclose(z['d'], self.MV.d)
        self.d, self.d0, self.r_ll, self.delta_D = self.MV.d, d0, r_ll, float(delta_D)
        k0 = int(np.argmin(np.abs(self.d - d0)))
        self.Eref = float(z['eP_H'][k0, 0] - z['eR_H'][k0, 0])
        self.zpe = float(z['eP_D'][k0, 0] - z['eR_D'][k0, 0]) - self.Eref
        self.shift = {'H': 0.0, 'D': -self.delta_D - self.zpe}       # Heyrovsky: -delta_D (thermodynamic cycle)
        self.ch = {}
        for iso in ('H', 'D'):
            eRall = z['eR_' + iso]
            eR, eP = eRall[:, :mu_max], z['eP_' + iso][:, :nu_max]
            S = z['S_' + iso][:, :mu_max, :nu_max]
            G = eP[:, None, :] - eR[:, :, None] - self.Eref + self.shift[iso]
            lnPmu = (-(eR - eRall[:, :1]) / KT
                     - np.log(np.exp(-(eRall - eRall[:, :1]) / KT).sum(1))[:, None])
            lnWc = (np.log(np.maximum(S ** 2, 1e-300)) + lnPmu[:, :, None]
                    + (-beta_el * (self.d - d0))[:, None, None])
            self.ch[iso] = dict(G=G, lnW=lnWc + self.MV.lnw[:, None, None])

    # ---------------------------------------------------------------- potential fraction
    def f_V(self, p, med):
        return np.clip(p['f0_' + med] + p['f1_' + med] * (self.d - self.d0), 0.0, 1.0)

    def f_Hy(self, p, med):
        return np.clip(p['f0_' + med] + p['f1_' + med] * (self.d + self.r_ll - self.d0), 0.0, 1.0)

    # ---------------------------------------------------------------- Heyrovsky rate (without rho)
    def lnk_hy(self, iso, med, eta, p, mhc, detail=False):
        eta = np.atleast_1d(np.asarray(eta, float))
        c = self.ch[iso]
        f = self.f_Hy(p, med)
        a = (1.0 - f) if med == 'acid' else np.zeros_like(f)
        G = -p['dE0_' + med] + c['G'][None] - f[None, :, None, None] * eta[:, None, None, None]
        lnF, dlnF = mhc(G)
        lnkc = (c['lnW'][None] + self.MV.lnPB[iso][None, :, None, None]
                + (a[None, :] * eta[:, None] / KT)[:, :, None, None] + lnF)
        m = lnkc.max(axis=(1, 2, 3), keepdims=True)
        w = np.exp(lnkc - m)
        J = w.sum(axis=(1, 2, 3))
        ac = a[None, :, None, None] + f[None, :, None, None] * (-KT * dlnF)
        alpha = (w * ac).sum(axis=(1, 2, 3)) / J
        lnk = m[:, 0, 0, 0] + np.log(J)
        if detail:
            return lnk, alpha, w / J[:, None, None, None]
        return lnk, alpha

    # ---------------------------------------------------------------- steady state
    def solve(self, iso, med, eta, p, mhc):
        """ln j (+ const), alpha and the step quantities at overpotentials eta (V, positive)."""
        eta = np.atleast_1d(np.asarray(eta, float))
        pv = {'dE0_' + med: p['dE0_' + med], 'f0_' + med: p['f0_' + med], 'f1_' + med: p['f1_' + med]}
        lkV, aV = self.MV.lnj_alpha(iso, med, eta, pv, mhc)
        lkHy0, aHy = self.lnk_hy(iso, med, eta, p, mhc)
        lkHy = lkHy0 + LN10 * p['lrho_' + med]
        dI = self.delta_D if iso == 'D' else 0.0
        lkmV = lkV + (p['dE0_' + med] + dI - eta) / KT
        L = np.vstack([lkV, lkmV, lkHy])
        lS = _lse(L, axis=0)
        wV, wmV, wHy = np.exp(L - lS[None])
        lnj = np.log(2.0) + lkV + lkHy - lS
        alpha = wHy * aV + (1.0 - wHy) * aHy + wmV
        return dict(lnj=lnj, alpha=alpha, theta=wV, wV=wV, wmV=wmV, wHy=wHy, aV=aV, aHy=aHy,
                    lkV=lkV, lkmV=lkmV, lkHy=lkHy)

    def alpha(self, iso, med, eta, p, mhc):
        return self.solve(iso, med, eta, p, mhc)['alpha']

    def lnj(self, iso, med, eta, p, mhc):
        return self.solve(iso, med, eta, p, mhc)['lnj']
