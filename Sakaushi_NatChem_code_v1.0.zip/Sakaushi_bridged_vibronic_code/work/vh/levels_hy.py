"""doc 64 step 1: proton levels and overlaps of the Heyrovsky step (bonding Morse terms only, as approved).
  reactant : O-L Morse of the donor (D_e 119 kcal/mol, omega 2600 cm-1, r_e 0.9575 A)  -- as in the Volmer model
  product  : L-L Morse, H2 constants (Huber & Herzberg 1979): omega_e 4401.21 cm-1, r_e 0.74144 A, D_e 4.748 eV
             (D_0 4.4781 eV + zero-point energy). L* fixed; the moving isotope has mass m_i, so the model reproduces
             omega(H2) for H and gives omega(H2)/sqrt(m_D/m_H) for D.
  coordinate x = r - r_LL (r: distance of the moving L from L*), product well at x = 0, reactant well at x = d,
  d = R' - r_OL - r_LL (R' = O...L* distance); grid d = 0-1.32 A in 0.01 A steps (the Volmer grid).
Checks: product ground level against the analytic Morse value; dx halved.
Output levels_hy.npz: d, eR_i, eP_i (eV, absolute, from the well bottoms), S_i[k, mu, nu].   [model calculation]"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import sys, time, json
import numpy as np
sys.path.insert(0, _PKG + '/work/stage1_morse_overlap')
from morse_dvr import MorsePair, morse_levels_analytic, CM1_TO_KCAL, MASS

EV = 23.060548                       # kcal/mol per eV
H2 = dict(we=4401.21, re=0.74144, D0=4.4781, De=4.748)
D_LL, W_LL = H2['De'] * EV, H2['we']
D_OL, W_OL = 119.0, 2600.0
NST = 10


def build(dx, dgrid, n=NST):
    mp = MorsePair(D_OL, W_OL, D_LL, W_LL, x_min=-1.0, x_max=2.8, dx=dx, n_states=n)
    out = {}
    for iso in 'HD':
        ep, cp = mp.product_states(iso)
        eR = np.zeros((len(dgrid), n)); eP = np.tile(ep, (len(dgrid), 1)); S = np.zeros((len(dgrid), n, n))
        for k, d in enumerate(dgrid):
            er, cr = mp.reactant_states(iso, float(d))
            eR[k], S[k] = er, cr.T @ cp
        out[iso] = dict(eR=eR / EV, eP=eP / EV, S=S)
    return mp, out


if __name__ == '__main__':
    t0 = time.time()
    log = {}
    d = np.round(np.arange(0.0, 1.3201, 0.01), 4)
    mp, T = build(0.0025, d)
    print(f'beta_OL {mp.beta_AH:.4f} 1/A, beta_LL {mp.beta_MH:.4f} 1/A (moving mass m_H; real H2, reduced mass m_H/2: 1.94 A^-1)')
    # check 1: product ground level vs analytic Morse
    for iso in 'HD':
        ea, hw, wexe, vmax = morse_levels_analytic(mp.beta_MH, D_LL, iso, 3)
        e_dvr = T[iso]['eP'][0, :3] * EV
        print(f'[check] L-L Morse {iso}: hbar w = {hw / CM1_TO_KCAL:.1f} cm-1, ZPE analytic {ea[0] / EV * 1000:.3f} meV, '
              f'DVR {e_dvr[0] / EV * 1000:.3f} meV, |diff| {abs(e_dvr[0] - ea[0]) / EV * 1e3:.1e} meV; '
              f'E1-E0 analytic {(ea[1] - ea[0]) / EV * 1000:.2f}, DVR {(e_dvr[1] - e_dvr[0]) / EV * 1000:.2f} meV')
        log[f'LL_{iso}'] = dict(hw_cm=hw / CM1_TO_KCAL, zpe_an_meV=ea[0] / EV * 1e3, zpe_dvr_meV=e_dvr[0] / EV * 1e3)
    for iso in 'HD':
        ea, hw, _, _ = morse_levels_analytic(mp.beta_AH, D_OL, iso, 2)
        e_dvr = T[iso]['eR'][-1, 0] * EV
        print(f'[check] O-L Morse {iso} (d = 1.32 A): ZPE analytic {ea[0] / EV * 1000:.3f} meV, DVR {e_dvr / EV * 1000:.3f} meV')
    # check 2: dx halved at a few d
    dchk = np.array([0.1, 0.3, 0.5, 0.9, 1.3])
    _, a = build(0.0025, dchk); _, b = build(0.00125, dchk)
    for iso in 'HD':
        s2a, s2b = a[iso]['S'][:, :3, :8] ** 2, b[iso]['S'][:, :3, :8] ** 2
        m = s2b > 1e-20                  # below ~1e-25 the DVR overlaps are at their numerical floor
        rel = np.abs(s2a[m] / s2b[m] - 1).max()
        dE = max(np.abs(a[iso]['eR'][:, :3] - b[iso]['eR'][:, :3]).max(), np.abs(a[iso]['eP'][:, :8] - b[iso]['eP'][:, :8]).max())
        print(f'[check] dx 0.0025 vs 0.00125, {iso}: max rel diff |S_mu nu|^2 > 1e-20 (mu<=2, nu<=7) {rel:.1e}; max |dE| {dE * 1e3:.1e} meV')
        log[f'dx_{iso}'] = dict(rel_S2=float(rel), dE_meV=float(dE * 1e3))
    k0 = int(np.argmin(np.abs(d - 0.5)))
    for iso in 'HD':
        g = T[iso]['eP'][:, 0] - T[iso]['eR'][:, 0]
        s2 = T[iso]['S'][:, 0, 0] ** 2
        print(f'  {iso}: eP0-eR0 {g[k0]:.4f} eV (d = 0.5); |S00|^2 at d = 0.1/0.3/0.5/0.9/1.3:',
              ' '.join('%.2e' % s2[int(np.argmin(np.abs(d - x)))] for x in (0.1, 0.3, 0.5, 0.9, 1.3)))
    sh = (T['D']['eP'][k0, 0] - T['D']['eR'][k0, 0]) - (T['H']['eP'][k0, 0] - T['H']['eR'][k0, 0])
    print(f'  zero-point shift of the Heyrovsky (0,0) driving force, D - H (d = 0.5 A): {sh * 1e3:+.2f} meV')
    log['zpe_shift_meV'] = float(sh * 1e3)
    np.savez('levels_hy.npz', d=d, **{f'{k}_{iso}': v for iso in 'HD' for k, v in T[iso].items()})
    json.dump(log, open('levels_hy.json', 'w'), indent=1)
    print(f'saved levels_hy.npz ({len(d)} points), {time.time() - t0:.0f} s')
