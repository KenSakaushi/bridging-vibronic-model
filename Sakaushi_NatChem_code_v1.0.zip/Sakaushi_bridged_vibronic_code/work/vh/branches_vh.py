"""doc 64: the second branches found in the VH fits (the listed local minima, polished from their rounded values),
evaluated with the same outputs as fit_vh.py. No new starting points or data.   [fit] [model calculation]"""
import json, numpy as np
from scipy.optimize import least_squares
import fit_vh as F

BR = {'alk': [0.644, 0.558, 1.236, -1.631], 'acid_new': [0.093, 0.718, 0.446, 0.493],
      'acid_trim': [0.161, 1.0 - 1e-6, 1.453, -0.084]}
out = {}
for which, x0 in BR.items():
    med, obs = F.DATA[which]
    names = [f'dE0_{med}', f'f0_{med}', f'f1_{med}', f'lrho_{med}']
    lo = np.array([F.BND[n.split('_')[0]][0] for n in names]); hi = np.array([F.BND[n.split('_')[0]][1] for n in names])
    s = least_squares(F.resid, np.clip(x0, lo + 1e-9, hi - 1e-9), args=(names, med, obs, {'lam': F.LAM}),
                      bounds=(lo, hi), x_scale='jac', max_nfev=500)
    p = dict({'lam': F.LAM}, **dict(zip(names, s.x)))
    sm = F.summary(p, med, obs, names)
    fe = F.features(p, med)
    ref = json.load(open(f'fit_vh_{which}.json'))
    dA = sm['AICc'] - ref['volmer']['summary']['AICc']; dB = sm['BIC'] - ref['volmer']['summary']['BIC']
    g = np.array(fe['grid'])
    print(f'[{which} branch 2] rms {sm["rms"]:.4f} (H {sm["per"]["H"]["rms"]:.4f}, D {sm["per"]["D"]["rms"]:.4f}); '
          f'x {[round(v, 4) for v in s.x]}; AICc {sm["AICc"]:.1f} (dAICc vs Volmer {dA:+.1f}), BIC {sm["BIC"]:.1f} ({dB:+.1f})')
    for iso in 'HD':
        Fi = fe[iso]
        xs = (0.10, 0.20, 0.30, 0.40) if med == 'acid' else (0.30, 0.40, 0.50, 0.60)
        print(f'   {iso}: steepest {Fi["steepest"][0]:+.2f} V^-1 at {Fi["steepest"][1]:.3f} V; theta at {xs}: '
              f'{[round(float(np.interp(x, g, Fi["theta"])), 3) for x in xs]}; w_Hy {[round(float(np.interp(x, g, Fi["wHy"])), 3) for x in xs]}')
    print('   Delta alpha (windows):', {k: round(v[0], 4) for k, v in fe['dalpha_win'].items()})
    print('   log K model vs measured:', ' '.join(f'{e:.3f}:{m:+.2f}/{o:+.2f}' for e, m, o in
                                               zip(fe['logK_vs_meas']['eta'], fe['logK_vs_meas']['model'], fe['logK_vs_meas']['meas'])))
    print('   residuals D:', ' '.join(f'{e:.2f}:{r:+.3f}' for e, r in zip(obs['D'][0], sm['per']['D']['res'])))
    out[which] = dict(x=list(map(float, s.x)), p=p, summary=sm, features=fe, dAICc=dA, dBIC=dB)
json.dump(out, open('branches_vh.json', 'w'), indent=1, default=float)
