"""doc 64 step 2: validation of the VH model.
 (1) rho -> infinity (log10 rho = 15) reproduces the Volmer-only model (doc 59 acid, new data; doc 47 alkali).
 (2) the analytic alpha (w_Hy alpha_V + (1 - w_Hy) alpha_Hy + w_-V) equals kT d ln j / d|eta| (numerical).
 (3) for orientation: step weights at an intermediate rho.   [model calculation]"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import sys, json
import numpy as np
sys.path.insert(0, _PKG + '/work/integrated')
from vh_model import VH, KT
from acid59_model import SETS, get_mhc
from model import OBS

f59 = json.load(open(_PKG + '/work/integrated/f1_59.json'))
r47 = {r['tag']: r for r in json.load(open(_PKG + '/work/integrated/results_47.json'))}
P = {'acid': {k: f59['new']['p'][k] for k in ('dE0_acid', 'f0_acid', 'f1_acid')},
     'alk': {k: r47['T4|base|alk']['p'][k] for k in ('dE0_alk', 'f0_alk', 'f1_alk')}}
DATA = {'acid': SETS['new'], 'alk': {'H': OBS[('H', 'alk')], 'D': OBS[('D', 'alk')]}}
V = VH()
mhc = get_mhc(0.3)
out = {}
print(f'Heyrovsky reference: Eref {V.Eref:.4f} eV, zero-point shift D-H {V.zpe * 1e3:+.2f} meV, '
      f'D shift applied {V.shift["D"] * 1e3:+.2f} meV (target -delta_D = {-V.delta_D * 1e3:.2f} meV)')
for med in ('acid', 'alk'):
    p = dict(P[med]); p['lrho_' + med] = 15.0
    dmax = 0.0
    for iso in 'HD':
        e = np.array(DATA[med][iso][0])
        a_vh = V.alpha(iso, med, e, p, mhc)
        a_v = V.MV.lnj_alpha(iso, med, e, P[med], mhc)[1]
        dmax = max(dmax, float(np.abs(a_vh - a_v).max()))
    rms = []
    for iso in 'HD':
        e, a = DATA[med][iso]
        rms.append(float(np.sqrt(np.mean((V.alpha(iso, med, e, p, mhc) - np.array(a)) ** 2))))
    print(f'[1] {med}: log10 rho = 15, max |alpha_VH - alpha_V| = {dmax:.1e}; rms H {rms[0]:.4f} D {rms[1]:.4f}')
    out[f'rho_inf_{med}'] = dict(dmax=dmax, rmsH=rms[0], rmsD=rms[1])
# (2) analytic vs numerical alpha at intermediate rho, and (3) step weights
g = np.round(np.arange(0.05, 0.4001, 0.01), 3)
h = 1e-4
for med, lrhos in (('acid', (-6.0, -3.0, 0.0)), ('alk', (-9.0, -6.0, -3.0))):
    for lr in lrhos:
        p = dict(P[med]); p['lrho_' + med] = lr
        dm = 0.0
        for iso in 'HD':
            s = V.solve(iso, med, g, p, mhc)
            num = KT * (V.lnj(iso, med, g + h, p, mhc) - V.lnj(iso, med, g - h, p, mhc)) / (2 * h)
            dm = max(dm, float(np.abs(num - s['alpha']).max()))
        sH = V.solve('H', med, [0.1, 0.2, 0.3, 0.45], p, mhc)
        print(f'[2] {med} log10 rho {lr:+.0f}: max |alpha - kT dlnj/deta| = {dm:.1e} | H at 0.10/0.20/0.30/0.45 V: '
              f'theta {np.round(sH["theta"], 3).tolist()}, w_Hy {np.round(sH["wHy"], 3).tolist()}, '
              f'w_-V {np.round(sH["wmV"], 3).tolist()}')
        out[f'num_{med}_{lr:+.0f}'] = dm
json.dump(out, open('validate_vh.json', 'w'), indent=1)
