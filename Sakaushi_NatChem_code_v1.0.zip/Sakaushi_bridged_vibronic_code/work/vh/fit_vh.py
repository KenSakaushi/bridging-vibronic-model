"""doc 64 step 3-4: fits of the VH extension at lambda = 0.3 eV and the outputs of doc 64 sec. 6.
Data [fit]: acid new (H 10, D 13; doc 26/34/58), acid trim (D 11, the two low-current points removed), alkali (H 5, D 7).
Parameters per medium: dE0, f0, f1, log10 rho (bounds -0.6-1.2 eV, 0.1-1, -2-2 1/A, -15-15). Starts: 32 random, plus
the Volmer-only solution at several log10 rho (warm). The Volmer-only fits (rho -> infinity) are refitted with the same
driver for the information criteria.   [fit] [model calculation]
Usage: python3 fit_vh.py acid_new | acid_trim | alk"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import sys, json, time
import numpy as np
from scipy.optimize import least_squares
sys.path.insert(0, _PKG + '/work/integrated')
from vh_model import VH, KT
from acid59_model import SETS, get_mhc
from model import OBS
from model_ext import info

LAM = 0.3
BND = {'dE0': (-0.6, 1.2), 'f0': (0.1, 1.0), 'f1': (-2.0, 2.0), 'lrho': (-15.0, 15.0)}
DATA = {'acid_new': ('acid', SETS['new']), 'acid_trim': ('acid', SETS['trim']),
        'alk': ('alk', {'H': OBS[('H', 'alk')], 'D': OBS[('D', 'alk')]})}
KFIG = json.load(open(_PKG + '/figs/k_fig.json'))
f59 = json.load(open(_PKG + '/work/integrated/f1_59.json'))
r47 = {r['tag']: r for r in json.load(open(_PKG + '/work/integrated/results_47.json'))}
V = VH()
mhc = get_mhc(LAM)


def resid(x, names, med, obs, fixed):
    p = dict(fixed); p.update(zip(names, x))
    r = []
    for iso in 'HD':
        e, a = obs[iso]
        r.extend(V.alpha(iso, med, np.array(e), p, mhc) - np.array(a))
    return np.array(r)


def fit(names, med, obs, fixed, starts, max_nfev=300):
    lo = np.array([BND[n.split('_')[0]][0] for n in names]); hi = np.array([BND[n.split('_')[0]][1] for n in names])
    sols = []
    for x0 in starts:
        x0 = np.clip(np.asarray(x0, float), lo + 1e-9, hi - 1e-9)
        try:
            s = least_squares(resid, x0, args=(names, med, obs, fixed), bounds=(lo, hi), x_scale='jac',
                              max_nfev=max_nfev)
        except Exception as ex:
            print('   start failed:', ex, flush=True)
            continue
        sols.append(s)
    best = min(sols, key=lambda s: s.cost)
    rms_b = np.sqrt(2 * best.cost / len(best.fun))
    nconv = sum(1 for s in sols if np.sqrt(2 * s.cost / len(s.fun)) - rms_b < 5e-4)
    at_b = [n for n, v, l, h in zip(names, best.x, lo, hi) if min(v - l, h - v) < 1e-3 * (h - l)]
    return best, nconv, len(sols), at_b, sols


def summary(p, med, obs, names):
    res = []
    per = {}
    for iso in 'HD':
        e, a = obs[iso]
        m = V.alpha(iso, med, np.array(e), p, mhc)
        r = m - np.array(a)
        per[iso] = dict(rms=float(np.sqrt(np.mean(r ** 2))), model=np.round(m, 4).tolist(), res=np.round(r, 4).tolist())
        res.extend(r)
    res = np.array(res)
    rss = float((res ** 2).sum()); n, k = len(res), len(names)
    aicc, bic = info(rss, n, k)
    return dict(rms=float(np.sqrt(np.mean(res ** 2))), per=per, rss=rss, n=n, k=k, AICc=aicc, BIC=bic)


def features(p, med):
    g = np.round(np.arange(0.05, 0.6001, 0.0025), 4) if med == 'alk' else np.round(np.arange(0.05, 0.4001, 0.0025), 4)
    S = {iso: V.solve(iso, med, g, p, mhc) for iso in 'HD'}
    f = {'grid': g.tolist()}
    for iso in 'HD':
        s = S[iso]
        a = s['alpha']; sl = np.gradient(a, g)
        sub = g >= (0.10 if med == 'acid' else 0.25)
        f[iso] = dict(alpha=np.round(a, 5).tolist(), theta=np.round(s['theta'], 5).tolist(),
                      wHy=np.round(s['wHy'], 5).tolist(), wmV=np.round(s['wmV'], 5).tolist(),
                      aV=np.round(s['aV'], 5).tolist(), aHy=np.round(s['aHy'], 5).tolist(),
                      peak=(float(a[sub].max()), float(g[sub][np.argmax(a[sub])])),
                      steepest=(float(sl.min()), float(g[np.argmin(sl)])))
    lnK = S['H']['lnj'] - S['D']['lnj']
    f['logK'] = np.round(lnK / np.log(10), 5).tolist()
    cr = [float(g[i] + (g[i + 1] - g[i]) * lnK[i] / (lnK[i] - lnK[i + 1])) for i in range(len(g) - 1)
          if lnK[i] > 0 >= lnK[i + 1]]
    f['K1_cross'] = cr[0] if cr else None
    # step KIEs (rate constants of each step, same |eta|)
    f['kie_V'] = np.round((S['H']['lkV'] - S['D']['lkV']) / np.log(10), 4).tolist()
    f['kie_Hy'] = np.round((S['H']['lkHy'] - S['D']['lkHy']) / np.log(10), 4).tolist()
    # windows (linear fit of ln j over the window, as for the data)
    wins = [(0.12, 0.248), (0.0875, 0.2972)] if med == 'acid' else [(0.30, 0.479)]
    f['dalpha_win'] = {}
    for lo, hi in wins:
        gg = np.linspace(lo, hi, 41)
        aw = {iso: KT * np.polyfit(gg, V.lnj(iso, med, gg, p, mhc), 1)[0] for iso in 'HD'}
        f['dalpha_win'][f'{lo}-{hi}'] = (float(aw['H'] - aw['D']), float(aw['H']), float(aw['D']))
    # level crossings of the falling alpha (D delay)
    f['cross_levels'] = {}
    for lev in (0.75, 0.70, 0.60, 0.50, 0.42):
        row = {}
        for iso in 'HD':
            a = np.array(f[iso]['alpha'])
            idx = [i for i in range(len(g) - 1) if a[i] >= lev > a[i + 1]]
            row[iso] = float(g[idx[-1]] + (g[idx[-1] + 1] - g[idx[-1]]) * (a[idx[-1]] - lev) / (a[idx[-1]] - a[idx[-1] + 1])) if idx else None
        f['cross_levels'][str(lev)] = row
    # log K at the measured points
    if med == 'acid':
        e, lk = KFIG['acid']['eta'], KFIG['acid']['logK']
    else:
        e, lk = KFIG['alk']['eta'], KFIG['alk']['KOD98']['logK']
    lm = (V.lnj('H', med, np.array(e), p, mhc) - V.lnj('D', med, np.array(e), p, mhc)) / np.log(10)
    f['logK_vs_meas'] = dict(eta=e, model=np.round(lm, 4).tolist(), meas=lk)
    return f


def main(which):
    t0 = time.time()
    med, obs = DATA[which]
    names = [f'dE0_{med}', f'f0_{med}', f'f1_{med}', f'lrho_{med}']
    fixed = {'lam': LAM}
    # Volmer-only reference with the same driver (rho fixed at 10^15)
    if med == 'acid':
        w = f59['new' if which == 'acid_new' else 'trim']['p']
    else:
        w = r47['T4|base|alk']['p']
    xv = [w[f'dE0_{med}'], min(w[f'f0_{med}'], 0.999999), w[f'f1_{med}']]
    rng = np.random.default_rng(6400 + len(which))
    lo = np.array([BND[n.split('_')[0]][0] for n in names[:3]]); hi = np.array([BND[n.split('_')[0]][1] for n in names[:3]])
    stV = [xv] + [lo + (hi - lo) * rng.random(3) for _ in range(8)]
    bV, ncV, nsV, abV, _ = fit(names[:3], med, obs, dict(fixed, **{f'lrho_{med}': 15.0}), stV)
    pV = dict(fixed, **dict(zip(names[:3], bV.x)), **{f'lrho_{med}': 15.0})
    sV = summary(pV, med, obs, names[:3])
    print(f'[{which}] Volmer only (log10 rho = 15): rms {sV["rms"]:.4f} (H {sV["per"]["H"]["rms"]:.4f}, D {sV["per"]["D"]["rms"]:.4f}); '
          f'p {[round(v, 4) for v in bV.x]}, bound {abV}, conv {ncV}/{nsV}; AICc {sV["AICc"]:.1f}, BIC {sV["BIC"]:.1f}  '
          f'({time.time() - t0:.0f} s)', flush=True)
    # VH fit: 32 random starts + warm starts (Volmer solution at several rho)
    lo4 = np.array([BND[n.split('_')[0]][0] for n in names]); hi4 = np.array([BND[n.split('_')[0]][1] for n in names])
    starts = [lo4 + (hi4 - lo4) * rng.random(4) for _ in range(32)]
    starts += [list(bV.x) + [lr] for lr in (10.0, 5.0, 2.0, 0.0, -2.0, -5.0)]
    best, nconv, ns, at_b, sols = fit(names, med, obs, fixed, starts)
    p = dict(fixed, **dict(zip(names, best.x)))
    s = summary(p, med, obs, names)
    print(f'[{which}] VH: rms {s["rms"]:.4f} (H {s["per"]["H"]["rms"]:.4f}, D {s["per"]["D"]["rms"]:.4f}); '
          f'p {[round(v, 4) for v in best.x]}, bound {at_b}, conv {nconv}/{ns}; AICc {s["AICc"]:.1f} '
          f'(dAICc {s["AICc"] - sV["AICc"]:+.1f}), BIC {s["BIC"]:.1f} (dBIC {s["BIC"] - sV["BIC"]:+.1f})  '
          f'({time.time() - t0:.0f} s)', flush=True)
    # distinct local minima (for the record)
    loc = sorted({(round(float(np.sqrt(2 * q.cost / len(q.fun))), 4), tuple(np.round(q.x, 3))) for q in sols})[:8]
    for r_, x_ in loc:
        print(f'     local: rms {r_:.4f} x {list(x_)}')
    fe = features(p, med)
    feV = features(pV, med)
    out = dict(which=which, med=med, names=names, volmer=dict(x=list(map(float, bV.x)), summary=sV, conv=f'{ncV}/{nsV}',
               features=feV), vh=dict(x=list(map(float, best.x)), p=p, summary=s, conv=f'{nconv}/{ns}', at_bound=at_b,
               features=fe, locals=[dict(rms=r_, x=list(x_)) for r_, x_ in loc]), sec=round(time.time() - t0, 1))
    json.dump(out, open(f'fit_vh_{which}.json', 'w'), indent=1, default=float)
    # short report
    g = np.array(fe['grid'])
    for iso in 'HD':
        F = fe[iso]
        print(f'   {iso}: alpha peak {F["peak"][0]:.3f} at {F["peak"][1]:.3f} V; steepest {F["steepest"][0]:+.2f} V^-1 at '
              f'{F["steepest"][1]:.3f} V; theta at 0.10/0.20/0.30/0.40 V '
              f'{[round(float(np.interp(x, g, F["theta"])), 3) for x in (0.10, 0.20, 0.30, 0.40)]}; w_Hy '
              f'{[round(float(np.interp(x, g, F["wHy"])), 3) for x in (0.10, 0.20, 0.30, 0.40)]}; w_-V '
              f'{[round(float(np.interp(x, g, F["wmV"])), 3) for x in (0.10, 0.20, 0.30, 0.40)]}')
    print('   Delta alpha (windows):', {k: round(v[0], 4) for k, v in fe['dalpha_win'].items()})
    print('   log K model vs measured:', ' '.join(f'{e:.3f}:{m:+.2f}/{o:+.2f}' for e, m, o in
                                               zip(fe['logK_vs_meas']['eta'], fe['logK_vs_meas']['model'], fe['logK_vs_meas']['meas'])),
          '| K = 1 at', fe['K1_cross'])
    print('   residuals D:', ' '.join(f'{e:.2f}:{r:+.3f}' for e, r in zip(obs['D'][0], s['per']['D']['res'])))
    print('   level crossings (H, D):', {k: (None if v['H'] is None else round(v['H'], 3), None if v['D'] is None else round(v['D'], 3))
                                         for k, v in fe['cross_levels'].items()})
    print(f'[{which}] done, {time.time() - t0:.0f} s', flush=True)


if __name__ == '__main__':
    main(sys.argv[1])
