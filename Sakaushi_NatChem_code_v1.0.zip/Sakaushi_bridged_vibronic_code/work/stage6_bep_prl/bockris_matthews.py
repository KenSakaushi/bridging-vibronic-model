"""The ACTUAL Bockris-Matthews construction, not the BEP caricature I used.

WHAT I IMPLEMENTED IN STAGE 2' (and mislabelled "Bockris-Matthews type")

    V0(eta) = V0(0) + beta e eta,   beta = 0.5 imposed,  WIDTH a1 FIXED

That is the same linear-height shortcut the PRL uses.  It is not what
Bockris & Matthews do.

WHAT BOCKRIS-MATTHEWS ACTUALLY DOES  (Gurney / Butler / Horiuti-Polanyi
intersecting-potential-energy-curve tradition)

    reactant : proton bound in H3O+ / H2O at the OHP     U_R(x)   Morse
    product  : proton adsorbed as M-H                    U_P(x)   Morse, mirrored

    The electron is taken from the metal AT THE FERMI LEVEL.  Changing the
    electrode potential by eta changes that electron's energy by -e*eta, so
    THE WHOLE PRODUCT CURVE IS DISPLACED VERTICALLY by e*eta.  Nothing else
    in the picture moves.

    The barrier is then the INTERSECTION of two fixed curves, one of which
    slides vertically.  Everything follows from where they now cross:

      * the height falls                      (this is BEP, derived not assumed)
      * the crossing MOVES ALONG x, so the WIDTH changes too
      * beta is not imposed - it is the ratio of slopes at the crossing,
            beta = |dU_R/dx| / (|dU_R/dx| + |dU_P/dx|)  at x*
        which is where "beta = 0.5" comes from in the first place, and which
        VARIES with eta (Tafel curvature).

So the PRL's fixed width a = 0.3 A is a simplification RELATIVE TO
Bockris-Matthews, not a rendering of it.  And my stage 2' inherited that
simplification while claiming the Bockris-Matthews label.

WHY THIS MATTERS FOR A STANDING CLAIM
Executive-summary item (f) says the 1-D tunnelling picture gives
dKIE/d|eta| < 0 "structurally".  That was computed with the width HELD FIXED.
The intersecting-parabola geometry says the imaginary frequency goes as
hbar w# ~ (1 + sqrt(u)) - i.e. it RISES as the crossing moves - so letting the
width move could flip the sign.  This script tests exactly that.

Units: kcal/mol, Angstrom, amu (stage 1 conventions).
"""

import os
import sys
import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in ("stage3a_R_integral", "stage2_vibronic_rate", "stage1_morse_overlap"):
    sys.path.insert(0, os.path.join(_HERE, "..", _p))

from proton_potentials import ProtonPotentials                       # noqa
from morse_dvr import hbar2_over_2m, KB_KCAL                         # noqa

line = "=" * 76
EV = 23.060548
T = 298.15
kT = KB_KCAL * T
D_STAR = 0.474                      # dominant donor-acceptor gap, stage 3a


def barrier_profile(pot, R, shift):
    """Diabatic two-curve barrier V(x) = min(U_R, U_P + shift).

    Reactant well sits at x = d (donor side), product well at x = 0 (metal).
    The lower envelope of the two diabatic curves is the path the proton
    takes, with a cusp at the crossing.
    """
    UR = pot.U_reactant(R)
    UP = pot.U_product(R) + shift
    return np.minimum(UR, UP), UR, UP


def crossing(pot, R, shift):
    """x*, barrier height above the reactant minimum, and the local beta."""
    x = pot.x
    UR = pot.U_reactant(R)
    UP = pot.U_product(R) + shift
    iR, iP = int(np.argmin(UR)), int(np.argmin(UP))
    lo, hi = (iP, iR) if iP < iR else (iR, iP)
    g = UR[lo:hi + 1] - UP[lo:hi + 1]
    s = np.where(np.diff(np.sign(g)) != 0)[0]
    if len(s) == 0:
        return None
    j = lo + int(s[0])
    den = (UR[j + 1] - UP[j + 1]) - (UR[j] - UP[j])
    t = 0.0 if den == 0 else -(UR[j] - UP[j]) / den
    xs = x[j] + t * (x[j + 1] - x[j])
    Vtop = float(np.interp(xs, x, UR))
    dR = abs(np.interp(xs, x, np.gradient(UR, x)))
    dP = abs(np.interp(xs, x, np.gradient(UP, x)))
    beta = dR / (dR + dP) if (dR + dP) > 0 else np.nan
    return xs, Vtop - UR[iR], beta, UR[iR], UP[iP] - UR[iR]


def theta(pot, R, shift, E, iso):
    """WKB action across the forbidden region between the two wells."""
    x = pot.x
    V, UR, UP = barrier_profile(pot, R, shift)
    iR, iP = int(np.argmin(UR)), int(np.argmin(UP))
    lo, hi = (iP, iR) if iP < iR else (iR, iP)
    seg, xs = V[lo:hi + 1], x[lo:hi + 1]
    m = seg > E
    if not m.any():
        return 0.0
    C = hbar2_over_2m(iso)
    return 2.0 * float(np.trapezoid(np.sqrt((seg[m] - E) / C), xs[m]))


def kappa_bm(pot, R, shift, iso, n=1200):
    """Thermally averaged Kemble transmission, energies from the reactant min."""
    c = crossing(pot, R, shift)
    if c is None:
        return np.nan
    _, V1, _, UR0, dE = c
    Emin = max(dE, 0.0)                       # product level must be reachable
    Egrid = np.linspace(0.0, V1 + 25.0 * kT, n)
    P = np.zeros_like(Egrid)
    for i, E in enumerate(Egrid):
        if E < Emin:
            continue
        th = theta(pot, R, shift, UR0 + E, iso)
        P[i] = 1.0 / (1.0 + np.exp(np.clip(th, -600, 600)))
    return float(np.trapezoid(P * np.exp(-Egrid / kT), Egrid) / kT)


if __name__ == "__main__":
    pot = ProtonPotentials(nonbonding=True)
    R = pot.R_of_d(D_STAR)

    print(line)
    print("BOCKRIS-MATTHEWS: eta DISPLACES THE PRODUCT CURVE VERTICALLY")
    print(line)
    print(f"  R = {R:.3f} A (d = {D_STAR} A, the dominant gap of stage 3a), "
          f"T = {T} K")
    print("  shift = dE0 - e|eta|;  everything below follows from the moving")
    print("  intersection of two FIXED Morse curves.")

    DE0 = 12.0        # offset at eta = 0, kcal/mol; scanned below
    print(f"\n    {'|eta|/V':>8}{'shift':>9}{'x*/A':>8}{'V1':>9}"
          f"{'beta(geom)':>12}{'w(E=V1-2)':>12}")
    for e in (0.0, 0.1, 0.2, 0.3, 0.4, 0.5):
        sh = DE0 - e * EV
        c = crossing(pot, R, sh)
        if c is None:
            print(f"    {e:>8.2f}   no crossing")
            continue
        xs, V1, be, UR0, dE = c
        V, UR, UP = barrier_profile(pot, R, sh)
        iR, iP = int(np.argmin(UR)), int(np.argmin(UP))
        a_, b_ = (iP, iR) if iP < iR else (iR, iP)
        lev = UR0 + V1 - 2.0
        seg, xseg = V[a_:b_ + 1], pot.x[a_:b_ + 1]   # BETWEEN the two wells only
        mm = seg > lev
        w = float(xseg[mm][-1] - xseg[mm][0]) if mm.any() else 0.0
        print(f"    {e:>8.2f}{sh:>9.2f}{xs:>8.3f}{V1:>9.3f}{be:>12.3f}{w:>12.4f}")

    print("\n  -> the barrier height falls (BEP, DERIVED), the crossing MOVES,")
    print("     the width changes, and beta is geometric, not imposed at 0.5.")

    print("\n" + line)
    print("DOES THE SIGN OF dKIE/d|eta| SURVIVE WHEN THE WIDTH MAY MOVE?")
    print(line)
    print("  stage 2' (width FIXED, height linear) gave alpha_H - alpha_D =")
    print("  -0.015, i.e. dKIE/d|eta| < 0, and called it structural.")
    print(f"\n    {'|eta|/V':>8}{'V1':>9}{'kappa_H':>12}{'kappa_D':>12}"
          f"{'KIE_tunnel':>12}{'d logK/d|eta|':>15}")
    es = np.arange(0.0, 0.51, 0.05)
    ks = []
    for e in es:
        sh = DE0 - e * EV
        c = crossing(pot, R, sh)
        if c is None:
            ks.append(np.nan)
            continue
        kh = kappa_bm(pot, R, sh, "H")
        kd = kappa_bm(pot, R, sh, "D")
        ks.append(kh / kd)
    ks = np.array(ks)
    sl = np.gradient(np.log10(ks), es)
    for i, e in enumerate(es):
        if i % 2:
            continue
        sh = DE0 - e * EV
        c = crossing(pot, R, sh)
        V1 = c[1] if c else np.nan
        kh = kappa_bm(pot, R, sh, "H")
        kd = kappa_bm(pot, R, sh, "D")
        print(f"    {e:>8.2f}{V1:>9.3f}{kh:>12.3e}{kd:>12.3e}"
              f"{ks[i]:>12.3f}{sl[i]:>15.3f}")
    good = np.isfinite(sl)
    print(f"\n  sign of d logK/d|eta|:  min {sl[good].min():+.3f}, "
          f"max {sl[good].max():+.3f}")
    print("  -> " + ("NEGATIVE throughout: the stage-2' sign survives"
                     if sl[good].max() < 0 else
                     "CHANGES SIGN or is POSITIVE: the stage-2' claim that the"
                     " 1-D picture structurally gives dKIE/deta < 0 does NOT"
                     " survive once the width is allowed to move"))
    np.savez(os.path.join(_HERE, "results", "bockris_matthews.npz"),
             eta=es, kie=ks, slope=sl)
    print("\nwritten: results/bockris_matthews.npz")
    print(line)
