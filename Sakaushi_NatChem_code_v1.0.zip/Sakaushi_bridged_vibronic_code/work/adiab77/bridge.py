"""doc 77 (b): eq. (3) with corrections that bridge to the adiabatic limits, and refits.  [model] [fit]

Base (M0) = ModelX of doc 47 (eq. 3; alkaline, lambda 0.3 eV, omega 2600, delta_D 27.97 meV), with a selectable ladder.
Corrections (all multiply the non-adiabatic channel rates, so that switching them off returns M0 exactly):

  gs   Georgievskii-Stuchebrukhov electron-proton adiabaticity (J. Chem. Phys. 113, 10438 (2000)):
       V_mu,nu = V_el S_mu,nu * phi(p),  phi(p) = exp(p ln p - p)/Gamma(p + 1),  p = V_el^2/(hbar |dF| v_t)
       (phi -> 1 for p -> 0).  The channel rate is multiplied by phi(p)^2.  V_el = Delta0 (reading b).
  lam  Lam et al. JPCC 2020 (ref. 19) interpolation between non-adiabatic and solvent-controlled rates, per (R, mu):
       k_mu = k^LZ k^SC / (k^LZ + k^SC), applied as the factor 1/(1 + r_mu) on all nu channels of (R, mu) (doc 50 'p3')
       k^LZ = (pi/hbar) Delta(R) sum_nu |S_mu,nu|^2 [phi^2] F_lambda(dG_mu,nu)
       k^SC = (1/tau_L) sqrt(lambda/(pi kT)) exp[-B(dG_mu,0)/kT]
       B = (x + lambda)^2/(4 lambda)                      sc = "lam"  (crossing at the Fermi level, as ref. 19)
       B = (x+l)^2/(4l) for |x| <= l, x for x > l, 0 for x < -l   sc = "mg"  (thermally excited electrons above E_F)
       Delta(R) = Delta0(R) (reading b) or V0(R) (reading v, upper bound).
alpha is evaluated as kT d ln j / d eta by central differences (h = 1 mV).
"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import os
import sys
import time
import numpy as np
from scipy.optimize import least_squares
from scipy.special import gammaln, logsumexp

sys.path.insert(0, _PKG + "/work/integrated")
sys.path.insert(0, _PKG + "/work/adiab77")
from model_ext import ModelX, get_mhc, DDG_ADS, BND, info           # noqa: E402
from model import KT, OBS                                           # noqa: E402
import diag_a as A                                                  # noqa: E402

GEO = np.load(_PKG + "/work/adiab77/geo_full.npz")
WIN_NEW = (0.2496, 0.4786)
ENDS = [0.25, 0.479]
LOGK_OBS = (1.0863, 1.5837)          # KOD 98 % D, steps removed [arith; k_fig.json]
DA_OBS = 0.126                       # [fit; corrA.json]
P_BASE = dict(A.P_FIT)


def log_phi(p):
    p = np.where(np.isfinite(p), p, 0.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        out = np.where(p > 0, p * np.log(np.maximum(p, 1e-300)) - p - gammaln(p + 1.0), 0.0)
    return out


class ModelB:
    def __init__(self, mu_max=3, nu_max=8, gs=False, lam=False, reading="b", tau=0.46e-12, sc="lam",
                 scale=1.0):
        self.X = ModelX(delta_D=DDG_ADS, mu_max=mu_max, nu_max=nu_max)
        self.d = self.X.d
        self.gs, self.lam, self.reading, self.tau, self.sc, self.scale = gs, lam, reading, tau, sc, scale
        self.mu_max, self.nu_max = mu_max, nu_max
        V = A.couplings(self.d)
        self.Delta = scale * (V["b"] if reading == "b" else V["v"])          # (nd,) eV
        self.extra = {}
        for iso in "HD":
            c = self.X.ch[iso]
            lw = c["lnWc"] + self.X.lnw[:, None, None]
            lphi2 = np.zeros_like(lw)
            if gs:
                p = GEO[f"pGS_b_{iso}"][:, :mu_max, :nu_max]
                lphi2 = 2.0 * log_phi(p)
            lS2 = np.log(np.maximum(c["S"] ** 2, 1e-300))
            self.extra[iso] = dict(lnW=lw + lphi2, lS2phi=lS2 + lphi2)

    def B(self, x, lamb):
        if self.sc == "lam":
            return (x + lamb) ** 2 / (4 * lamb)
        return np.where(x > lamb, x, np.where(x < -lamb, 0.0, (x + lamb) ** 2 / (4 * lamb)))

    def lnjc(self, iso, eta, p, mhc):
        """log channel currents, shape (n_eta, nd, nmu, nnu), and log(1 + r) per (eta, d, mu)."""
        eta = np.atleast_1d(np.asarray(eta, float))
        c, e = self.X.ch[iso], self.extra[iso]
        f = self.X.f_of(p, "alk")
        G = p["dE0_alk"] + c["G"][None] - f[None, :, None, None] * eta[:, None, None, None]
        lnF, _ = mhc(G)
        out = e["lnW"][None] + self.X.lnPB[iso][None, :, None, None] + lnF
        l1r = None
        if self.lam:
            lam_ = p["lam"]
            lkLZ = (np.log(np.pi / A.HBAR) + np.log(self.Delta)[None, :, None]
                    + logsumexp(e["lS2phi"][None] + lnF, axis=3))
            lkSC = (-np.log(self.tau) + 0.5 * np.log(lam_ / (np.pi * KT)) - self.B(G[..., 0], lam_) / KT)
            l1r = np.logaddexp(0.0, lkLZ - lkSC)
            out = out - l1r[..., None]
        return out, l1r

    def lnj(self, iso, eta, p, mhc):
        out, _ = self.lnjc(iso, eta, p, mhc)
        return logsumexp(out, axis=(1, 2, 3))

    def alpha(self, iso, eta, p, mhc, h=1e-3):
        eta = np.atleast_1d(np.asarray(eta, float))
        return KT * (self.lnj(iso, eta + h, p, mhc) - self.lnj(iso, eta - h, p, mhc)) / (2 * h)


def residuals(MB, x, names, mhc):
    p = dict(P_BASE)
    p.update(dict(zip(names, map(float, x))))
    r = []
    for iso in "HD":
        e, a = OBS[(iso, "alk")]
        r.extend(MB.alpha(iso, e, p, mhc) - np.array(a))
    return np.array(r)


def fit(MB, nstart=16, seed=0, warm=None, max_nfev=300):
    names = ["dE0_alk", "f0_alk", "f1_alk"]
    lo = np.array([BND[n.split("_")[0]][0] for n in names])
    hi = np.array([BND[n.split("_")[0]][1] for n in names])
    mhc = get_mhc(P_BASE["lam"])
    rng = np.random.default_rng(seed)
    starts = [lo + (hi - lo) * rng.random(3) for _ in range(nstart)]
    for w in (warm or []) + [P_BASE]:
        starts.append(np.clip(np.array([w[n] for n in names]), lo + 1e-9, hi - 1e-9))
    best, costs = None, []
    for x0 in starts:
        try:
            s = least_squares(lambda x: residuals(MB, x, names, mhc), x0, bounds=(lo, hi), x_scale="jac",
                              max_nfev=max_nfev)
        except Exception:
            continue
        costs.append(s.cost)
        if best is None or s.cost < best.cost:
            best = s
    p = dict(P_BASE)
    p.update(dict(zip(names, map(float, best.x))))
    rms_best = np.sqrt(2 * best.cost / 12)
    nconv = int(sum(np.sqrt(2 * c / 12) <= rms_best + 5e-4 for c in costs))
    return p, best, nconv, len(costs)


def features(MB, p):
    mhc = get_mhc(p["lam"])
    out = {}
    g = np.linspace(*WIN_NEW, 41)
    aw = {}
    for iso in "HD":
        aw[iso] = KT * np.polyfit(g, MB.lnj(iso, g, p, mhc), 1)[0]
    out["dA"] = float(aw["H"] - aw["D"])
    lh, ld = MB.lnj("H", ENDS, p, mhc), MB.lnj("D", ENDS, p, mhc)
    out["logK"] = [float(v) for v in (lh - ld) / np.log(10)]
    out["K"] = [float(10 ** v) for v in out["logK"]]
    out["ratio_to_meas"] = [float(10 ** (a - b)) for a, b in zip(out["logK"], LOGK_OBS)]
    res, rms = {}, {}
    rss = 0.0
    for iso in "HD":
        e, a = OBS[(iso, "alk")]
        am = MB.alpha(iso, e, p, mhc)
        res[iso] = [round(float(v), 4) for v in am]
        rms[iso] = float(np.sqrt(np.mean((am - np.array(a)) ** 2)))
        rss += float(((am - np.array(a)) ** 2).sum())
        out["c2_" + iso] = float(np.polyfit(e, am, 2)[0])
    out["alpha_model"], out["rms"], out["RSS"] = res, rms, rss
    out["AICc"], out["BIC"] = info(rss, 12, 3)
    # current composition at the window ends
    comp = {}
    for iso in "HD":
        lc, l1r = MB.lnjc(iso, ENDS, p, mhc)
        w = np.exp(lc - logsumexp(lc, axis=(1, 2, 3), keepdims=True))
        nm, nn = w.shape[2], w.shape[3]
        B = GEO["B_" + iso][:, :nm, :nn]
        obv = GEO["obv_" + iso][:, :nm, :nn]
        cc = dict(dmean=[float((w[i].sum((1, 2)) * MB.d).sum()) for i in range(2)],
                  mu_shares=[[float(v) for v in w[i].sum((0, 2))] for i in range(2)],
                  overbarrier_def1=[float(w[i][B <= 0].sum()) for i in range(2)],
                  overbarrier_adiab_v=[float(w[i][obv].sum()) for i in range(2)])
        if l1r is not None:
            r = np.expm1(l1r)                                   # (2, nd, nmu)
            wm = w.sum(3)
            cc["share_r_gt1"] = [float(wm[i][r[i] > 1].sum()) for i in range(2)]
            cc["share_r_gt01"] = [float(wm[i][r[i] > 0.1].sum()) for i in range(2)]
            # current lost relative to the uncorrected weights at the same parameters
            cc["mean_factor"] = [float(np.exp(logsumexp(lc[i]) - logsumexp(lc[i] + l1r[i][..., None])))
                                 for i in range(2)]
        comp[iso] = cc
    out["comp"] = comp
    return out


VARIANTS = [
    # tag, kwargs
    ("M0 (mu<=2, nu<=7)", dict(mu_max=3, nu_max=8)),
    ("M0 (mu<=3, nu<=9)", dict(mu_max=4, nu_max=10)),
    ("GS (b)", dict(mu_max=4, nu_max=10, gs=True)),
    ("Lam b 0.46 ps", dict(mu_max=4, nu_max=10, lam=True, reading="b", tau=0.46e-12)),
    ("Lam b 4.6 ps", dict(mu_max=4, nu_max=10, lam=True, reading="b", tau=4.6e-12)),
    ("GS + Lam b 4.6 ps", dict(mu_max=4, nu_max=10, gs=True, lam=True, reading="b", tau=4.6e-12)),
    ("Lam v 0.46 ps", dict(mu_max=4, nu_max=10, lam=True, reading="v", tau=0.46e-12)),
    ("Lam v 4.6 ps", dict(mu_max=4, nu_max=10, lam=True, reading="v", tau=4.6e-12)),
    ("Lam v 0.46 ps, thermal e-", dict(mu_max=4, nu_max=10, lam=True, reading="v", tau=0.46e-12, sc="mg")),
    ("Lam v 4.6 ps, thermal e-", dict(mu_max=4, nu_max=10, lam=True, reading="v", tau=4.6e-12, sc="mg")),
    ("Lam b 4.6 ps, thermal e-", dict(mu_max=4, nu_max=10, lam=True, reading="b", tau=4.6e-12, sc="mg")),
]
