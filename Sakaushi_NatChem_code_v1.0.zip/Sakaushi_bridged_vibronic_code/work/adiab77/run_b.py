"""doc 77 (b): refit alkaline alpha (dE0, f0, f1; lambda 0.3 eV fixed) for each variant of bridge.VARIANTS. [fit]"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
import sys
import json
import time
import multiprocessing as mp
import numpy as np

sys.path.insert(0, _PKG + "/work/adiab77")
import bridge as B                                     # noqa: E402

OUT = _PKG + "/work/adiab77/run_b.json"


def one(item):
    i, (tag, kw) = item
    t0 = time.time()
    MB = B.ModelB(**kw)
    p, best, nconv, nst = B.fit(MB, nstart=16, seed=7700 + i)
    f = B.features(MB, p)
    return dict(tag=tag, kw={k: (v if not isinstance(v, float) else float(v)) for k, v in kw.items()},
                p=p, x=[float(v) for v in best.x], nconv=nconv, nstart=nst, sec=round(time.time() - t0, 1), **f)


if __name__ == "__main__":
    items = list(enumerate(B.VARIANTS))
    if len(sys.argv) > 1:
        sel = set(int(s) for s in sys.argv[1].split(","))
        items = [it for it in items if it[0] in sel]
    with mp.Pool(2) as pool:
        res = pool.map(one, items)
    old = json.load(open(OUT)) if os.path.exists(OUT) else []
    keep = {r["tag"]: r for r in old}
    for r in res:
        keep[r["tag"]] = r
        print(f"{r['tag']:28s} rms {r['rms']['H']:.4f}/{r['rms']['D']:.4f} AICc {r['AICc']:.2f} dA {r['dA']:+.4f} "
              f"logK {r['logK'][0]:.3f}/{r['logK'][1]:.3f} (K {r['K'][0]:.1f}/{r['K'][1]:.1f}) "
              f"x {np.round(r['x'], 4)} conv {r['nconv']}/{r['nstart']} {r['sec']} s", flush=True)
    json.dump([keep[t] for t, _ in B.VARIANTS if t in keep], open(OUT, "w"), indent=1)
