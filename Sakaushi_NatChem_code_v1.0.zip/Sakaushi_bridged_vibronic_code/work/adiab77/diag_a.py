"""doc 77 (a): how well does the current bridged fit satisfy the non-adiabatic, localized-proton premise of eq. (3)
at 0.25 V and 0.479 V (and at the alpha points)?  (Requested by the author, 2026-10-01.)

Fit evaluated (not refitted): 'T4|base|alk' (doc 47; recalc_winD.json): omega 2600 cm-1, D_e 119 kcal/mol,
lambda 0.3 eV, delta_D 27.97 meV, dE0 0.6123 eV, f0 0.6048, f1 1.1792 / A, mu <= 2, nu <= 7.  [model]

Electronic coupling, two readings (paper III = Lam et al. JPCC 2020, SI eq S33; doc 04, doc 50):
  bare        V0(R)  = 20 exp[-1.0 (R - 3.0)] kcal/mol            (0.82 eV at d = 0.5 A)
  broadening  Delta0 = V0(R)^2 n_s/(B - A), n_s = 1, B - A = 400 kcal/mol   (0.039 eV at d = 0.5 A)
  R = d + 2.5575 A.

Per channel c = (d, mu, nu) [model; arithmetic on model quantities]
  vibronic coupling, two-state form      Vc = V_el |S_mu,nu|            (V_el = Delta0 or V0)
  vibronic broadening                    Gc = V_el |S_mu,nu|^2
  Landau-Zener electron-proton parameter p = 2 pi V_el^2 / (hbar |dF| v_p)   (doc 04 / doc 50 definition)
  localization (definition 1, doc 04/50) B = max over [x_P, x_R] of min(U_D, U_P + Delta_mu,nu) - eps^R_mu
                                         Delta_mu,nu = eps^R_mu - eps^P_nu (channel at its own resonance)
  adiabatic barrier (definition 2-like)  lower surface E_-(x) with coupling V_el at the channel resonance;
                                         over-barrier if single well or if the barrier height above the
                                         adiabatic reactant-well bottom is below the level's vibrational energy
  Lam 2020 bridging ratio (doc 50 'p3')  r_mu = k_mu^LZ / k_mu^SC,
                                         k^LZ = (pi/hbar) V_el sum_nu |S|^2 F_lambda(dG_mu,nu)
                                         k^SC = (1/tau_L) sqrt(lambda/(pi kT)) exp[-(dG_mu,0 + lambda)^2/(4 lambda kT)]
Current weights: the normalised channel weights of eq. (3) at each eta (ModelX.lnj_alpha(detail=True)).
"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import os
import sys
import json
import numpy as np

sys.path.insert(0, _PKG + "/work/integrated")
sys.path.insert(0, _PKG + "/work/stage3a_R_integral")
sys.path.insert(0, _PKG + "/work/stage1_morse_overlap")
from model_ext import ModelX, get_mhc, DDG_ADS          # noqa: E402
from model import KT, OBS                               # noqa: E402
from proton_potentials import ProtonPotentials          # noqa: E402
from morse_dvr import MASS                               # noqa: E402

EV = 23.060548                       # kcal/mol per eV
HBAR = 6.582119569e-16               # eV s
AMU_EV = 1.66053906660e-27 * 1e-20 / 1.602176634e-19     # amu -> eV s^2 / A^2
KCAL1 = 1.0 / EV                     # 1 kcal/mol in eV
P_FIT = {"lam": 0.3, "dE0_alk": 0.6122836792189001, "f0_alk": 0.604829073287688, "f1_alk": 1.17917539476244}
ETAS = [0.25, 0.30, 0.479]
TAUS = [0.46e-12, 4.6e-12]           # s


def couplings(d):
    R = d + 2.5575
    V0 = 20.0 * np.exp(-1.0 * (R - 3.0)) / EV           # eV
    D0 = (20.0 * np.exp(-1.0 * (R - 3.0))) ** 2 / 400.0 / EV
    return {"b": D0, "v": V0}


def channel_geometry(pot, z, iso, nmu, nnu):
    """Per (d, mu, nu): diabatic barrier B, crossing slope dF, crossing energy U*, adiabatic over-barrier flags."""
    d = z["d"]
    nd = len(d)
    eR, eP = z["eR_" + iso], z["eP_" + iso]
    out = {k: np.full((nd, nmu, nnu), np.nan) for k in ("B", "dF", "Ustar")}
    ob = {r: np.zeros((nd, nmu, nnu), bool) for r in ("b", "v")}
    x = pot.x
    for k in range(nd):
        R = pot.R_of_d(float(d[k]))
        UD = pot.U_reactant(R) / EV
        UP = pot.U_product(R) / EV
        iR, iP = int(np.argmin(UD)), int(np.argmin(UP))
        lo, hi = min(iP, iR), max(iP, iR)
        xs, ud, up = x[lo:hi + 1], UD[lo:hi + 1], UP[lo:hi + 1]
        gD, gP = np.gradient(UD, x)[lo:hi + 1], np.gradient(UP, x)[lo:hi + 1]
        V = couplings(float(d[k]))
        for mu in range(nmu):
            for nu in range(nnu):
                Dl = eR[k, mu] - eP[k, nu]
                env = np.minimum(ud, up + Dl)
                out["B"][k, mu, nu] = env.max() - eR[k, mu]
                g = ud - up - Dl
                s = np.where(np.diff(np.sign(g)) != 0)[0]
                if len(s):
                    j = int(s[0])
                    t = g[j] / (g[j] - g[j + 1])
                    out["Ustar"][k, mu, nu] = ud[j] + t * (ud[j + 1] - ud[j])
                    out["dF"][k, mu, nu] = abs((gD[j] + t * (gD[j + 1] - gD[j])) - (gP[j] + t * (gP[j + 1] - gP[j])))
                    # 2026-10-01 (verification): the grid maximum of the envelope underestimates the barrier by
                    # 0-3 meV; use the crossing interpolated between grid points (U_D linear between them)
                    if len(s) == 1:
                        out["B"][k, mu, nu] = out["Ustar"][k, mu, nu] - eR[k, mu]
                evib = eR[k, mu] - UD[iR]
                for r in ("b", "v"):
                    Vr = V[r]
                    Em = 0.5 * (UD + UP + Dl) - np.sqrt(0.25 * (UD - UP - Dl) ** 2 + Vr ** 2)
                    seg = Em[lo:hi + 1]
                    it = int(np.argmax(seg))
                    if it == 0 or it == len(seg) - 1:
                        ob[r][k, mu, nu] = True          # single well between the diabatic minima
                        continue
                    top = lo + it
                    # reactant side is the larger-x side (iR > iP)
                    rmin = Em[top:].min() if iR > iP else Em[:top + 1].min()
                    ob[r][k, mu, nu] = (Em[top] - rmin) <= evib
    return out, ob


def main():
    pot = ProtonPotentials(n_states=10)
    z = np.load(_PKG + "/work/integrated/levels_ext.npz")
    M = ModelX(delta_D=DDG_ADS)
    mhc = get_mhc(P_FIT["lam"])
    d = M.d
    nmu, nnu = M.ch["H"]["S"].shape[1], M.ch["H"]["S"].shape[2]
    V = couplings(d)
    res = {"settings": dict(p=P_FIT, delta_D=M.delta_D, nmu=nmu, nnu=nnu, kT=KT,
                            V0_d05=float(couplings(0.5)["v"]), D0_d05=float(couplings(0.5)["b"]))}
    eta_all = sorted(set(ETAS + list(OBS[("H", "alk")][0]) + list(OBS[("D", "alk")][0])))
    for iso in "HD":
        geo, ob = channel_geometry(pot, z, iso, nmu, nnu)
        S = np.abs(M.ch[iso]["S"])                                   # (nd, nmu, nnu)
        m = MASS[iso] * AMU_EV
        q = {}
        for r in ("b", "v"):
            Vel = V[r][:, None, None]
            q["Vc_" + r] = Vel * S / KT
            q["Gc_" + r] = Vel * S ** 2 / KT
            vp = np.sqrt(2.0 * np.abs(z["eR_" + iso][:, :nmu, None] - geo["Ustar"]) / m)   # A/s
            q["p_" + r] = 2 * np.pi * Vel ** 2 / (HBAR * geo["dF"] * vp)
            q["ob_" + r] = ob[r]
        B = geo["B"]
        res[iso] = {}
        for eta in eta_all:
            lnj, alpha, w = M.lnj_alpha(iso, "alk", [eta], P_FIT, mhc, detail=True)
            w = w[0]
            G = P_FIT["dE0_alk"] + M.ch[iso]["G"] - M.f_of(P_FIT, "alk")[:, None, None] * eta
            lnF, _ = mhc(G)
            F = np.exp(lnF)
            row = dict(alpha=float(alpha[0]), mu1=float(w[:, 1:, :].sum()), dmean=float((w.sum((1, 2)) * d).sum()))
            for r in ("b", "v"):
                for key in ("Vc_", "Gc_"):
                    a = q[key + r]
                    row[key + r] = dict(lt01=float(w[a < 0.1].sum()), mid=float(w[(a >= 0.1) & (a < 1)].sum()),
                                        ge1=float(w[a >= 1].sum()),
                                        wmed=float(np.interp(0.5, np.cumsum(w.ravel()[np.argsort(a.ravel())]),
                                                             np.sort(a.ravel()))))
                pp = np.nan_to_num(q["p_" + r], nan=np.inf)
                row["p_" + r] = dict(gt01=float(w[pp > 0.1].sum()), gt1=float(w[pp > 1].sum()))
                row["ob_" + r] = float(w[q["ob_" + r]].sum())
                kLZ = (np.pi / HBAR) * V[r][:, None] * (S ** 2 * F).sum(2)          # (nd, nmu), 1/s
                for tau in TAUS:
                    kSC = (1 / tau) * np.sqrt(P_FIT["lam"] / (np.pi * KT)) * \
                        np.exp(-(G[:, :, 0] + P_FIT["lam"]) ** 2 / (4 * P_FIT["lam"] * KT))
                    rr = kLZ / kSC
                    wm = w.sum(2)
                    row[f"r_{r}_{tau*1e12:.2f}"] = dict(gt01=float(wm[rr > 0.1].sum()), gt1=float(wm[rr > 1].sum()))
            row["B"] = dict(le0=float(w[B <= 0].sum()), lt_kT=float(w[(B > 0) & (B < KT)].sum()),
                            lt_kcal=float(w[(B >= KT) & (B < KCAL1)].sum()))
            # channels (mu, nu) summed over d that carry >= 5 % of the current; current-weighted means over d
            top = []
            wmn = w.sum(0)
            for idx in np.argsort(wmn.ravel())[::-1][:6]:
                mu, nu = np.unravel_index(idx, wmn.shape)
                W = wmn[mu, nu]
                if W < 0.05:
                    break
                wd = w[:, mu, nu] / W

                def avg(a):
                    return float((wd * a[:, mu, nu]).sum())
                top.append(dict(mu=int(mu), nu=int(nu), w=float(W), d=float((wd * d).sum()),
                                S=avg(S), Vb=avg(q["Vc_b"]), Vv=avg(q["Vc_v"]), Gb=avg(q["Gc_b"]),
                                pb=avg(np.nan_to_num(q["p_b"], nan=0.0)), B=avg(B),
                                ob_b=float(wd[q["ob_b"][:, mu, nu]].sum()), ob_v=float(wd[q["ob_v"][:, mu, nu]].sum())))
            row["top"] = top
            # Georgievskii-Stuchebrukhov factor phi(p)^2 on the channel rate, p = (doc 04 'p')/(2 pi), reading b
            pg = np.nan_to_num(q["p_b"], nan=0.0) / (2 * np.pi)
            from scipy.special import gammaln
            lphi = np.where(pg > 0, pg * np.log(np.maximum(pg, 1e-300)) - pg - gammaln(pg + 1), 0.0)
            row["gs_mean_factor"] = float((w * np.exp(2 * lphi)).sum())
            row["p_b_doc50conv_gt01"] = float(w[np.nan_to_num(q["p_b"], nan=np.inf) / np.sqrt(10) > 0.1].sum())
            res[iso][f"{eta:.3f}"] = row
    json.dump(res, open(_PKG + "/work/adiab77/diag_a.json", "w"), indent=1)
    return res


def report(res):
    L = []
    s = res["settings"]
    L.append(f"kT = {s['kT']*1000:.2f} meV; d = 0.5 A: V0 = {s['V0_d05']:.3f} eV, Delta0 = {s['D0_d05']:.4f} eV; "
             f"mu <= {s['nmu']-1}, nu <= {s['nnu']-1}")
    for iso in "HD":
        for e in ("0.250", "0.300", "0.479"):
            r = res[iso][e]
            L.append(f"\n{iso} {e} V: alpha {r['alpha']:.3f}, mu>=1 {r['mu1']:.3f}, <d> {r['dmean']:.3f} A")
            for rd, nm in (("b", "broadening Delta0"), ("v", "bare V0")):
                vc, gc = r["Vc_" + rd], r["Gc_" + rd]
                L.append(f"  [{nm}] V|S|/kT: <0.1 {vc['lt01']:.3f}  0.1-1 {vc['mid']:.3f}  >=1 {vc['ge1']:.3f}  "
                         f"(weighted median {vc['wmed']:.3g}) | V|S|^2/kT: <0.1 {gc['lt01']:.3f} 0.1-1 {gc['mid']:.3f} "
                         f">=1 {gc['ge1']:.3f} (median {gc['wmed']:.3g})")
                L.append(f"      LZ p>0.1 {r['p_'+rd]['gt01']:.3f}, p>1 {r['p_'+rd]['gt1']:.3f} | adiabatic over-barrier "
                         f"{r['ob_'+rd]:.3f} | Lam r>0.1/r>1: tau 0.46 ps {r['r_'+rd+'_0.46']['gt01']:.3f}/"
                         f"{r['r_'+rd+'_0.46']['gt1']:.3f}, tau 4.6 ps {r['r_'+rd+'_4.60']['gt01']:.3f}/"
                         f"{r['r_'+rd+'_4.60']['gt1']:.3f}")
            b = r["B"]
            L.append(f"  definition 1: B<=0 {b['le0']:.4f}, 0<B<kT {b['lt_kT']:.4f}, kT<=B<1 kcal/mol {b['lt_kcal']:.4f}")
            L.append(f"  G-S factor on the rate (current-weighted mean, reading b) {r['gs_mean_factor']:.3f}; "
                     f"LZ p>0.1 with the doc 04/50 speed conversion {r['p_b_doc50conv_gt01']:.4f}")
            for t in r["top"]:
                L.append(f"    channel ({t['mu']},{t['nu']}) share {t['w']:.3f} <d> {t['d']:.3f} |S| {t['S']:.3g} "
                         f"Delta0|S|/kT {t['Vb']:.3g} V0|S|/kT {t['Vv']:.3g} Delta0|S|^2/kT {t['Gb']:.2g} "
                         f"p(b) {t['pb']:.3f} B {t['B']*1000:.0f} meV over-barrier share b/v {t['ob_b']:.2f}/{t['ob_v']:.2f}")
    # ranges over the alpha points
    L.append("\nRanges over the alpha points (H 0.29-0.45 V, D 0.28-0.56 V):")
    for iso in "HD":
        ks = [f"{e:.3f}" for e in OBS[(iso, "alk")][0]]
        for key in ("Vc_b", "Vc_v"):
            v = [res[iso][k][key]["ge1"] for k in ks]
            u = [res[iso][k][key]["lt01"] for k in ks]
            L.append(f"  {iso} {key}: >=1 {min(v):.3f}-{max(v):.3f}; <0.1 {min(u):.3f}-{max(u):.3f}")
        v = [res[iso][k]["B"]["le0"] for k in ks]
        L.append(f"  {iso} B<=0 {min(v):.4f}-{max(v):.4f}")
        for rd in "bv":
            v = [res[iso][k]["ob_" + rd] for k in ks]
            L.append(f"  {iso} adiabatic over-barrier ({rd}) {min(v):.3f}-{max(v):.3f}")
    txt = "\n".join(L)
    open(_PKG + "/work/adiab77/diag_a.log", "w").write(txt + "\n")
    print(txt)


if __name__ == "__main__":
    report(main())
