"""Per-channel crossing geometry for all levels in levels_ext.npz (mu, nu <= 9), both isotopes.  [model]

Saved arrays (nd = 133, 10, 10), for iso in H, D:
  B_<iso>      definition-1 barrier: max over [x_P, x_R] of min(U_D, U_P + Delta_mu,nu) - eps^R_mu  [eV]
  dF_<iso>     |U_D'(r*) - U_P'(r*)| at the channel's diabatic crossing r* [eV/A] (NaN if no crossing between wells)
  Ust_<iso>    U_D(r*) [eV]
  obb_<iso>, obv_<iso>   over-barrier on the lower adiabatic surface with V_el = Delta0 (b) or V0 (v)
  pGS_b_<iso>, pGS_v_<iso>  Georgievskii-Stuchebrukhov adiabaticity parameter p = V_el^2/(hbar |dF| v_t),
               v_t = sqrt(2 |eps^R_mu - U_D(r*)| / m)  (doc 04's LZ 'p' is 2 pi times this; doc 04/50 used a speed
               conversion that was sqrt(10) too large, see diag_a check)
"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import sys
import numpy as np

sys.path.insert(0, _PKG + "/work/adiab77")
import diag_a as A                                         # noqa: E402
from proton_potentials import ProtonPotentials             # noqa: E402
from morse_dvr import MASS                                  # noqa: E402

if __name__ == "__main__":
    pot = ProtonPotentials(n_states=10)
    z = np.load(_PKG + "/work/integrated/levels_ext.npz")
    out = {"d": z["d"]}
    V = A.couplings(z["d"])
    for iso in "HD":
        geo, ob = A.channel_geometry(pot, z, iso, 10, 10)
        out["B_" + iso], out["dF_" + iso], out["Ust_" + iso] = geo["B"], geo["dF"], geo["Ustar"]
        out["obb_" + iso], out["obv_" + iso] = ob["b"], ob["v"]
        m = MASS[iso] * A.AMU_EV
        vt = np.sqrt(2.0 * np.abs(z["eR_" + iso][:, :, None] - geo["Ustar"]) / m)
        for r in ("b", "v"):
            out[f"pGS_{r}_{iso}"] = V[r][:, None, None] ** 2 / (A.HBAR * geo["dF"] * vt)
    np.savez(_PKG + "/work/adiab77/geo_full.npz", **out)
    k = int(np.argmin(abs(z["d"] - 0.47)))
    print("H (0,0) d=0.47: pGS_b", out["pGS_b_H"][k, 0, 0], " x 2pi =", 2 * np.pi * out["pGS_b_H"][k, 0, 0])
    print("NaN dF count H/D:", np.isnan(out["dF_H"]).sum(), np.isnan(out["dF_D"]).sum())
