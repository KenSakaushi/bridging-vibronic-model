"""Stage 3a : proton potentials with nonbonding terms, and the R dependence.

Stage 1 used the bonding (Morse) terms only, so the overlaps depended on the
single parameter d_tunn.  The full diabatic potentials of
J. Phys. Chem. C 124, 27309 (2020) SI eq S16 add Buckingham nonbonding terms,

    U_a (r,R) = U_AH^Morse(r,R) + V_AuO(R) + V_AuH(r)
    U_kF(r,R) = U_MH^Morse(r)   + V_AuO(R) + V_OH(R - r)

    V^nb_XY(s) = A_XY exp(-s / r0_XY) - C_XY / s^6            (SI eq S19)

Geometry, with the electrode surface at the origin:
    R      = donor oxygen to electrode        (Au-O pair)
    r      = transferring proton to electrode (Au-H pair, nonbonding in the
             REACTANT state, where H is bonded to O)
    R - r  = proton to donor oxygen           (O-H pair, nonbonding in the
             PRODUCT state, where H is bonded to Au)

Working coordinate is x = r - r_MH, as in stage 1, so the product well sits
near x = 0 and the reactant well near x = d_tunn = R - r_AH - r_MH.

V_AuO(R) is common to both states.  It therefore cancels from dG but survives
in the reactant work term W_a(R), where it supplies the steric penalty that
stops the reaction happening at arbitrarily short distance.

Outputs per R: the ground vibronic energies E_a0(R) and E_kF0(R) (which carry
the zero point energy), the level spacings eps_mu(R), eps_nu(R), and the
overlap matrix S_mu,nu(R).

Units: energy kcal/mol, length Angstrom.
"""

import sys
import os
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "stage1_morse_overlap"))
from morse_dvr import (beta_from_omega, solve_1d, _fix_phase,      # noqa: E402
                       KB_KCAL, hbar2_over_2m)

# Buckingham parameters, SI Table S2 (2020, alkaline)
NB = {"AuO": (10907.0, 0.43, 6453.0),
      "AuH": (100000.0, 0.16, 0.0),
      "OH": (100.0, 0.375, 0.0)}


def buck(s, pair):
    """A exp(-s/r0) - C/s^6, guarded against s -> 0."""
    A, r0, C = NB[pair]
    s = np.maximum(np.asarray(s, dtype=float), 1e-3)
    out = A * np.exp(-s / r0)
    if C:
        out = out - C / s ** 6
    return out


class ProtonPotentials:
    """Reactant and product diabatic proton potentials as functions of R."""

    def __init__(self, D_AH=119.0, w_AH=2600.0, D_MH=52.1, w_MH=1600.0,
                 r_AH=0.9575, r_MH=1.60, n_states=10,
                 x_min=-0.9, x_max=3.2, dx=0.0025, nonbonding=True):
        self.D_AH, self.D_MH = D_AH, D_MH
        self.r_AH, self.r_MH = r_AH, r_MH
        self.beta_AH = beta_from_omega(w_AH, D_AH)
        self.beta_MH = beta_from_omega(w_MH, D_MH)
        self.n_states = n_states
        self.nonbonding = nonbonding
        n = int(round((x_max - x_min) / dx)) + 1
        self.x = np.linspace(x_min, x_min + (n - 1) * dx, n)
        self._cache = {}

    # -- geometry -----------------------------------------------------------
    def d_of_R(self, R):
        return R - self.r_AH - self.r_MH

    def R_of_d(self, d):
        return d + self.r_AH + self.r_MH

    # -- potentials ---------------------------------------------------------
    def U_reactant(self, R):
        """U_a(x; R), the proton bonded to the donor oxygen."""
        d = self.d_of_R(R)
        U = self.D_AH * (1.0 - np.exp(self.beta_AH * (self.x - d))) ** 2
        if self.nonbonding:
            U = U + buck(self.x + self.r_MH, "AuH") + buck(R, "AuO")
        return U

    def U_product(self, R):
        """U_kF(x; R), the proton bonded to the electrode."""
        U = self.D_MH * (1.0 - np.exp(-self.beta_MH * self.x)) ** 2
        if self.nonbonding:
            U = U + buck(R - self.r_MH - self.x, "OH") + buck(R, "AuO")
        return U

    # -- eigenstates --------------------------------------------------------
    def solve(self, iso, R):
        key = (iso, round(float(R), 6))
        if key not in self._cache:
            er, cr = solve_1d(self.x, self.U_reactant(R), iso, self.n_states)
            ep, cp = solve_1d(self.x, self.U_product(R), iso, self.n_states)
            cr = _fix_phase(cr, self.x, -1)
            cp = _fix_phase(cp, self.x, +1)
            self._cache[key] = (er, ep, cr.T @ cp)
        return self._cache[key]

    def E_a0(self, iso, R):
        """Ground vibronic energy of the reactant diabatic state at R."""
        return self.solve(iso, R)[0][0]

    def E_kF0(self, iso, R):
        """Ground vibronic energy of the product diabatic state at R."""
        return self.solve(iso, R)[1][0]

    def levels(self, iso, R):
        er, ep, _ = self.solve(iso, R)
        return er - er[0], ep - ep[0]

    def overlaps(self, iso, R):
        return self.solve(iso, R)[2]

    # -- the R -> infinity reference ---------------------------------------
    def _zpe_free(self, iso, which):
        """Zero point energy of the ISOLATED bond, analytically.

        The R -> infinity reference cannot be taken on the grid: the reactant
        well sits at x = d_tunn = R - r_AH - r_MH, which walks off any fixed
        grid as R grows.  At infinite separation the nonbonding terms vanish
        and the state is a pure Morse oscillator, whose ground level is exact:
            E_0 = hw/2 - (hw)^2/(16 D),   hw = 2 beta sqrt(D hbar^2/2m).
        """
        D = self.D_AH if which == "reac" else self.D_MH
        beta = self.beta_AH if which == "reac" else self.beta_MH
        hw = 2.0 * beta * np.sqrt(D * hbar2_over_2m(iso))
        return 0.5 * hw - hw ** 2 / (16.0 * D)

    def E_a0_inf(self, iso):
        return self._zpe_free(iso, "reac")

    def E_kF0_inf(self, iso):
        return self._zpe_free(iso, "prod")

    # -- work terms ---------------------------------------------------------
    def W_a(self, iso, R, W_solv=0.0):
        """SI eq S28: W_a(R) = E_a0(R) - E_a0(inf) + W^(H2O)2."""
        return self.E_a0(iso, R) - self.E_a0_inf(iso) + W_solv

    def dW_product_minus_reactant(self, iso, R):
        """The R-dependent part of W_kF - W_a (SI eqs S28, S29).

        V_AuO(R) is in both and cancels here; what survives is the difference
        between the O-H repulsion felt by the product and the Au-H repulsion
        felt by the reactant, plus the difference in zero point energy.
        """
        return ((self.E_kF0(iso, R) - self.E_kF0_inf(iso))
                - (self.E_a0(iso, R) - self.E_a0_inf(iso)))
