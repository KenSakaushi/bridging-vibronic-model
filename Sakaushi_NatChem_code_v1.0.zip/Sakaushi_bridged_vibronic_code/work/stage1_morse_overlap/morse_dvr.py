"""
Stage 1 : Morse eigenstates and proton vibrational overlap integrals S_mu,nu(d_tunn)

Model (Lam, Soudackov, Hammes-Schiffer, J. Phys. Chem. C 124, 27309 (2020);
       J. Phys. Chem. C 123, 12335 (2019), eq 14 / SI eqs S16-S18)

The transferring proton moves in one dimension along r, the distance from the
electrode surface.  The reactant (A-H) and product (M-H) diabatic bonding
potentials are a *mirrored* pair of Morse curves:

    U_a(r,R) = D_AH [1 - exp(+beta_AH (r - R + r_AH))]^2      min at r = R - r_AH
    U_F(r)   = D_MH [1 - exp(-beta_MH (r - r_MH))]^2          min at r = r_MH

so that the reactant dissociates as r decreases (H leaves the donor) and the
product dissociates as r increases (H leaves the electrode).

We shift to x = r - r_MH.  Then

    product  minimum at x = 0
    reactant minimum at x = d_tunn,        d_tunn = R - r_AH - r_MH   (eq 49)

and the pair of potentials depends on the single parameter d_tunn:

    U_prod(x) = D_MH [1 - exp(-beta_MH * x)]^2
    U_reac(x) = D_AH [1 - exp(+beta_AH * (x - d_tunn))]^2

Stage 1 uses the bonding (Morse) terms only.  Nonbonding Buckingham terms and
work terms enter at stage 3, where the R integral is done.

Units: energy kcal/mol, length Angstrom, mass amu.
"""

import numpy as np
from scipy.linalg import eigh

# ----------------------------------------------------------------------------
# physical constants (CODATA 2018) and unit conversions
# ----------------------------------------------------------------------------
H_PLANCK = 6.62607015e-34        # J s           (exact)
C_LIGHT = 2.99792458e10          # cm / s        (exact)
N_A = 6.02214076e23              # 1 / mol       (exact)
AMU = 1.66053906660e-27          # kg
KCAL = 4184.0                    # J / kcal      (thermochemical, exact)
KB = 1.380649e-23                # J / K         (exact)

HBAR = H_PLANCK / (2.0 * np.pi)

# 1 cm^-1 expressed in kcal/mol
CM1_TO_KCAL = H_PLANCK * C_LIGHT * N_A / KCAL          # 2.859144e-3
KCAL_TO_CM1 = 1.0 / CM1_TO_KCAL                        # 349.7550
# k_B in kcal/(mol K)
KB_KCAL = KB * N_A / KCAL                              # 1.987204e-3
# hbar^2 / (2 * 1 amu) in kcal/mol * Angstrom^2
HBAR2_2M_AMU = (HBAR ** 2 / (2.0 * AMU)) * 1.0e20 * N_A / KCAL   # 0.0481975

# isotope masses (neutral atom masses; the proton moves between two heavy
# centres so the reduced mass is the bare isotope mass to <0.5%)
MASS = {"H": 1.00782503, "D": 2.01410178, "T": 3.01604928}


def hbar2_over_2m(isotope):
    """hbar^2 / (2 m) in kcal/mol * Angstrom^2."""
    return HBAR2_2M_AMU / MASS[isotope]


# ----------------------------------------------------------------------------
# Morse parameters
# ----------------------------------------------------------------------------
def beta_from_omega(omega_cm1, D_kcal, isotope="H"):
    """Morse range parameter beta [1/Angstrom] from harmonic frequency and D_e.

    For V = D [1 - exp(-beta x)]^2 the harmonic force constant is k = 2 D beta^2
    and hbar*omega = beta * sqrt(4 D * hbar^2/(2m)), hence

        beta = hbar*omega / (2 sqrt(D * hbar^2/(2m)))

    beta characterises the *potential* and is therefore evaluated with the H
    mass regardless of which isotope later moves on it (SI eq S18 uses mu^H).
    """
    hw = omega_cm1 * CM1_TO_KCAL
    return hw / (2.0 * np.sqrt(D_kcal * hbar2_over_2m(isotope)))


def omega_from_beta(beta, D_kcal, isotope):
    """hbar*omega [kcal/mol] for a given isotope moving on a fixed Morse curve."""
    return 2.0 * beta * np.sqrt(D_kcal * hbar2_over_2m(isotope))


def morse_levels_analytic(beta, D_kcal, isotope, n_max=None):
    """Exact Morse eigenvalues measured from the well bottom.

        E_v = hw (v+1/2) - (hw)^2/(4D) (v+1/2)^2 ,   hw = 2 beta sqrt(D hbar^2/2m)

    Returns (energies, hw, wexe, v_max).
    """
    hw = omega_from_beta(beta, D_kcal, isotope)
    wexe = hw ** 2 / (4.0 * D_kcal)
    v_max = int(np.floor(hw / (2.0 * wexe) - 0.5))
    n = v_max + 1 if n_max is None else min(n_max, v_max + 1)
    v = np.arange(n)
    return hw * (v + 0.5) - wexe * (v + 0.5) ** 2, hw, wexe, v_max


# ----------------------------------------------------------------------------
# potentials
# ----------------------------------------------------------------------------
def u_product(x, D_MH, beta_MH):
    """Product (M-H) Morse; minimum at x = 0, dissociates toward +x."""
    return D_MH * (1.0 - np.exp(-beta_MH * x)) ** 2


def u_reactant(x, D_AH, beta_AH, d_tunn):
    """Reactant (A-H) Morse; minimum at x = d_tunn, dissociates toward -x."""
    return D_AH * (1.0 - np.exp(beta_AH * (x - d_tunn))) ** 2


# ----------------------------------------------------------------------------
# Colbert-Miller sinc-DVR on a uniform grid
# ----------------------------------------------------------------------------
def sinc_dvr_kinetic(n, dx, isotope):
    """Kinetic energy matrix of the (-inf, inf) sinc-DVR restricted to n points."""
    pref = hbar2_over_2m(isotope) / dx ** 2
    i = np.arange(n)
    diff = i[:, None] - i[None, :]
    with np.errstate(divide="ignore", invalid="ignore"):
        T = 2.0 / diff ** 2
    T[np.diag_indices(n)] = np.pi ** 2 / 3.0
    T *= (-1.0) ** diff
    return pref * T


def solve_1d(x, v, isotope, n_states=12):
    """Lowest n_states eigenpairs of [-hbar^2/2m d2/dx2 + V] on the sinc-DVR grid.

    Returns (energies [kcal/mol], vectors) where vectors[:, k] are the DVR
    coefficients c_i, normalised as sum_i c_i^2 = 1, i.e. psi(x_i) = c_i/sqrt(dx).
    """
    dx = x[1] - x[0]
    H = sinc_dvr_kinetic(len(x), dx, isotope)
    H[np.diag_indices(len(x))] += v
    w, vec = eigh(H, subset_by_index=(0, n_states - 1))
    return w, vec


def _fix_phase(vec, x, toward, floor=1e-6):
    """Fix the sign of each eigenvector so it is positive in the tail that faces
    the other well.  `toward` is +1 (tail at large x) or -1 (tail at small x).

    The reference point is the OUTERMOST grid point on that side at which the
    amplitude still exceeds `floor` times its maximum.  Taking the extreme edge
    instead would read a value that is pure round-off (|psi| ~ 1e-17 deep in the
    forbidden region), whose sign is random and would flip S_mu,nu arbitrarily
    between isotopes.  |S|^2 is unaffected either way; this only makes the
    signed overlaps meaningful.
    """
    out = vec.copy()
    for k in range(vec.shape[1]):
        col = out[:, k]
        big = np.flatnonzero(np.abs(col) > floor * np.abs(col).max())
        j = big[0] if toward < 0 else big[-1]
        if col[j] < 0:
            out[:, k] *= -1.0
    return out


# ----------------------------------------------------------------------------
# driver: eigenstates + overlaps for one d_tunn
# ----------------------------------------------------------------------------
class MorsePair:
    """Reactant/product Morse pair on a shared sinc-DVR grid."""

    def __init__(self, D_AH, omega_AH, D_MH, omega_MH,
                 x_min=-1.0, x_max=2.8, dx=0.0025, n_states=10):
        self.D_AH, self.D_MH = D_AH, D_MH
        self.omega_AH, self.omega_MH = omega_AH, omega_MH
        self.beta_AH = beta_from_omega(omega_AH, D_AH)
        self.beta_MH = beta_from_omega(omega_MH, D_MH)
        self.n_states = n_states
        n = int(round((x_max - x_min) / dx)) + 1
        self.x = np.linspace(x_min, x_min + (n - 1) * dx, n)
        self.dx = dx
        self._prod_cache = {}

    # -- product states do not depend on d_tunn -----------------------------
    def product_states(self, isotope):
        if isotope not in self._prod_cache:
            v = u_product(self.x, self.D_MH, self.beta_MH)
            e, c = solve_1d(self.x, v, isotope, self.n_states)
            self._prod_cache[isotope] = (e, _fix_phase(c, self.x, +1))
        return self._prod_cache[isotope]

    def reactant_states(self, isotope, d_tunn):
        v = u_reactant(self.x, self.D_AH, self.beta_AH, d_tunn)
        e, c = solve_1d(self.x, v, isotope, self.n_states)
        return e, _fix_phase(c, self.x, -1)

    def overlaps(self, isotope, d_tunn):
        """S[mu, nu] = <chi^reac_mu | chi^prod_nu>, plus the two level sets."""
        e_r, c_r = self.reactant_states(isotope, d_tunn)
        e_p, c_p = self.product_states(isotope)
        return c_r.T @ c_p, e_r, e_p

    # -- bookkeeping --------------------------------------------------------
    def n_bound(self, which, isotope):
        D = self.D_AH if which == "reac" else self.D_MH
        beta = self.beta_AH if which == "reac" else self.beta_MH
        _, _, _, v_max = morse_levels_analytic(beta, D, isotope)
        return v_max + 1
