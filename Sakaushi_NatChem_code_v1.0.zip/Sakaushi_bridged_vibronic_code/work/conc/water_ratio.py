"""Donor concentration ratio c_D/c_H for the alkaline electrolytes (0.1 M KOH in H2O, 0.1 M KOD in D2O), 298 +- 1 K.
Densities: IAPWS-95 (H2O) and IAPWS 2017 heavy water (D2O), 0.101325 MPa, via the iapws package 1.5.5.
Molar masses: IAPWS values (H2O 18.015268, D2O 20.027508 g/mol).
Isotopic composition of the D electrolyte from the reagent specifications in FD2020:
  D2O "100%" (Sigma-Aldrich): >= 99.96 atom% D;  KOD 40 wt% in D2O (CIL DLM-3115): D 97-99 %.
Natural D in Milli-Q water: VSMOW D/H = 155.76 ppm.  [published values -> arithmetic]"""
import numpy as np
from iapws import IAPWS95, D2O

c = 0.1                                   # mol/L of KOH or KOD
phi_V = 5.6                               # apparent molar volume of KOH/KOD at 0.1 M (cm3/mol); range 4-7 tested
M_KOD = 39.0983 + 15.9994 + 2.0141018     # g/mol
x_D_nat = 155.76e-6 / (1 + 155.76e-6)     # atom fraction D in natural water (VSMOW)


def water_conc(rho, M, phi=phi_V):
    """mol/L of water in a 0.1 M solution: (1000 - c*phi)/V_m, V_m = M/rho (cm3/mol); rho in kg/m3 = g/L"""
    Vm = M / (rho / 1000.0)
    return (1000.0 - c * phi) / Vm


def xH_D_electrolyte(xD_D2O, xD_KOD, cw_D):
    """atom fraction of H among exchangeable hydrons in 1 L of 0.1 M KOD made from 40 wt% KOD stock and D2O"""
    m_stock = c * M_KOD / 0.40                       # g of 40 wt% stock
    n_w_stock = 0.60 * m_stock / 20.027508           # mol D2O in the stock
    L_stock = 2 * n_w_stock + c                      # exchangeable hydrons from the stock (water + OD-)
    L_bulk = 2 * (cw_D - n_w_stock)                  # from the added D2O
    H = (1 - xD_KOD) * L_stock + (1 - xD_D2O) * L_bulk
    return H / (L_stock + L_bulk), dict(m_stock=m_stock, n_w_stock=n_w_stock, L_stock=L_stock, L_bulk=L_bulk)


print('T/K    rho_H2O  rho_D2O   [H2O]    [water]_D  ratio(total water)')
res = {}
for T in (297.15, 298.15, 299.15):
    w, d = IAPWS95(T=T, P=0.101325), D2O(T=T, P=0.101325)
    cH, cD = water_conc(w.rho, w.M), water_conc(d.rho, d.M)
    res[T] = (cH, cD)
    print(f'{T:.2f} {w.rho:9.4f} {d.rho:9.4f} {cH:8.4f} {cD:9.4f}   {cD / cH:.6f}')
cH, cD = res[298.15]
print('\npure water (no solute):', f'{997.0476 / 18.015268:.4f}', f'{1104.4681 / 20.027508:.4f}')
for phi in (4.0, 7.0):
    w, d = IAPWS95(T=298.15, P=0.101325), D2O(T=298.15, P=0.101325)
    print(f'phi_V = {phi}: ratio {water_conc(d.rho, d.M, phi) / water_conc(w.rho, w.M, phi):.6f}')
print('phi_V(KOD in D2O) - phi_V(KOH in H2O) = +-1 cm3/mol changes the ratio by', f'{c * 1.0 / 1000:.1e}', '(relative)')

print('\nisotopic composition of the D electrolyte (298.15 K)')
rows = []
for xD_D2O in (0.9996,):
    for xD_KOD in (0.99, 0.98, 0.97):
        xH, info = xH_D_electrolyte(xD_D2O, xD_KOD, cD)
        xD = 1 - xH
        r_bond = (xD * cD) / ((1 - x_D_nat) * cH)                  # O-D donor bonds / O-H donor bonds
        r_mol = (xD ** 2 * cD) / ((1 - x_D_nat) ** 2 * cH)         # [D2O]/[H2O] species
        rows.append((xD_KOD, xH, r_bond, r_mol))
        print(f'  D2O {xD_D2O*100:.2f} atom% D, KOD {xD_KOD*100:.0f} %: x_H = {xH:.2e} ({xD*100:.4f} atom% D); '
              f'c_D/c_H (O-D bonds) = {r_bond:.5f} (log {np.log10(r_bond):+.5f}); [D2O]/[H2O] species = {r_mol:.5f}')
print('  stock for 1 L: %.3f g of 40 wt%% KOD, %.4f mol D2O in it' % (info['m_stock'], info['n_w_stock']))

print('\nH impurity in the D electrolyte: K = R x_D [w]_D / (x_H,nat [w]_H - R x_H [w]_D), R = j_H/j_D')
for xD_KOD, xH, r_bond, _ in rows:
    for R in (18.0, 38.0):
        K = R * (1 - xH) * cD / ((1 - x_D_nat) * cH - R * xH * cD)
        print(f'  KOD {xD_KOD*100:.0f} %: R = {R:.0f} -> K = {K:.3f} ({(K / R - 1) * 100:+.2f} %; '
              f'concentration factor alone {(r_bond - 1) * 100:+.2f} %)')
