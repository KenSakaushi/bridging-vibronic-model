"""Donor concentration ratio c_D/c_H = [D3O+]/[H3O+] for 0.05 M D2SO4 in D2O vs 0.05 M H2SO4 in H2O, 298.15 K.
Species L+, LSO4-, SO4^2- (L = H or D); first dissociation complete, water autoprotolysis negligible.
  K2(H2O): pK = 1.979 (Dickson et al. 1990, as adopted in PHREEQC pitzer.dat); 1.988 (PHREEQC phreeqc.dat) as a check
  K2(D2O): pK(D2O) = pK(H2O) + 0.425 +- 0.076 (molal scale; Yacyshyn, Applegarth, Cox & Tremaine, J. Solution Chem. 2022)
  activity: the same model in both solvents with solvent-specific Debye-Hueckel constants
     A = 1.82483e6 rho^0.5 / (eps T)^1.5,  B = 50.2916 rho^0.5 / (eps T)^0.5   (molal, rho in g/cm3)
     eps(H2O) = 78.408 (IAPWS 1997); eps(D2O) = 77.94 (Vidulich, Evans & Kay 1967)
     rho from IAPWS-95 and IAPWS 2017 heavy water
  model 1: Davies (all ions);  model 2: extended Debye-Hueckel, a(H+) 9, a(HSO4-) 4, a(SO4^2-) 4 A (Kielland)
  solvent mass per litre of solution: w = rho0 (1 - c phi_V/1000), phi_V = 15 +- 5 cm3/mol (cancels in the ratio)
[published values -> arithmetic]"""
import numpy as np
from scipy.optimize import brentq

T = 298.15
SOLV = {"H": dict(rho=0.9970476, eps=78.408), "D": dict(rho=1.1044681, eps=77.94)}
c = 0.05


def AB(s):
    r, e = SOLV[s]["rho"], SOLV[s]["eps"]
    return 1.82483e6 * r ** 0.5 / (e * T) ** 1.5, 50.2916 * r ** 0.5 / (e * T) ** 0.5


def logg(z, I, s, model, a=None):
    A, B = AB(s)
    if model == "davies":
        return -A * z * z * (np.sqrt(I) / (1 + np.sqrt(I)) - 0.3 * I)
    return -A * z * z * np.sqrt(I) / (1 + B * a * np.sqrt(I))


def speciate(s, pK, model="davies", phi_V=15.0):
    w = SOLV[s]["rho"] * (1 - c * phi_V / 1000.0)        # kg solvent per L solution
    mS = c / w
    K = 10 ** (-pK)

    def f(x):
        I = mS + 2 * x
        gL = logg(1, I, s, model, 9.0); gHS = logg(1, I, s, model, 4.0); gS = logg(2, I, s, model, 4.0)
        return np.log10(mS + x) + np.log10(x) - np.log10(mS - x) + gL + gS - gHS + pK
    x = brentq(f, 1e-9, mS * (1 - 1e-9))
    I = mS + 2 * x
    return dict(w=w, mS=mS, mL=mS + x, mLSO4=mS - x, mSO4=x, I=I, cL=(mS + x) * w,
                pL=-(np.log10(mS + x) + logg(1, I, s, model, 9.0)), A=AB(s)[0], B=AB(s)[1])


print("Debye-Hueckel constants (molal): H2O A=%.4f B=%.4f; D2O A=%.4f B=%.4f" % (*AB("H"), *AB("D")))
rows = []
for model in ("davies", "extDH"):
    for pKH in (1.979, 1.988):
        for dpK in (0.425, 0.349, 0.501):
            h = speciate("H", pKH, model)
            d = speciate("D", pKH + dpK, model)
            rows.append((model, pKH, dpK, h, d))
            print(f"{model:6s} pK_H {pKH:.3f} dpK {dpK:.3f}: [H+] {h['cL']:.5f} M (m {h['mL']:.5f}, I {h['I']:.4f}, pH {h['pL']:.3f}) | "
                  f"[D+] {d['cL']:.5f} M (m {d['mL']:.5f}, I {d['I']:.4f}, pD {d['pL']:.3f}) | ratio {d['cL']/h['cL']:.4f}")
# phi_V sensitivity
for phi in (10.0, 20.0):
    h = speciate("H", 1.979, "davies", phi); d = speciate("D", 2.404, "davies", phi)
    print(f"phi_V {phi}: ratio {d['cL']/h['cL']:.5f}")
# eps(D2O) sensitivity
e0 = SOLV["D"]["eps"]
for e in (e0 - 0.5, e0 + 0.5):
    SOLV["D"]["eps"] = e
    h = speciate("H", 1.979); d = speciate("D", 2.404)
    print(f"eps(D2O) {e:.2f}: ratio {d['cL']/h['cL']:.5f}")
SOLV["D"]["eps"] = e0

# isotopic purity of the D electrolyte (D2SO4 96-98 wt% in D2O, 99.5 atom% D; D2O >= 99.96 atom% D)
M_D2SO4 = 2 * 2.0141018 + 32.065 + 4 * 15.9994
cw_D = 1104.4681 * (1 - c * 15 / 1000) / 20.027508          # mol water per L
xs = []
for wt in (0.96, 0.98):
    m_stock = c * M_D2SO4 / wt
    n_w = (1 - wt) * m_stock / 20.027508
    L_stock = 2 * c + 2 * n_w
    L_bulk = 2 * (cw_D - n_w)
    H = 0.005 * L_stock + 0.0004 * L_bulk
    xs.append(H / (L_stock + L_bulk))
xH_w = max(xs); xH_w_min = min(xs)
phi_L3O = 0.69                                                 # fractionation factor of L3O+ vs water (per site)
xH_L3O = xH_w / phi_L3O
xD_nat_L3O = 155.76e-6 * phi_L3O
print(f"\nD electrolyte: x_H(water) = {xH_w_min:.2e}-{xH_w:.2e}; on L3O+ (phi 0.69) x_H = {xH_L3O:.2e}")
h = speciate("H", 1.979); d = speciate("D", 2.404)
r0 = d["cL"] / h["cL"]
r_iso = r0 * (1 - xH_L3O) / (1 - xD_nat_L3O)
print(f"central (Davies, pK 1.979, dpK 0.425): c_D/c_H = {r0:.4f}; with isotopic fractions {r_iso:.4f} (log {np.log10(r_iso):+.4f})")
for R in (0.6, 1.2, 2.9):
    K = R * (1 - xH_L3O) * d["cL"] / ((1 - xD_nat_L3O) * h["cL"] - R * xH_L3O * d["cL"])
    print(f"  R = j_H/j_D = {R}: K = {K:.4f} (K/R = {K/R:.4f}; concentration factor alone {r_iso:.4f})")
