"""Numbers for the text after removing both alkaline instrumental steps (choice A, Ken 2026-10-01).
Only arithmetic on stored values; no model is evaluated.
  measured log K (KOD 98 % D)  : figs/k_fig.json (from data_tab.KIE_ALK, corrected log R) [arith]
  measured Delta alpha          : corrA.json (both steps removed) [fit]
  bridged model log K           : 1.3112 / 1.7070 at 0.25 / 0.479 V (recalc_winD.json, doc 47 fit) [model]
  sensitivity d logK / d delta_D: 0.013445 / 0.012562 per meV (recalc_winD.json) [arith]
  fixed-distance, lambda free   : 2.0691 / 2.5072 (recalc_winD.json) [model]
  VH best                       : 0.1428 / 0.5124 (fit_vh_alk.json, SI v7) [model]
"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import json
import numpy as np

KF = json.load(open(_PKG + '/figs/k_fig.json'))
KB = json.load(open(_PKG + '/figs/k_fig_before_stepA.json'))
CA = json.load(open(_PKG + '/work/stepA/corrA.json'))
R = json.load(open(_PKG + '/work/winD/recalc_winD.json'))

eta = KF['alk']['eta']
m = np.array(KF['alk']['KOD98']['logK'])
mb = np.array(KB['alk']['KOD98']['logK'])
m_unr = np.array(CA['corr']['KOD98']['logK'])
i25, i479 = eta.index(0.25), eta.index(0.479)
out = {}
print('measured log K (k_fig, KOD98): 0.25 V %.4f (unrounded log R %.4f; before %.4f), 0.479 V %.4f (before %.4f)' % (
    m[i25], m_unr[i25], mb[i25], m[i479], mb[i479]))
print('K: %.2f -> %.2f (before %.2f -> %.2f)' % (10 ** m[i25], 10 ** m[i479], 10 ** mb[i25], 10 ** mb[i479]))
print('rise of log K: measured %+.4f (before %+.4f)' % (m[i479] - m[i25], mb[i479] - mb[i25]))
dA = CA['corr']['window']
print('Delta alpha: %.4f (aH %.4f, aD %.4f); as recorded %.4f' % (dA['dA'], dA['aH'], dA['aD'],
                                                                   CA['raw']['window']['dA']))

br = np.array([1.3112, 1.7070])
sens = np.array([0.013445, 0.012562])
dD = 27.97
mm = np.array([m[i25], m[i479]])
print('bridged: rise %+.4f; ratio model/measured %.3f (0.25 V), %.3f (0.479 V)' % (
    br[1] - br[0], 10 ** (br[0] - mm[0]), 10 ** (br[1] - mm[1])))
print('  fraction of measured Delta alpha: %.3f (model 0.1047)' % (0.1047 / dA['dA']))
hi = br + sens * (32 - dD)
lo = br + sens * (0 - dD)
f = np.concatenate([10 ** (hi - mm), 10 ** (mm - lo)])
print('band delta_D 0-32 meV: hi/measured %s, measured/lo %s -> max factor %.4f' % (
    np.round(10 ** (hi - mm), 4), np.round(10 ** (mm - lo), 4), f.max()))
a3 = np.array([2.0691, 2.5072])
print('fixed R, lambda free: ratio %.3f (0.25 V), %.3f (0.479 V); Fig 3d arrow from rounded 2.07: %.2f' % (
    10 ** (a3[0] - mm[0]), 10 ** (a3[1] - mm[1]), 10 ** (2.07 - mm[0])))
b3 = np.array([0.93, 1.22])
print('thermal P(R), lambda free: ratio %.3f, %.3f' % (10 ** (b3[0] - mm[0]), 10 ** (b3[1] - mm[1])))
vh = np.array([0.1428, 0.5124])
print('VH best: measured/model %.3f (0.25 V), %.3f (0.479 V)' % (10 ** (mm[0] - vh[0]), 10 ** (mm[1] - vh[1])))
for nm, v in (('VH dE0>0', (1.2336, 1.7271)), ('VHT -0.95', (1.2598, 1.7185)), ('VHT +0.96', (1.2196, 1.6926))):
    v = np.array(v)
    print('%s: model/measured %.3f, %.3f' % (nm, 10 ** (v[0] - mm[0]), 10 ** (v[1] - mm[1])))
excess = np.array(CA['corr']['KOD97']['excess'] + CA['corr']['KOD99']['excess']) * 100
print('K/R excess (KOD 97-99 %%): %.2f-%.2f %%' % (excess.min(), excess.max()))
