"""Alkaline common window matched to the D file (Ken, 2026-09-30): 0.2496-0.4786 V (was 0.30-0.48 V).

Re-evaluates the window-dependent model quantities of the stored fits (doc 47: results_47.json and
check_3a_interior.json) and refits the bridged lambda profile of doc 50 (omega 2600, delta_D 27.97 meV,
lambda 0.1-1.0 eV), which is not stored in this workspace. Only alpha is fitted (as in doc 47 and doc 50), so the
fits themselves do not depend on the window; the window enters only
  dA    : Delta alpha from straight-line fits of ln j over the window (41 points), as for the data (doc 27)
  lkie  : log(j_H/j_D) at the window ends (the measured K is evaluated at 0.25 and 0.479 V)
  Rstar : current-weighted distance <d> at the window ends
  mu1   : share of the current carried by channels with mu >= 1
Each stored fit is first re-evaluated with the old window and compared with the stored features (check).
Tags: [model] model calculation with fitted parameters, [fit] refit.
"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
import sys
import json
import time
import numpy as np
import multiprocessing as mp

sys.path.insert(0, _PKG + "/work/integrated")
from model_ext import ModelX, get_mhc, run_fit, DDG_ADS          # noqa: E402
from model import KT                                             # noqa: E402

INT = _PKG + "/work/integrated"
OUT = _PKG + "/work/winD/recalc_winD.json"
OLD = dict(win=(0.30, 0.48), ends=[0.30, 0.48])
NEW = dict(win=(0.2496, 0.4786), ends=[0.25, 0.479])
EXTRA = [0.2496, 0.30, 0.48, 0.4786]                 # reference points


def feats(M, p, lam, win, ends):
    mhc = get_mhc(lam)
    a, b = win
    g = np.linspace(a, b, 41)
    aw = {}
    for iso in "HD":
        lj, _ = M.lnj_alpha(iso, "alk", g, p, mhc)
        aw[iso] = KT * np.polyfit(g, lj, 1)[0]
    e = np.array(ends, float)
    lh, ah = M.lnj_alpha("H", "alk", e, p, mhc)
    ld, ad = M.lnj_alpha("D", "alk", e, p, mhc)
    out = dict(dA=float(aw["H"] - aw["D"]), aw=[float(aw["H"]), float(aw["D"])],
               lkie=[float(v) for v in (lh - ld) / np.log(10)],
               alpha_ends={"H": [float(v) for v in ah], "D": [float(v) for v in ad]},
               Rstar={iso: [float(v) for v in M.Rstar(iso, "alk", e, p, mhc)] for iso in "HD"})
    if M.dist != "delta":
        mu1 = {}
        for iso in "HD":
            _, _, w = M.lnj_alpha(iso, "alk", e, p, mhc, detail=True)
            mu1[iso] = [float(v) for v in w[:, :, 1:, :].sum(axis=(1, 2, 3))]
        out["mu1"] = mu1
    return out


def evaluate(r):
    M = ModelX(**r["model"])
    p = dict(r["p"])
    lam = float(r["lam"])
    old = feats(M, p, lam, **OLD)
    new = feats(M, p, lam, **NEW)
    mhc = get_mhc(lam)
    lh, _ = M.lnj_alpha("H", "alk", EXTRA, p, mhc)
    ld, _ = M.lnj_alpha("D", "alk", EXTRA, p, mhc)
    ref = dict(eta=EXTRA, lkie=[float(v) for v in (lh - ld) / np.log(10)])
    chk = None
    if "features" in r and isinstance(r["features"], dict) and "alk" in r["features"]:
        s = r["features"]["alk"]
        chk = dict(dA=abs(old["dA"] - s["dA"]), lkie=max(abs(x - y) for x, y in zip(old["lkie"], s["lkie"])),
                   Rstar=max(abs(x - y) for iso in "HD" for x, y in zip(old["Rstar"][iso], s["Rstar"][iso])))
    return dict(tag=r["tag"], lam=lam, rms=r.get("rms"), p=p, model=r["model"], old=old, new=new, ref=ref,
                check_vs_stored=chk)


# doc 50 table 1 (omega 2600): lambda -> (dE0, f0, f1), rms H / D, Delta alpha, log KIE 0.30 -> 0.48 V
DOC50 = {0.1: ((0.489, 0.618, 1.00), (0.030, 0.034), 0.142, (1.26, 1.67)),
         0.2: ((0.553, 0.611, 1.12), (0.029, 0.038), 0.118, (1.35, 1.70)),
         0.5: ((0.733, 0.599, 1.20), (0.037, 0.046), 0.095, (1.41, 1.70)),
         0.7: ((0.851, 0.597, 1.19), (0.041, 0.049), 0.089, (1.41, 1.68)),
         1.0: ((1.017, 0.599, 1.16), (0.045, 0.053), 0.083, (1.41, 1.66))}


def refit(lam):
    (dE0, f0, f1), _, _, _ = DOC50[lam]
    cfg = dict(tag=f"BR|alk|lam={lam}", model=dict(delta_D=DDG_ADS), meds=["alk"],
               names=["dE0_alk", "f0_alk", "f1_alk"], lam=lam, nstart=16, seed=7000 + int(round(lam * 100)),
               warm=[dict(dE0_alk=dE0, f0_alk=f0, f1_alk=f1)])
    r = run_fit(cfg)
    return r


if __name__ == "__main__":
    t0 = time.time()
    res = json.load(open(os.path.join(INT, "results_47.json")))
    chk = json.load(open(os.path.join(INT, "check_3a_interior.json")))
    keep = [r for r in res if "error" not in r and r["tag"].endswith("alk") or
            ("error" not in r and "|alk|" in r["tag"])]
    keep += [r for r in chk if "|alk|" in r["tag"]]
    out = dict(stored=[], refit=[])
    for r in keep:
        e = evaluate(r)
        out["stored"].append(e)
        c = e["check_vs_stored"]
        print(f"{r['tag']:30s} old dA {e['old']['dA']:+.4f} new dA {e['new']['dA']:+.4f} | lkie old "
              f"{e['old']['lkie'][0]:.3f}->{e['old']['lkie'][1]:.3f} new {e['new']['lkie'][0]:.3f}->"
              f"{e['new']['lkie'][1]:.3f} | check {c}", flush=True)
    json.dump(out, open(OUT, "w"), indent=1)
    with mp.Pool(2) as pool:
        fits = pool.map(refit, sorted(DOC50))
    for r in fits:
        e = evaluate(r)
        e["per"] = {k: v["rms"] for k, v in r["per"].items()}
        e["x"] = r["x"]
        e["at_bound"] = r["at_bound"]
        lam = r["lam"]
        _, rmsHD, dA50, lk50 = DOC50[lam]
        e["doc50"] = dict(rms=rmsHD, dA=dA50, lkie=lk50)
        out["refit"].append(e)
        print(f"refit lam {lam}: x {np.round(r['x'], 3)} rms H/D {e['per']['H-alk']:.3f}/{e['per']['D-alk']:.3f} "
              f"(doc 50 {rmsHD}) | old dA {e['old']['dA']:+.4f} (doc 50 {dA50}) lkie {e['old']['lkie'][0]:.3f}->"
              f"{e['old']['lkie'][1]:.3f} (doc 50 {lk50}) | new dA {e['new']['dA']:+.4f} lkie "
              f"{e['new']['lkie'][0]:.3f}->{e['new']['lkie'][1]:.3f}", flush=True)
    json.dump(out, open(OUT, "w"), indent=1)
    print(f"DONE {time.time() - t0:.0f} s")
