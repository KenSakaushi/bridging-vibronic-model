"""Donor-potential and lambda sensitivity of the bridged model (water donor), re-done for the common window matched to
the D file (0.2496-0.4786 V; Ken, 2026-09-30). The calc 5 / calc 6 files (doc 48, doc 50) are not in this workspace,
so the fits are repeated with model_ext.ModelX on the re-created levels (levels_donor.py) and checked against the
published tables before the new-window values are taken:
  doc 48 table 2a/2b : 15 donor potentials (omega 2600-3700 cm-1 x D_e 100, 119, 125 kcal/mol), lambda 0.3 eV
  doc 50 table 1     : omega 3200 and 3700 (D_e 119), lambda 0.1, 0.2, 0.5, 0.7, 1.0 eV (omega 2600: recalc_winD.py)
Settings as doc 48/50: media-separate (alkaline only), delta_D = 27.97 meV (the D channels are shifted by
delta_D - zero-point shift of that potential), dE0, f0, f1 fitted to alpha only, 16 random starts + a warm start at
the published optimum. W_a(R) of the Boltzmann P(R) uses E_a0(inf) of the same Morse potential (doc 48 sec. 1.3).
Tags: [fit], [model]."""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
import sys
import json
import time
import numpy as np
import multiprocessing as mp

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _PKG + "/work/integrated")
sys.path.insert(0, _PKG + "/work/winD")
from model_ext import ModelX, run_fit, DDG_ADS, EV_KCAL, KT          # noqa: E402
from recalc_winD import feats, OLD, NEW                              # noqa: E402

W = _PKG + "/work"
sys.path.insert(0, os.path.join(W, "stage3a_R_integral"))
sys.path.insert(0, os.path.join(W, "stage1_morse_overlap"))
from proton_potentials import ProtonPotentials                       # noqa: E402

# doc 48 table 2a/2b: (omega, De) -> rms H/D, c2 H/D, dA (0.30-0.48), lkie (0.30, 0.48), (dE0, f0, f1)
DOC48 = {
    (2600, 100): ((0.032, 0.041), (-1.77, -0.11), 0.106, (1.39, 1.71), (0.611, 0.605, 1.19)),
    (2600, 119): ((0.032, 0.042), (-1.77, -0.12), 0.107, (1.39, 1.71), (0.612, 0.605, 1.18)),
    (2600, 125): ((0.032, 0.042), (-1.76, -0.12), 0.107, (1.39, 1.71), (0.613, 0.605, 1.18)),
    (2900, 100): ((0.028, 0.041), (-1.94, -0.03), 0.116, (1.40, 1.74), (0.625, 0.605, 1.11)),
    (2900, 119): ((0.029, 0.042), (-1.91, -0.04), 0.116, (1.40, 1.75), (0.628, 0.604, 1.10)),
    (2900, 125): ((0.029, 0.042), (-1.91, -0.04), 0.116, (1.40, 1.75), (0.628, 0.604, 1.10)),
    (3200, 100): ((0.026, 0.042), (-1.97, 0.07), 0.123, (1.40, 1.77), (0.645, 0.602, 1.04)),
    (3200, 119): ((0.026, 0.042), (-1.93, 0.06), 0.123, (1.40, 1.77), (0.648, 0.601, 1.04)),
    (3200, 125): ((0.026, 0.042), (-1.92, 0.06), 0.123, (1.40, 1.77), (0.649, 0.601, 1.03)),
    (3500, 100): ((0.024, 0.042), (-1.90, 0.17), 0.129, (1.39, 1.78), (0.669, 0.599, 0.98)),
    (3500, 119): ((0.024, 0.043), (-1.86, 0.17), 0.129, (1.39, 1.78), (0.673, 0.598, 0.98)),
    (3500, 125): ((0.024, 0.043), (-1.84, 0.17), 0.128, (1.39, 1.78), (0.674, 0.598, 0.98)),
    (3700, 100): ((0.023, 0.042), (-1.82, 0.24), 0.132, (1.38, 1.78), (0.686, 0.597, 0.95)),
    (3700, 119): ((0.024, 0.043), (-1.77, 0.24), 0.131, (1.38, 1.78), (0.691, 0.596, 0.94)),
    (3700, 125): ((0.024, 0.043), (-1.76, 0.24), 0.131, (1.38, 1.78), (0.692, 0.596, 0.94)),
}
# doc 50 table 1 (D_e 119): (omega, lambda) -> rms H/D, c2 H/D, dA, lkie (0.30, 0.48), (dE0, f0, f1), converged/16
DOC50 = {
    (3200, 0.1): ((0.029, 0.030), (-4.36, 0.34), 0.120, (1.33, 1.68), (0.875, 0.491, 1.05), 4),
    (3200, 0.2): ((0.024, 0.039), (-3.03, 0.40), 0.136, (1.33, 1.73), (0.588, 0.604, 0.95), 13),
    (3200, 0.5): ((0.031, 0.047), (-0.91, -0.08), 0.109, (1.46, 1.78), (0.771, 0.599, 1.10), 14),
    (3200, 0.7): ((0.035, 0.050), (-0.52, -0.09), 0.102, (1.47, 1.78), (0.901, 0.597, 1.12), 10),
    (3200, 1.0): ((0.039, 0.053), (-0.30, -0.08), 0.096, (1.47, 1.76), (1.100, 0.595, 1.11), 11),
    (3700, 0.1): ((0.022, 0.027), (-3.45, 0.24), 0.132, (1.28, 1.67), (0.956, 0.506, 0.97), 2),
    (3700, 0.2): ((0.024, 0.040), (-2.46, 0.67), 0.142, (1.29, 1.71), (0.630, 0.601, 0.84), 10),
    (3700, 0.5): ((0.028, 0.047), (-0.93, -0.02), 0.117, (1.47, 1.83), (0.813, 0.594, 1.04), 14),
    (3700, 0.7): ((0.032, 0.050), (-0.54, -0.06), 0.109, (1.50, 1.83), (0.944, 0.594, 1.07), 12),
    (3700, 1.0): ((0.036, 0.052), (-0.29, -0.06), 0.102, (1.50, 1.81), (1.155, 0.594, 1.07), 11),
}


class ModelD(ModelX):
    """ModelX on the levels of another donor Morse potential; W_a uses E_a0(inf) of that potential."""

    def __init__(self, omega, De, **kw):
        super().__init__(lev=os.path.join(HERE, f"levels_w{omega}_De{De}.npz"), **kw)
        z = np.load(os.path.join(HERE, f"levels_w{omega}_De{De}.npz"))
        pot = ProtonPotentials(D_AH=float(De), w_AH=float(omega))
        self.Wa = {iso: z["eR_" + iso][:, 0] - pot.E_a0_inf(iso) / EV_KCAL for iso in ("H", "D")}
        self.lnPB = {iso: -self.Wa[iso] / KT for iso in ("H", "D")}


def job(args):
    kind, omega, De, lam, warm = args
    M = ModelD(omega, De, delta_D=DDG_ADS)
    cfg = dict(tag=f"{kind}|w={omega}|De={De}|lam={lam}", model=dict(delta_D=DDG_ADS), meds=["alk"],
               names=["dE0_alk", "f0_alk", "f1_alk"], lam=lam, nstart=16,
               seed=9000 + omega // 100 + De + int(round(lam * 100)),
               warm=[dict(dE0_alk=warm[0], f0_alk=warm[1], f1_alk=warm[2])])
    r = run_fit(cfg, M=M)
    old = feats(M, r["p"], lam, **OLD)
    new = feats(M, r["p"], lam, **NEW)
    fa = r["features"]["alk"]
    return dict(kind=kind, omega=omega, De=De, lam=lam, x=r["x"], rmsH=r["per"]["H-alk"]["rms"],
                rmsD=r["per"]["D-alk"]["rms"], c2=(fa["c2_H"], fa["c2_D"]), zpe=M.zpe, old=old, new=new,
                at_bound=r["at_bound"], sec=r["sec"])


if __name__ == "__main__":
    t0 = time.time()
    jobs = [("doc48", w, De, 0.3, v[4]) for (w, De), v in DOC48.items()]
    jobs += [("doc50", w, 119, lam, v[4]) for (w, lam), v in DOC50.items()]
    with mp.Pool(2) as pool:
        res = pool.map(job, jobs)
    out = []
    for r in res:
        if r["kind"] == "doc48":
            ref = DOC48[(r["omega"], r["De"])]
        else:
            ref = DOC50[(r["omega"], r["lam"])]
        r["ref"] = dict(rms=ref[0], c2=ref[1], dA=ref[2], lkie=ref[3], x=ref[4])
        dev = dict(rms=max(abs(r["rmsH"] - ref[0][0]), abs(r["rmsD"] - ref[0][1])),
                   dA=abs(r["old"]["dA"] - ref[2]),
                   lkie=max(abs(r["old"]["lkie"][0] - ref[3][0]), abs(r["old"]["lkie"][1] - ref[3][1])),
                   x=max(abs(a - b) for a, b in zip(r["x"], ref[4])))
        r["dev"] = dev
        out.append(r)
        print(f"{r['kind']} w {r['omega']} De {r['De']} lam {r['lam']}: x {np.round(r['x'], 3)} rms "
              f"{r['rmsH']:.3f}/{r['rmsD']:.3f} c2 {r['c2'][0]:+.2f}/{r['c2'][1]:+.2f} | old dA {r['old']['dA']:+.4f} "
              f"lkie {r['old']['lkie'][0]:.3f}->{r['old']['lkie'][1]:.3f} | ref rms {ref[0]} dA {ref[2]} lkie {ref[3]} "
              f"| dev {({k: round(v, 4) for k, v in dev.items()})} | NEW dA {r['new']['dA']:+.4f} lkie "
              f"{r['new']['lkie'][0]:.3f}->{r['new']['lkie'][1]:.3f}", flush=True)
    json.dump(out, open(os.path.join(HERE, "fit_donor.json"), "w"), indent=1)
    print(f"DONE {time.time() - t0:.0f} s")
