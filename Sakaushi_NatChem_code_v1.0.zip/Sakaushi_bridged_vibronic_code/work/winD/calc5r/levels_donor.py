"""Re-create the donor-potential levels of calc 5 (doc 48), whose files are not in this workspace.

doc 48 sec. 1.3: only the donor O-H Morse is changed, omega = 2600, 2900, 3200, 3500, 3700 cm-1 x
D_e = 100, 119, 125 kcal/mol (15 sets); everything else as levels_ext.npz (Au-H Morse 52.1 kcal/mol,
1600 cm-1, non-bonded terms, Au-O Buckingham, r_OH 0.9575 A, r_AuH 1.60 A, proton grid -0.9 to 3.2 A,
0.0025 A, 10 states, d = 0.00-1.32 A in 0.01 A steps). The product states do not depend on the donor Morse and
are solved once per (isotope, d). Check: (2600, 119) must reproduce levels_ext.npz.
Output: levels_w{omega}_De{De}.npz (d, eR_*, eP_*, S_* in eV, as levels_ext.npz). [model]
"""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
import sys
import time
import numpy as np
import multiprocessing as mp

W = _PKG + "/work"
sys.path.insert(0, os.path.join(W, "stage3a_R_integral"))
sys.path.insert(0, os.path.join(W, "stage1_morse_overlap"))
from proton_potentials import ProtonPotentials          # noqa: E402
from morse_dvr import solve_1d, _fix_phase               # noqa: E402

EV = 23.060548
HERE = os.path.dirname(os.path.abspath(__file__))
OMEGA = [2600, 2900, 3200, 3500, 3700]
DE = [100, 119, 125]
SETS = [(w, De) for w in OMEGA for De in DE]
D = np.round(np.arange(0.0, 1.32 + 0.005, 0.01), 4)
NS = 10


def run_iso(iso):
    pots = {s: ProtonPotentials(D_AH=float(s[1]), w_AH=float(s[0]), n_states=NS) for s in SETS}
    p0 = pots[(2600, 119)]
    out = {s: dict(eR=np.zeros((len(D), NS)), eP=np.zeros((len(D), NS)), S=np.zeros((len(D), NS, NS)))
           for s in SETS}
    t0 = time.time()
    for k, dk in enumerate(D):
        R = p0.R_of_d(float(dk))
        ep, cp = solve_1d(p0.x, p0.U_product(R), iso, NS)          # product: independent of the donor Morse
        cp = _fix_phase(cp, p0.x, +1)
        for s, pot in pots.items():
            er, cr = solve_1d(pot.x, pot.U_reactant(R), iso, NS)
            cr = _fix_phase(cr, pot.x, -1)
            out[s]["eR"][k], out[s]["eP"][k], out[s]["S"][k] = er / EV, ep / EV, cr.T @ cp
        if k % 20 == 0:
            print(f"{iso}: d {dk:.2f} ({k + 1}/{len(D)}) {time.time() - t0:.0f} s", flush=True)
    return iso, out


if __name__ == "__main__":
    t0 = time.time()
    with mp.Pool(2) as pool:
        res = dict(pool.map(run_iso, ["H", "D"]))
    for s in SETS:
        z = {"d": D}
        for iso in "HD":
            z["eR_" + iso], z["eP_" + iso], z["S_" + iso] = res[iso][s]["eR"], res[iso][s]["eP"], res[iso][s]["S"]
        np.savez(os.path.join(HERE, f"levels_w{s[0]}_De{s[1]}.npz"), **z)
    ref = np.load(os.path.join(W, "integrated", "levels_ext.npz"))
    z = np.load(os.path.join(HERE, "levels_w2600_De119.npz"))
    dev = max(float(np.abs(z[k] - ref[k]).max()) for k in ref.files)
    print(f"check (2600, 119) vs levels_ext.npz: max |diff| = {dev:.2e}")
    print(f"DONE {time.time() - t0:.0f} s")
