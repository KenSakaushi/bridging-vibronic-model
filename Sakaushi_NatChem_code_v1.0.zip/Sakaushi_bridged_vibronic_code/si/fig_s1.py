"""Supplementary Fig. 1 (Supplementary Note 1): the Volmer-Heyrovsky mechanism at lambda = 0.3 eV.
Same content as the internal figure of doc 65 (work/vh/fig_vh.py), relabelled for the Supplementary Information:
no internal title, panel labels a-f, full names in the legend. No model is evaluated here.
Numbers: fit_vh_acid_new.json, fit_vh_alk.json, branches_vh.json [fit, model calculation; doc 65];
measured alpha: doc 26/34 (H, acid), doc 58 (D, acid), doc 26/27 (alkali) [fit];
measured log K = log[(j_H/c_H)/(j_D/c_D)]: k_fig.json [arithmetic; doc 61]."""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import sys
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D

sys.path.insert(0, _PKG + '/figs')
from style import C, MM, setup, panel_label  # noqa: E402

setup()
VH = _PKG + '/work/vh/'
A = json.load(open(VH + 'fit_vh_acid_new.json'))
B = json.load(open(VH + 'fit_vh_alk.json'))
BR = json.load(open(VH + 'branches_vh.json'))
KF = json.load(open(_PKG + '/figs/k_fig.json'))
sys.path.insert(0, _PKG + '/work/integrated')
from acid59_model import SETS  # noqa: E402
from model import OBS  # noqa: E402

OBSA = SETS['new']
OBSB = {'H': OBS[('H', 'alk')], 'D': OBS[('D', 'alk')]}
M = '−'   # minus sign

fig = plt.figure(figsize=(183 * MM, 118 * MM))
gs = GridSpec(2, 3, figure=fig, left=0.075, right=0.985, top=0.855, bottom=0.085, wspace=0.40, hspace=0.62)
axs = [[fig.add_subplot(gs[r, c]) for c in range(3)] for r in range(2)]


def tidy(ax, title):
    ax.set_title(title, fontsize=6.8, loc='left', pad=3)
    ax.grid(axis='y', color=C['grid'], lw=0.4)
    ax.set_axisbelow(True)
    ax.set_xlabel(r'$|\eta|$ (V)', labelpad=1.5)


def alpha_panel(ax, obs, fits, xlim, ylim, title):
    for iso in 'HD':
        e, a = obs[iso]
        ax.plot(e, a, ls='none', marker='o', ms=3.6, color=C[iso], mec='white', mew=0.4, zorder=5)
    for feat, ls, lw in fits:
        g = np.array(feat['grid'])
        for iso in 'HD':
            ax.plot(g, feat[iso]['alpha'], color=C[iso], ls=ls, lw=lw, zorder=3)
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.set_ylabel(r'$\alpha$', labelpad=2)
    tidy(ax, title)


def cov_panel(ax, feat, xlim, title):
    g = np.array(feat['grid'])
    for iso in 'HD':
        ax.plot(g, feat[iso]['theta'], color=C[iso], lw=1.2)
        ax.plot(g, feat[iso]['wHy'], color=C[iso], lw=1.0, ls=(0, (1, 1.3)))
    ax.set_xlim(*xlim)
    ax.set_ylim(-0.02, 1.02)
    ax.set_ylabel(r'$\theta$ (solid), $w_{\rm Hy}$ (dotted)', labelpad=2)
    tidy(ax, title)


def logk_panel(ax, meas, fits, xlim, ylim, title):
    e, lk = meas
    ax.plot(e, lk, ls='none', marker='o', ms=3.6, color=C['ink'], mec='white', mew=0.4, zorder=5)
    for feat, ls, lw in fits:
        ax.plot(np.array(feat['grid']), feat['logK'], color=C['bridged'], ls=ls, lw=lw)
    ax.axhline(0, color=C['muted'], lw=0.5, ls=(0, (1.5, 1.5)))
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.set_ylabel(r'log $K$', labelpad=2)
    tidy(ax, title)


LS_VH, LS_V, LS_B = '-', (0, (4, 2)), (0, (1, 1.3))
# ---- hydronium donor (0.05 M H2SO4 / D2SO4, all 23 values)
va, vv = A['vh'], A['volmer']
alpha_panel(axs[0][0], OBSA, [(va['features'], LS_VH, 1.2), (vv['features'], LS_V, 0.9)],
            (0.05, 0.40), (0.30, 0.90), 'Hydronium donor: transfer coefficients')
d_aicc = va['summary']['AICc'] - vv['summary']['AICc']
axs[0][0].text(0.98, 0.97, f"rms: Volmer–Heyrovsky {va['summary']['rms']:.3f}\n"
               f"Volmer only {vv['summary']['rms']:.3f}\n"
               f"$\\Delta$AICc {d_aicc:+.1f}".replace('-', M),
               transform=axs[0][0].transAxes, ha='right', va='top', fontsize=5.8, color=C['ink2'])
cov_panel(axs[0][1], va['features'], (0.05, 0.40), 'Hydronium donor: coverage, rate control')
logk_panel(axs[0][2], (KF['acid']['eta'], KF['acid']['logK']),
           [(va['features'], LS_VH, 1.2), (vv['features'], LS_V, 0.9)], (0.05, 0.40), (-0.4, 1.3),
           'Hydronium donor: isotope effect')
# ---- water donor (0.1 M KOH / KOD)
vb, vbv, vb2 = B['vh'], B['volmer'], BR['alk']
alpha_panel(axs[1][0], OBSB, [(vb2['features'], LS_VH, 1.2), (vb['features'], LS_B, 1.0),
                              (vbv['features'], LS_V, 0.9)],
            (0.20, 0.60), (0.30, 0.70), 'Water donor: transfer coefficients')
txt_b = (f"rms: $\\Delta E_0$ = {vb2['x'][0]:.2f} eV {vb2['summary']['rms']:.3f}\n"
         f"$\\Delta E_0$ = {vb['x'][0]:.2f} eV (bound) {vb['summary']['rms']:.3f}\n"
         f"Volmer only {vbv['summary']['rms']:.3f}").replace('-0.', M + '0.')
axs[1][0].text(0.50, 0.03, txt_b, transform=axs[1][0].transAxes, ha='center', va='bottom', fontsize=5.8,
               color=C['ink2'])
cov_panel(axs[1][1], vb2['features'], (0.20, 0.60), r'Water donor: coverage, rate control ($\Delta E_0$ > 0)')
logk_panel(axs[1][2], (KF['alk']['eta'], KF['alk']['KOD98']['logK']),
           [(vb2['features'], LS_VH, 1.2), (vb['features'], LS_B, 1.0), (vbv['features'], LS_V, 0.9)],
           (0.20, 0.60), (0.0, 2.0), 'Water donor: isotope effect')
for r in range(2):
    for c, lab in enumerate('abc' if r == 0 else 'def'):
        panel_label(axs[r][c], lab, x=-0.20, y=1.03)
hk = [Line2D([], [], ls='none', marker='o', ms=3.6, color=C['ink2'], mec='white'),
      Line2D([], [], color=C['ink2'], lw=1.2), Line2D([], [], color=C['ink2'], lw=1.0, ls=LS_B),
      Line2D([], [], color=C['ink2'], lw=0.9, ls=LS_V),
      Line2D([], [], color=C['H'], lw=1.2), Line2D([], [], color=C['D'], lw=1.2),
      Line2D([], [], color=C['bridged'], lw=1.2)]
fig.legend(hk, ['measured', 'Volmer–Heyrovsky (d–f: $\\Delta E_0$ > 0)',
                'Volmer–Heyrovsky, best fit at bounds (d–f)', 'Volmer only',
                'H', 'D', 'model log $K$'],
           loc='upper center', bbox_to_anchor=(0.53, 0.995), ncol=4, fontsize=6.0, handlelength=2.4,
           columnspacing=1.4)
for ext in ('png', 'pdf'):
    fig.savefig(f'{_PKG}/si/SuppFig1_VH.{ext}', dpi=600 if ext == 'png' else None)
print('ok', round(va['summary']['rms'], 4), round(vv['summary']['rms'], 4), round(d_aicc, 2))
