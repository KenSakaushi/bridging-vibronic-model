"""Supplementary Table 2 (Volmer-Heyrovsky-Tafel fits) from work/vht/summary_vht.json [fit, model calculation;
doc 67 sec. 7]. No model is evaluated. The only arithmetic here is the corrected Akaike information criterion of the
fits with Delta E0 >= 0.35 eV relative to the (unrestricted) Volmer-only fit of the main text,
AICc = n ln(RSS/n) + 2k + 2k(k + 1)/(n - k - 1) with RSS/n = rms^2 [arithmetic]. Writes table2.json for build_si.js."""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import json
import math

S = json.load(open(_PKG + '/work/vht/summary_vht.json'))
M = '−'
N = {'acid_new': 23, 'acid_trim': 21, 'alk': 12}
AICC_V = {}                       # Volmer-only fits of the main text (k = 3), from their rms
RMS_V = {'acid_new': 0.11620701110726013, 'acid_trim': None, 'alk': None}


def aicc(rms, n, k):
    return n * math.log(rms ** 2) + 2 * k + 2 * k * (k + 1) / (n - k - 1)


def get(which, rng, kie):
    hit = [r for r in S if r['which'] == which and r['rng'] == rng and abs(r['kieT'] - kie) < 1e-9]
    assert len(hit) == 1, (which, rng, kie)
    return hit[0]


for w in N:
    AICC_V[w] = aicc(get(w, 'full', 0.0)['ref_rms_V'], N[w], 3)


def num(v, nd, bounds=None):
    s = f'{v:.{nd}f}'
    if s.startswith('-'):
        s = M + s[1:]
    if s in ('−0.000', '−0.00', '−0.0'):
        s = s[1:]
    if bounds is not None:
        lo, hi = bounds
        if abs(v - hi) < 1e-9:
            s += '^{a}'
        elif abs(v - lo) < 1e-9:
            s += '^{b}'
    return s


def rng_txt(vals, nd):
    lo, hi = min(vals), max(vals)
    a, b = num(lo, nd), num(hi, nd)
    return a if a == b else f'{a} to {b}' if lo < 0 else f'{a}–{b}'


def bounds(which, rng):
    return {'dE0': (0.35 if rng == 'r035' else -0.6, 1.2), 'f0': (0.1, 1.0), 'f1': (-2.0, 2.0), 'lrho': (-15, 15),
            'lrhoT': (-15, 15)}


def row(which, rng, kies, label, tafel=True):
    r = get(which, rng, kies[0])
    B = bounds(which, rng)
    x = r['x']
    return [('0.35 to 1.2' if rng == 'r035' else '−0.6 to 1.2'), label,
            f"{num(r['rms'], 3)} / {num(r['rmsH'], 3)} / {num(r['rmsD'], 3)}",
            num(x[0], 3, B['dE0']), num(x[1], 3, B['f0']), num(x[2], 3, B['f1']), num(x[3], 2, B['lrho']),
            (num(x[4], 2, B['lrhoT']) if tafel else '–^{d}'),
            f"{num(r['dAICc_V'], 1).replace('−', '−') if r['dAICc_V'] < 0 else '+' + num(r['dAICc_V'], 1)} / "
            f"{num(r['dAICc_VH'], 1) if r['dAICc_VH'] < 0 else '+' + num(r['dAICc_VH'], 1)}",
            ', '.join(num(v, 2) for v in r['logK'])]


def restricted(which):
    rr = [get(which, 'r035', k) for k in (-0.946, -0.5, 0.0, 0.5, 0.963)]
    n = N[which]
    d = [aicc(r['rms'], n, 5) - AICC_V[which] for r in rr]
    lk = list(zip(*[r['logK'] for r in rr]))
    return ['0.35 to 1.2', '−0.95 to +0.96^{e}',
            f"{rng_txt([r['rms'] for r in rr], 3)} / {rng_txt([r['rmsH'] for r in rr], 3)} / "
            f"{rng_txt([r['rmsD'] for r in rr], 3)}",
            '0.350^{b}', '1.000^{a}', '0.000', rng_txt([r['x'][3] for r in rr], 2), rng_txt([r['x'][4] for r in rr], 2),
            f"+{min(d):.1f} to +{max(d):.1f} / –", ', '.join(rng_txt(v, 2) for v in lk)], d


T = {'blocks': []}
acid_meas = '0.42, 0.02, −0.27'
for which, title in (('acid_new', 'Hydronium donor, all values ({n} = 23); log {K} at 0.13, 0.245 and 0.29 V'),
                     ('acid_trim', 'Hydronium donor, reduced set: without the two lowest-current values of {α}_{D} '
                                   '({n} = 21); log {K} at 0.13, 0.245 and 0.29 V')):
    rows = [row(which, 'full', [-0.946], '−0.95'), row(which, 'full', [-0.5], '−0.5'),
            row(which, 'full', [0.0], '0'), row(which, 'full', [0.5, 0.963], '+0.5, +0.96', tafel=False)]
    # the two rows +0.5 and +0.963 must coincide (Tafel step inactive)
    a, b = get(which, 'full', 0.5), get(which, 'full', 0.963)
    assert abs(a['rms'] - b['rms']) < 1e-4 and max(a['wT_max'] + b['wT_max']) < 2e-3, which
    rr, d = restricted(which)
    rows.append(rr)
    T['blocks'].append({'title': title, 'rows': rows, 'measured': acid_meas, 'dAICc_restricted': d})
rows = [row('alk', 'r035', [-0.946], '−0.95'), row('alk', 'r035', [-0.5, 0.0], '−0.5, 0', tafel=False),
        row('alk', 'r035', [0.5], '+0.5'), row('alk', 'r035', [0.963], '+0.96')]
a, b = get('alk', 'r035', -0.5), get('alk', 'r035', 0.0)
assert abs(a['rms'] - b['rms']) < 1e-6 and max(a['wT_max'] + b['wT_max']) < 1e-3
T['blocks'].append({'title': 'Water donor, Δ{E}_{0} ≥ 0.35 eV ({n} = 12); log {K} at 0.30 and 0.479 V', 'rows': rows,
                    'measured': '1.26, 1.58'})
json.dump(T, open(_PKG + '/si/table2.json', 'w'), ensure_ascii=False, indent=1)
print('Volmer AICc (main text):', {k: round(v, 1) for k, v in AICC_V.items()})
for bl in T['blocks']:
    print(bl['title'])
    for r in bl['rows']:
        print('   ', ' | '.join(r))
    if 'dAICc_restricted' in bl:
        print('    restricted dAICc vs Volmer:', [round(v, 1) for v in bl['dAICc_restricted']])
