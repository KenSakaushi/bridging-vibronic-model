"""Supplementary Fig. 2 (Supplementary Note 2): the Volmer-Heyrovsky-Tafel mechanism at lambda = 0.3 eV.
Same content as the internal figure of doc 67 (work/vht/fig_vht.py), relabelled for the Supplementary Information:
no model is evaluated here.
Rows: hydronium, all 23 values; hydronium, lowest-current D values excluded; water (dE0 >= 0.35 eV branch);
scan over the Tafel KIE and profile over log10 rhoT.
Numbers: out/vht_*.json, out/ref_*.json, out/prof_*.json [fit, model calculation]; fit_vh_*.json (doc 65);
measured alpha [fit; doc 26, 27, 34, 58]; measured log K [arithmetic; k_fig.json]."""
import os as _os_pkg  # package root = the folder that contains the file PACKAGE_ROOT
_PKG = _os_pkg.path.dirname(_os_pkg.path.abspath(__file__))
while not _os_pkg.path.exists(_os_pkg.path.join(_PKG, 'PACKAGE_ROOT')) and _os_pkg.path.dirname(_PKG) != _PKG:
    _PKG = _os_pkg.path.dirname(_PKG)
import sys, json, os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
sys.path.insert(0, _PKG + '/figs')
sys.path.insert(0, _PKG + '/work/vht')
from style import C, MM, setup, panel_label

setup()
OUT = _PKG + '/work/vht/out'
VHD = _PKG + '/work/vh'
KF = json.load(open(_PKG + '/figs/k_fig.json'))
sys.path.insert(0, _PKG + '/work/integrated')
from acid59_model import SETS
from model import OBS
OBSX = {'acid_new': SETS['new'], 'acid_trim': SETS['trim'], 'alk': {'H': OBS[('H', 'alk')], 'D': OBS[('D', 'alk')]}}
KIES = [-0.946, -0.5, 0.0, 0.5, 0.963]
PURP = ['#2e1f7a', '#4a3aa7', '#7a6cc4', '#a99fdc', '#d3cdef']     # one hue, dark (inverse Tafel KIE) -> light
M = '−'


def load(which, rng, kie):
    return json.load(open(f'{OUT}/vht_{which}_{rng}_{kie:+.3f}.json'))


def vh_ref(which, rng):
    if rng == 'full':
        d = json.load(open(f'{VHD}/fit_vh_{which}.json'))
        return d['vh']['features'], d['volmer']['features'], d['vh']['summary']['rms'], d['volmer']['summary']['rms']
    d = json.load(open(f'{OUT}/ref_{which}_{rng}.json'))
    return d['vh']['features'], d['volmer']['features'], d['vh']['summary']['rms'], d['volmer']['summary']['rms']


def tidy(ax, title, xl=r'$|\eta|$ (V)'):
    ax.set_title(title, fontsize=6.6, loc='left', pad=3)
    ax.grid(axis='y', color=C['grid'], lw=0.4); ax.set_axisbelow(True)
    if xl:
        ax.set_xlabel(xl, labelpad=1.5)


fig = plt.figure(figsize=(183 * MM, 205 * MM))
gs = GridSpec(4, 3, figure=fig, left=0.075, right=0.985, top=0.93, bottom=0.05, wspace=0.42, hspace=0.62)
ax = [[fig.add_subplot(gs[r, c]) for c in range(3)] for r in range(4)]
ROWS = [('acid_new', 'full', -0.946, (0.05, 0.40), (0.25, 0.90), (-1.2, 1.4), 'Hydronium, all values'),
        ('acid_trim', 'full', -0.946, (0.05, 0.40), (0.25, 0.90), (-1.2, 1.4), 'Hydronium, reduced set'),
        ('alk', 'r035', 0.963, (0.20, 0.60), (0.30, 0.70), (0.0, 2.0), r'Water, $\Delta E_0 \geq$ 0.35 eV')]
for r, (which, rng, kbest, xlim, ylim, klim, title) in enumerate(ROWS):
    med = 'alk' if which == 'alk' else 'acid'
    d = load(which, rng, kbest)
    fe = d['features']; g = np.array(fe['grid'])
    fvh, fv, rvh, rv = vh_ref(which, rng)
    # alpha
    a0 = ax[r][0]
    for iso in 'HD':
        e, a = OBSX[which][iso]
        a0.plot(e, a, ls='none', marker='o', ms=3.4, color=C[iso], mec='white', mew=0.4, zorder=5)
        a0.plot(g, fe[iso]['alpha'], color=C[iso], lw=1.2, zorder=4)
        a0.plot(fvh['grid'], fvh[iso]['alpha'], color=C[iso], lw=0.9, ls=(0, (1, 1.3)), zorder=3)
        a0.plot(fv['grid'], fv[iso]['alpha'], color=C[iso], lw=0.8, ls=(0, (4, 2)), zorder=2)
    a0.set_xlim(*xlim); a0.set_ylim(*ylim); a0.set_ylabel(r'$\alpha$', labelpad=2)
    x = d['x']
    a0.text(0.98, 0.97, (f"rms: VHT {d['summary']['rms']:.3f}\nVH {rvh:.3f}, Volmer only {rv:.3f}\n"
                         f"$\\Delta E_0$ {x[0]:.2f} eV").replace('-', M),
            transform=a0.transAxes, ha='right', va='top', fontsize=5.5, color=C['ink2'])
    tidy(a0, f'{title}: ' + r'$\alpha$ (log $k_{\rm T}^{\rm H}/k_{\rm T}^{\rm D}$ ' + f'{kbest:+.2f})'.replace('-', M))
    # coverage and Tafel share
    a1 = ax[r][1]
    for iso in 'HD':
        a1.plot(g, fe[iso]['theta'], color=C[iso], lw=1.2)
        a1.plot(g, fe[iso]['wT'], color=C[iso], lw=1.0, ls=(0, (1, 1.3)))
    a1.set_xlim(*xlim); a1.set_ylim(-0.02, 1.02)
    a1.set_ylabel(r'$\theta$ (solid), $w_{\rm T}$ (dotted)', labelpad=2)
    tidy(a1, 'Coverage; H$_2$ fraction via the Tafel step')
    # log K for all Tafel KIE values
    a2 = ax[r][2]
    if med == 'acid':
        em, lm = KF['acid']['eta'], KF['acid']['logK']
    else:
        em, lm = KF['alk']['eta'], KF['alk']['KOD98']['logK']
    for kie, col in zip(KIES, PURP):
        q = load(which, rng, kie)['features']
        a2.plot(q['grid'], q['logK'], color=col, lw=1.1)
    a2.plot(fvh['grid'], fvh['logK'], color=C['ink2'], lw=0.9, ls=(0, (1, 1.3)))
    a2.plot(fv['grid'], fv['logK'], color=C['ink2'], lw=0.8, ls=(0, (4, 2)))
    a2.plot(em, lm, ls='none', marker='o', ms=3.4, color=C['ink'], mec='white', mew=0.4, zorder=5)
    a2.axhline(0, color=C['muted'], lw=0.5, ls=(0, (1.5, 1.5)))
    a2.set_xlim(*xlim); a2.set_ylim(*klim); a2.set_ylabel(r'log $K$', labelpad=2)
    tidy(a2, 'Isotope effect for each Tafel step KIE')
# ---- row 4: scan and profile
b0, b1, b2 = ax[3]
for (which, rng, lab, col, mk) in (('acid_new', 'full', 'hydronium, all', C['ink'], 'o'),
                                   ('acid_trim', 'full', 'hydronium, reduced set', C['ink2'], 's'),
                                   ('acid_new', 'r035', r'hydronium, all, $\Delta E_0\geq$0.35 eV', C['muted'], '^'),
                                   ('alk', 'r035', r'water, $\Delta E_0\geq$0.35 eV', C['bridged'], 'D')):
    rr = [load(which, rng, k)['summary']['rms'] for k in KIES]
    b0.plot(KIES, rr, color=col, marker=mk, ms=3.2, lw=1.0, label=lab)
    de = [load(which, rng, k)['x'][0] for k in KIES]
    b2.plot(KIES, de, color=col, marker=mk, ms=3.2, lw=1.0)
b0.set_xlabel(r'log($k_{\rm T}^{\rm H}/k_{\rm T}^{\rm D}$)', labelpad=1.5); b0.set_ylabel('rms of $\\alpha$', labelpad=2)
b0.set_ylim(0.0, 0.25)
b0.legend(fontsize=5.3, loc='upper left', handlelength=1.8, borderaxespad=0.2, ncol=1)
tidy(b0, 'Fit quality against the Tafel step KIE', xl=None)
b2.axhline(0.45, color=C['D'], lw=0.8, ls=(0, (3, 2)))
b2.text(0.97, 0.47, 'Au(111), computed', color=C['D'], fontsize=5.5, ha='right', va='bottom', transform=b2.get_yaxis_transform())
b2.set_xlabel(r'log($k_{\rm T}^{\rm H}/k_{\rm T}^{\rm D}$)', labelpad=1.5); b2.set_ylabel(r'fitted $\Delta E_0$ (eV)', labelpad=2)
b2.set_ylim(-0.7, 0.8)
tidy(b2, r'Fitted $\Delta E_0$', xl=None)
for (which, rng, kie, col, lab) in (('acid_new', 'full', -0.946, C['ink'], f'hydronium, all, {M}0.95'),
                                    ('acid_new', 'full', 0.0, C['ink'], 'hydronium, all, 0'),
                                    ('acid_trim', 'full', -0.946, C['ink2'], f'hydronium, reduced, {M}0.95'),
                                    ('acid_trim', 'full', 0.0, C['ink2'], 'hydronium, reduced, 0'),
                                    ('alk', 'r035', 0.963, C['bridged'], 'water, +0.96')):
    f = f'{OUT}/prof_{which}_{rng}_{kie:+.3f}.json'
    if not os.path.exists(f):
        continue
    P = json.load(open(f))
    xs = [q['lrhoT'] for q in P['rows']]; ys = [q['rms'] for q in P['rows']]
    b1.plot(xs, ys, color=col, lw=1.0, ls='-' if kie != 0.0 else (0, (3, 1.5)), marker='o', ms=2.4, label=lab)
b1.set_xlabel(r'log$_{10}\rho_{\rm T}$ (fixed)', labelpad=1.5); b1.set_ylabel('rms of $\\alpha$', labelpad=2)
b1.set_ylim(0.0, 0.21)
b1.legend(fontsize=5.0, loc='upper left', handlelength=2.0, borderaxespad=0.2)
tidy(b1, 'Profile over the Tafel rate constant', xl=None)
labs = 'abcdefghijkl'
for i in range(4):
    for j in range(3):
        panel_label(ax[i][j], labs[3 * i + j], x=-0.20, y=1.04)
hk = [Line2D([], [], ls='none', marker='o', ms=3.4, color=C['ink2'], mec='white'),
      Line2D([], [], color=C['ink2'], lw=1.2), Line2D([], [], color=C['ink2'], lw=0.9, ls=(0, (1, 1.3))),
      Line2D([], [], color=C['ink2'], lw=0.8, ls=(0, (4, 2))), Line2D([], [], color=C['H'], lw=1.2),
      Line2D([], [], color=C['D'], lw=1.2)] + [Line2D([], [], color=c, lw=1.2) for c in PURP]
fig.legend(hk, ['measured', 'Volmer–Heyrovsky–Tafel (VHT)', 'Volmer–Heyrovsky (VH)', 'Volmer only', 'H', 'D']
           + [r'log $k_{\rm T}^{\rm H}/k_{\rm T}^{\rm D}$ ' + f'{k:+.2f}'.replace('-', M) for k in KIES],
           loc='upper center', bbox_to_anchor=(0.53, 0.995), ncol=6, fontsize=5.6, handlelength=2.2, columnspacing=1.1)
for ext in ('png', 'pdf'):
    fig.savefig(f'{_PKG}/si/SuppFig2_VHT.{ext}', dpi=600 if ext == 'png' else None)
print('ok')
