# Where each number comes from

Paths are relative to the package root. `file → key` gives the stored output and the key that holds the number. In `results_47.json` and `recalc_winD.json`, the entries are lists; `[tag = …]` selects the entry with that tag. "Processing of the measured data" marks values obtained by scripts that are not included, because they need the measured current–potential data (README §6); their results are stored in the files listed. Numbers are given as stored, followed by the value printed in the article.

## 1. Measured quantities (processed inputs)

| Quantity (where in the article) | Produced by | Stored in | Stored → printed |
|---|---|---|---|
| K(η), acid: 2.6 at 0.13 V, 0.53 at 0.29 V (Abstract, Results, Fig. 2a) | processing of the measured data (not included) | `figs/k_fig.json → acid.K` (grid `acid.eta`) | 2.6125 → 2.6; 0.5335 → 0.53 |
| K(η), acid: 1.05 at 0.245 V | same | `work/conc/k_fig.log`, `k_apply.log` (text) | 1.0512 → 1.05 |
| K = 1 at 0.248 V (Results) | same | `figs/k_fig.json → acid.K1_cross` | 0.24849 → 0.248 |
| K(η), water: 12 at 0.25 V → 38 at 0.48 V (Abstract, Results, Fig. 2b) | processing of the measured data (not included); `KIE_ALK` in `figs/data_tab.py` is copied from `work/stepA/corrA.json → corr.logR` | `figs/k_fig.json → alk.KOD98.K` | 12.198 → 12; 38.341 → 38 |
| Measured log K, water: 1.09 and 1.58 (Results) | same | `figs/k_fig.json → alk.KOD98.logK` | 1.0863, 1.5837 |
| Local α, alkali (H 0.58–0.62; D 0.47 at 0.44 V → 0.39 at 0.56 V) | processing of the measured data (not included) | `OBS` in `work/integrated/model.py` and `figs/data_tab.py`; `work/stepA/corrA.json → corr.local` | H 0.583–0.624; D 0.466, 0.386 |
| Local α, acid H (0.79 → 0.40 between 0.09 and 0.27 V) | processing of the measured data (not included) | `OBS` (as above); `work/acid59/d1d3.json → fine` | 0.789 → 0.397 |
| Local α, acid D (near 0.73 at 0.17–0.21 V; 0.80 at 0.25 V; 0.35 at 0.35 V) | processing of the measured data (not included) | `figs/acidD_update.json → aD`; `work/acid59/d1d3.json → alpha_D` | 0.732–0.734; 0.805; 0.350 |
| Δα = −0.20, acid, 0.088–0.297 V (Results, Fig. 2c, Fig. 4d) | script not preserved | `work/acid59/window_dalpha.log` (window 0.0875–0.2972 V) | −0.20001 |
| Δα = +0.13 (+0.126), alkali, 0.25–0.479 V, steps removed (Results, Figs. 2c, 3c) | processing of the measured data (not included) | `work/stepA/corrA.json → corr.window.dA`; `steps_window.json → both_removed.dA` | 0.12630 |
| Local slope of αH in acid, −3.6 V⁻¹ (Results, Discussion) | processing of the measured data (not included) | `work/acid59/d1d3.json → adjacent.H_min` | −3.600 |
| −2.78 ± 0.18 V⁻¹ averaged over 0.12–0.248 V (Discussion) | same | `d1d3.json → D1_windows` (H, 0.12–0.248 V) | −2.779 ± 0.184 |
| αD slope −7.8 V⁻¹ at 0.29 V (Results, Discussion) | same | `d1d3.json → D1_sliding` (w = 0.06 V, centre 0.29 V) | −7.809 ± 0.219 |
| D bends "about 0.14 V later and twice as steeply" (Results) | same | `work/acid59/d1d3.log` | 142 mV at α = 0.60; −7.81 / −3.63 = 2.15 |
| Best shift 0.14 V, five times δD, 1.8 times steeper (Methods) | same | `d1d3.json → shift`, `stretch.s` | 140 meV (140/27.97 = 5.0); 1.788 |
| "3 to 20 times faster" (Methods) | arithmetic on `d1d3.log` (log r = 1.23–1.30), no script | — | — |
| Quadratic coefficients of measured α, −2.2 (D) and +3.2 (H) V⁻² (Discussion) | `obs_c2()` in `work/integrated/model.py` (quadratic fit to `OBS`): `cd work/integrated && python3 -c "import model; print(model.obs_c2())"` | not stored | −2.21, +3.17 |
| cD/cH = 0.996, water (Methods) | `work/conc/water_ratio.py` | `work/conc/water_ratio.log` | 0.99594–0.99611 |
| K exceeds jH/jD by 0.2–2% (Methods) | processing of the measured data (not included); printed by `work/stepA/calc_numbers.py` | `work/stepA/corrA.json → corr.KOD97.excess`, `corr.KOD99.excess`; `calc_numbers.log` | 0.20–2.11% |
| cD/cH = 0.895 (0.88–0.91); [H3O+] 0.064 M, [D3O+] 0.058 M (Methods) | `work/conc/acid_ratio.py` | `work/conc/acid_ratio.log` | 0.8953 (0.8789–0.9141); 0.06446, 0.05774 M |
| K = 0.90 jH/jD, acid (Methods) | processing of the measured data (not included) | `work/conc/k_fig.log` | 0.8956–0.8968 |

## 2. Single-theory models (Results "Neither theory alone…", Methods "Single-theory models", Fig. 3)

| Quantity | Produced by | Stored in | Stored → printed |
|---|---|---|---|
| Bond-stretching rms of α, acid 0.11 | `work/fig3b/fit3b_bm.py` | `work/fig3b/fit3b_bm.json → new.rms` | 0.11063 |
| Bond-stretching rms of α, alkali 0.12; window beyond the switch for water | `work/bm2/fit_bm.py` | `work/bm2/bm_fit.json → alk.rms`; `fit_bm.log` | 0.11893 |
| "a third of the measured Δα if the step is kept endergonic" | not included (README §7) | — | — |
| Marcus–Hush–Chidsey, water rms 0.026 | `work/fig3b/fit3b_mhc.py` | `work/fig3b/fit3b_mhc.json → new.per` (H-alk 0.02727, D-alk 0.02434) | pooled over the 12 values: 0.0256 |
| Isotope offset at its bound, −0.20 eV; seven times the thermodynamic value | same | `fit3b_mhc.json → new.p.d_alk` (in `at_bound`) | −0.2000; 0.200/0.02797 = 7.2 |
| Hydronium rms 0.099; λ at its lower bound 0.10 eV | same | `fit3b_mhc.json → new.per` (H-acid 0.06173, D-acid 0.11995), `new.p.lam_acid` | pooled over the 23 values: 0.0989; 0.1000 |
| Fixed-distance and distributed vibronic models, Δα ≤ +0.049 at λ = 0.3–1.0 eV (Fig. 3c) | `work/integrated/run_tasks.py`, `verify_47.py`; re-evaluated by `work/winD/recalc_winD.py` | `work/winD/recalc_winD.json → stored[tag = 'T3\|3a\|alk\|lam=0.3'].new.dA` (largest) | 0.04914 |
| λ free → 0.05 eV (bound) and 0.088 eV | `run_tasks.py` (`refine_free`) | `work/integrated/results_47.json → [tag = 'T3\|3a\|alk\|lam=free'].lam`, `[tag = 'T3\|3b\|alk\|lam=free'].lam` | 0.0500 (at bound); 0.08836 |
| ΔAICc = −0.9 (fixed distance, λ free, against the bridged model) | `run_tasks.py` (`model_ext.info`) | `results_47.json → [tag].ic.alk.AICc` | −70.389 − (−69.504) = −0.885 |
| KIE eight to ten times larger than measured (Fig. 3d) | `recalc_winD.py` | `recalc_winD.json → stored[tag = 'T3\|3a\|alk\|lam=free'].new.lkie`; measured `figs/k_fig.json → alk.KOD98.logK` | [2.0691, 2.5072] vs [1.0863, 1.5837]: 9.6 and 8.4 |
| Ref. 19 model, αH = 0.59 and αD = 0.57 | published values of ref. 19 (no code) | — | — |

## 3. Bridged model, water (Results, Fig. 4)

| Quantity | Produced by | Stored in | Stored → printed |
|---|---|---|---|
| Fit at λ = 0.3 eV: ΔE0, f0 = 0.605, f1 = 1.18 Å⁻¹ (δD fixed at 27.97 meV) | `work/integrated/run_tasks.py` | `results_47.json → [tag = 'T4\|base\|alk'].p` | 0.61228 eV, 0.60483, 1.17918 |
| rms of α, 0.032 (H) and 0.042 (D) | same | `[tag = 'T4\|base\|alk'].per` | 0.0322, 0.0416 |
| Δα = +0.105 over 0.25–0.479 V | `work/winD/recalc_winD.py` | `recalc_winD.json → stored[tag = 'T4\|base\|alk'].new.dA` | 0.10467 |
| log K = 1.31 (0.25 V) and 1.71 (0.48 V); rise +0.40 | same | `… .new.lkie` | 1.3112, 1.7070; 0.3958 |
| Measured rise +0.50 | — | `figs/k_fig.json → alk.KOD98.logK` | 1.5837 − 1.0863 = 0.4974 |
| Factor 1.33–1.68 against the measurement | `work/stepA/calc_numbers.py` | `work/stepA/calc_numbers.log` | 1.328, 1.678 |
| 0.013 per meV of δD (0.0134 at 0.25 V, 0.0126 at 0.48 V) | arithmetic on `recalc_winD.json → stored[tag = 'T1\|dD=zpe\|alk']` and `[tag = 'T1\|dD=28\|alk']` `.new.lkie`, divided by 28 − 16.19 meV (typed into `calc_numbers.py`) | — | 0.013445, 0.012562 |
| Within a factor of 1.9 for δD = 0–32 meV (Abstract, Results, Conclusion; band in Fig. 4b) | `calc_numbers.py` (log K extrapolated linearly in δD with the sensitivities above; the model was not evaluated at 0 and 32 meV) | `calc_numbers.log` | 1.9014 |
| Ablations, ΔAICc +3.5 (excited states), +7.9 (single distance), +8.4 (f1 = 0) (Fig. 4e) | `run_tasks.py` | `results_47.json → [tag = 'T4\|4a\|alk' / '4b' / '4c'].ic.alk.AICc` against `'T4\|base\|alk'` (−69.504) | −65.992, −61.629, −61.104 |
| Δα without each element: +0.095, +0.049, +0.027 | `recalc_winD.py` | `stored[tag = 'T4\|4a\|alk' / '4b' / '4c'].new.dA` | 0.09492, 0.04914, 0.02729 |
| ⟨d⟩ 0.571 → 0.642 Å (H), 0.485 → 0.543 Å (D) (Fig. 4c) | `recalc_winD.py` | `stored[tag = 'T4\|base\|alk'].new.Rstar` | 0.5711 → 0.6418; 0.4851 → 0.5428 |
| μ ≥ 1 carry 86% of the D current and 48% of the H current at 0.25 V | same | `… .new.mu1` | 0.8635, 0.4833 |

## 4. Bridged model, hydronium (Results, Fig. 4c,d)

| Quantity | Produced by | Stored in | Stored → printed |
|---|---|---|---|
| Fit (f0 at its upper bound) | `work/integrated/f1_59.py` (13-point αD from `figs/acidD_update.json`) | `f1_59.json → new.p`, `new.at_bound` | ΔE0 0.21155 eV, f0 1.0 (bound), f1 0.33077 |
| f at the relevant distances 0.95–0.97 | same | `f1_59.json → new.features.f_at_d` | D 0.948, H 0.970 |
| Model Δα = −0.060 (0.12–0.248 V) | same | `f1_59.json → new.features.dA_old` | −0.06014 |
| Decomposition 58 / 25 / 17 (= 5 + 12)% (Fig. 4d) | `work/integrated/f2_59.py` | `f2_59.json → new.windows['0.12-0.248'].frac` | 0.57705, 0.25524, 0.04769, 0.12002 (rounded to percentages so that the parts sum to 100) |
| Tunnelling distances 0.342 (D) and 0.409 Å (H); effective offset 28 → 41 meV | same | `f2_59.json → new.dD`, `new.dH`, `new.delta_eff` | 0.3419, 0.4089; 40.59 meV |
| Model log K 1.10 → 0.98; no inverse KIE | `f1_59.py` | `f1_59.json → new.features.logK['0.13']`, `['0.245']`, `logK_min`, `K1_cross` | 1.0982 → 0.9800; minimum 0.768; no crossing |
| KIE overestimated five- to sixteenfold (Discussion) | processing of the measured data (not included) (arithmetic on the model log K of `f1_59.json` and the measured log K) | `work/conc/k_apply.log` | 4.82, 9.09, 15.59 |

## 5. General limits (Discussion; Methods "Transfer coefficient and curvature bounds")

| Quantity | Produced by | Stored in | Stored → printed |
|---|---|---|---|
| B(λ) = 2.72, 1.25, 0.45 V⁻¹ at λ = 0.1, 0.3, 1.0 eV (fmax = 1) | `work/acid59/l1_bound.py` | `l1_bound.json → table[].B` | 2.7194, 1.2487, 0.4485 |
| e/4kBT = 9.7 V⁻¹; maximum of kBT\|(ln Fλ)″\| at zero argument | same | `l1_bound.json → table[].fermi_cap`, `table[].x_at_max` | 9.730; ≤ 1 × 10⁻¹³ eV |
| λ ≤ 0.06 eV (−3.6 V⁻¹), ≤ 0.10 eV (window average), ≤ 0.007 eV (D, −7.8 V⁻¹); "nearly threefold" | same | `l1_bound.json → required` | 0.0619, 0.0965, 0.00697; 3.60/1.2487 = 2.88 |
| \|Δα\| at most 0.035 (δD) and 0.051 (effective offset) at λ = 0.3 eV; 0.20 needs λ ≤ 0.010–0.032 eV | same | `l1_bound.json → dalpha[].B03`, `dalpha[].need['0.201']` | 0.0349, 0.0508; 0.0104, 0.0323 |
| Model quadratic coefficients −0.1 (D) and −1.8 (H) V⁻² | `run_tasks.py` | `results_47.json → [tag = 'T4\|base\|alk'].features.alk.c2_D`, `c2_H`; also `work/adiab77/run_b.json → 'M0 (mu<=2, nu<=7)'` | −0.115, −1.765 |
| "all 66 fits": 30 without solvent-dynamical corrections | `work/winD/calc5r/fit_donor.py`; `recalc_winD.py` | `fit_donor.json` (15 entries of kind 'doc48': donor potentials at λ = 0.3 eV; 10 of kind 'doc50': ω = 3200 and 3700 cm⁻¹ at λ = 0.1, 0.2, 0.5, 0.7, 1.0 eV); `recalc_winD.json → refit` (ω = 2600 cm⁻¹, λ = 0.1–1.0 eV) | ordering reversed in every stored fit |
| … and 36 with corrections; β ≈ 0.8–1 | earlier code, not included (README §7) | — | — |
| \|S10/S00\|² ≈ 11 (D) against 8 (H) | `work/integrated/levels.py` | `work/integrated/levels_ext.npz → S_D, S_H` at d = 0.5 Å | 11.3, 7.6 |

## 6. Methods

| Quantity | Produced by | Stored in | Stored → printed |
|---|---|---|---|
| Levels and overlaps by sinc DVR, d = 0–1.32 Å in 0.01 Å steps, μ ≤ 2, ν ≤ 7 | `work/integrated/levels.py`, `prep_boltz.py` | `levels.npz`, `levels_ext.npz` | — |
| Zero-point shift of the D (0,0) driving force at d0, 16.2 meV | `model_ext.py` (`ModelX.zpe`) | `results_47.json → [tag].zpe` | 0.0161876 eV |
| δD = 0.645 kcal mol⁻¹ (27.97 meV); range 0–32 meV | arithmetic from the data of ref. 19, no script (constant `DDG_ADS` in `model_ext.py`) | — | — |
| Mean channel symmetry factor of about 0.77 for D | `work/integrated/verify_47.py` | `verify_47.log` (at 0.30 V) | 0.77 |
| Au–O well 25 meV deep at R = 3.96 Å; < 1.4 × 10⁻⁴ of the current beyond d = 1.0 Å | not regenerated (README §7); Buckingham terms in `work/stage3a_R_integral/proton_potentials.py` | — | — |
| 0.40 eV between the fitted ΔE0 of the two media | `run_tasks.py`, `f1_59.py` | `results_47.json` (0.61228) and `f1_59.json` (0.21155) | 0.4007 |
| 16–48 starting points; f0 ≤ 1, λ ≥ 0.05 eV, distances 0–1.32 Å; identical minima from different starts | `run_tasks.py` (16 or 32 starts plus warm starts), `verify_47.py` (48), `f1_59.py` (32 + 2); bounds `BND` in `model_ext.py` | `run_tasks.log`, `verify_47.log` | — |
| Derivatives at window centres differ from window slopes by < 0.002 | `f1_59.py` | `f1_59.json → new.point_vs_window` (hydronium) | 6.3 × 10⁻⁵ (H), 1.1 × 10⁻⁴ (D) |
| λ grid 0.05–2.0 eV | `model_ext.py` (`LAMGRID`) | — | — |
| Implementation checks to within 10⁻⁵ in α | `work/integrated/limits.py` (narrow P(R); harmonic single channel against the independent implementation `pack/model/ext2.py`); `check_ext.py` | printed only; `check_ext.log` | — |
| 15 donor potentials: Δα = +0.104 to +0.125, log K(0.25 V) = 1.30–1.32 | `work/winD/calc5r/levels_donor.py`, `fit_donor.py` | `fit_donor.json` (entries of kind 'doc48', `new.dA`, `new.lkie`) | 0.1044–0.1249; 1.3020–1.3193 |
| λ = 0.1–1.0 eV: Δα = +0.083 to +0.130, log K(0.25 V) = 1.21–1.43 | `recalc_winD.py` (ω = 2600 cm⁻¹), `fit_donor.py` (3200, 3700 cm⁻¹) | `recalc_winD.json → refit`; `fit_donor.json` (entries of kind 'doc50') | 0.0827–0.1302; 1.2082–1.4252 |
| rms 0.045 (H) and 0.053 (D) at λ = 1.0 eV | `recalc_winD.py` | `recalc_winD.json → refit[tag = 'BR\|alk\|lam=1.0'].per` | 0.0450, 0.0527 |
| Continuum estimate of λ, 1.5–2 eV | estimate, no script | — | — |
| Landau–Zener parameter > 0.1: 27% (D) and 5% (H) of the current at 0.25 V; > 1: < 1% | `work/adiab77/diag_a.py` | `diag_a.json → D['0.250'].p_b.gt01`, `.gt1` (likewise H) | 0.2737, 0.0528; 0.0051, 0.0015 |
| Semiclassical vibronic coupling: log K changes by at most 0.03, rms by < 0.001 | `work/adiab77/geo.py`, `bridge.py`, `run_b.py` | `run_b.json → 'GS (b)'` against `'M0 (mu<=3, nu<=9)'` and `'M0 (mu<=2, nu<=7)'` | ≤ 0.033; ≤ 0.0003 |
| Zusman and solvent-controlled corrections (36 fits) | earlier code, not included (README §7) | — | — |
| D μ = 3 level near ΔE0 + δD | `levels.py` | `levels_ext.npz → eR_D` at d = 0.5 Å | ε3 − ε0 = 0.667 eV vs 0.640 eV |

## 7. Figures

| Figure | Script | Inputs |
|---|---|---|
| Fig. 2 | not included (plots the measured data) | — |
| Fig. 3 | `figs/fig3.py` | numbers in `figs/data_tab.py` (`BM`, `MHC`, `DA_3A`, `DA_3B`, `FREE_3A`, `FREE_3B`, `RMS_3A_ALK`, `RMS_3B_ALK`, `BRIDGED_03`, `BR_DALPHA`, `BR_RMS_HD`, `DALPHA_ALK_MEAS`, `KALK`), copied from `bm_fit.json`/`fit_bm.log`, `fit3b_bm.json`, `fit3b_mhc.json`, `results_47.json`, `recalc_winD.json`, `check_3a_interior.json`, `corrA.json`, `k_fig.json`. `BR_RMS_HD` comes from an earlier refit and differs from `recalc_winD.json → refit` by up to 0.0005 |
| Fig. 4 | `figs/fig4.py` | numbers in `figs/data_tab.py`, copied from `recalc_winD.json`, `results_47.json`, `calc_numbers.log`, `f1_59.json`, `f2_59.json`, `k_fig.json` (`DECOMP_PCT` = 58, 25, 5, 12) |
| Supplementary Fig. 1 | `si/fig_s1.py` | `work/vh/fit_vh_*.json`, `branches_vh.json`, `figs/k_fig.json`, measured α |
| Supplementary Fig. 2 | `si/fig_s2.py` | `work/vht/out/*.json`, `work/vh/fit_vh_*.json`, `figs/k_fig.json`, measured α |

## 8. Supplementary Information

| Quantity | Produced by | Stored in |
|---|---|---|
| Heyrovsky levels and overlaps (H2 constants; β = 2.750 Å⁻¹; 3113 cm⁻¹ for D; −31.34 meV); validation | `work/vh/levels_hy.py`, `validate_vh.py` | `levels_hy.npz`, `levels_hy.json`, `levels_hy.log`, `validate_vh.json` |
| Note 1, hydronium: rms 0.116 → 0.099, ΔAICc −4.4, ΔBIC −4.3 (all values); 0.115 → 0.085, −9.5 (without the two lowest-current values) | `work/vh/fit_vh.py acid_new`, `acid_trim` | `fit_vh_acid_new.json`, `fit_vh_acid_trim.json → volmer`, `vh` (`summary`) |
| Second solutions within 0.001 in rms | `work/vh/branches_vh.py` | `branches_vh.json` |
| Coverage, degree of rate control, steepest slopes, delays, log isotope effects of the steps, K against the measurement | `fit_vh.py` | `fit_vh_*.json → vh.features` (`H.theta`, `H.wHy`, `D.theta`, `steepest`, `cross_levels`, `kie_Hy`, `kie_V`, `logK_vs_meas`) |
| Note 1, water (fit at the bounds, rms, log K 0.14–0.51, the ΔE0 > 0 solution) | `fit_vh.py alk`, `branches_vh.py` | `fit_vh_alk.json`, `branches_vh.json → alk` |
| Note 2 (VHT fits, profiles, restricted fits) | `work/vht/fit_vht.py` (job lists `jobs1–4.txt`), `summarize_vht.py`, `validate_vht.py` | `work/vht/out/*.json`, `summary_vht.json`, `validate_vht.json` |
| Supplementary Table 1 | values transcribed from the files above; measured log K from `work/conc/k_apply.log` | — |
| Supplementary Table 2 | `si/make_table2.py` | `si/table2.json` (hydronium blocks; for the water block see README §7) |
