import numpy as np
kT=0.025693
EPS=np.linspace(-2.5,2.5,401); DE=EPS[1]-EPS[0]; FD=1/(1+np.exp(EPS/kT))
def mhc(dG,lam): return (FD*np.exp(-(lam+dG[...,None]-EPS)**2/(4*lam*kT))).sum(-1)*DE
OBS={('H','alk'):([0.29,0.33,0.37,0.41,0.45],[0.592,0.583,0.587,0.604,0.624]),
     ('D','alk'):([0.28,0.32,0.40,0.44,0.48,0.52,0.56],[0.464,0.475,0.472,0.466,0.437,0.412,0.386]),
     ('H','acid'):([0.09,0.11,0.13,0.15,0.17,0.19,0.21,0.23,0.25,0.27],[0.789,0.753,0.690,0.620,0.548,0.491,0.442,0.413,0.401,0.397]),
     ('D','acid'):([0.16,0.18,0.20,0.22],[0.730,0.737,0.730,0.731])}
def lnj(eta,iso,med,p,NR=41):
    ext=p.get('Rspan',0)>1e-3
    R=np.linspace(0,p['Rspan'],NR) if ext else np.zeros(1)
    f=np.clip(p['f0_'+med]+p.get('f1',0)*R,0,1)
    kap=p.get('kH',0)*(np.sqrt(2) if iso=='D' else 1)
    G=p['G0_'+med]+(p['d_'+med] if iso=='D' else 0)+p.get('g1',0)*R-f*eta[:,None]
    W=-p.get('chi',0)*eta[:,None]*(1-f) if med=='acid' else 0*eta[:,None]
    w=np.exp(-2*kap*R)*np.exp(-W/kT)
    return np.log((w*mhc(G,p['lam_'+med])).sum(1)+1e-300)
def alpha(eta,iso,med,p,h=0.002): return kT*(lnj(eta+h,iso,med,p)-lnj(eta-h,iso,med,p))/(2*h)
def resid(p):
    out=[]
    for (iso,med),(e,a) in OBS.items(): out+=list(alpha(np.array(e),iso,med,p)-np.array(a))
    return np.array(out)
def report(p):
    for (iso,med),(e,a) in OBS.items():
        m=alpha(np.array(e),iso,med,p); r=m-np.array(a)
        print(f"  {iso}-{med:4s} obs "+" ".join("%.2f"%v for v in a)+"\n           mod "+" ".join("%.2f"%v for v in m)+f"  rms {np.sqrt((r**2).mean()):.3f}")
