"""Compare the stored numerical outputs (.json, .npz) of two copies of this package, for example the original and a
copy in which the scripts were re-run.

    python3 tools/compare_outputs.py <reference folder> <re-run folder> [--rtol 1e-6] [--atol 1e-9]

For every .json and .npz file of the reference copy, the file with the same relative path in the re-run copy is
loaded and all numbers are compared. A number differs when |a - b| > atol + rtol * |a|. Text logs are not compared.
"""
import argparse
import json
import math
import os
import sys

import numpy as np


def walk(a, b, path, out, rtol, atol):
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b), key=str):
            if k not in a or k not in b:
                out['structure'].append(f'{path}/{k}: missing in {"re-run" if k in a else "reference"}')
                continue
            walk(a[k], b[k], f'{path}/{k}', out, rtol, atol)
    elif isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        if len(a) != len(b):
            out['structure'].append(f'{path}: length {len(a)} vs {len(b)}')
        for i, (x, y) in enumerate(zip(a, b)):
            walk(x, y, f'{path}[{i}]', out, rtol, atol)
    elif isinstance(a, bool) or isinstance(b, bool) or a is None or b is None or isinstance(a, str) or isinstance(b, str):
        if a != b:
            out['structure'].append(f'{path}: {a!r} vs {b!r}')
    elif isinstance(a, (int, float)) and isinstance(b, (int, float)):
        if math.isnan(a) and math.isnan(b):
            return
        d = abs(a - b)
        out['n'] += 1
        out['max_abs'] = max(out['max_abs'], d)
        if a != 0:
            out['max_rel'] = max(out['max_rel'], d / abs(a))
        if not d <= atol + rtol * abs(a):
            out['differ'].append(f'{path}: {a!r} vs {b!r}')
    else:
        out['structure'].append(f'{path}: types {type(a).__name__} vs {type(b).__name__}')


def load(p):
    if p.endswith('.json'):
        return json.load(open(p))
    z = np.load(p, allow_pickle=False)
    return {k: z[k].tolist() for k in z.files}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('reference')
    ap.add_argument('rerun')
    ap.add_argument('--rtol', type=float, default=1e-6)
    ap.add_argument('--atol', type=float, default=1e-9)
    a = ap.parse_args()
    bad = 0
    for dp, _, files in os.walk(a.reference):
        for f in sorted(files):
            if not f.endswith(('.json', '.npz')):
                continue
            rel = os.path.relpath(os.path.join(dp, f), a.reference)
            q = os.path.join(a.rerun, rel)
            if not os.path.exists(q):
                print(f'MISSING  {rel}')
                bad += 1
                continue
            out = dict(n=0, max_abs=0.0, max_rel=0.0, differ=[], structure=[])
            walk(load(os.path.join(dp, f)), load(q), '', out, a.rtol, a.atol)
            ok = not out['differ'] and not out['structure']
            bad += not ok
            print(f'{"same    " if ok else "DIFFERS "} {rel}: {out["n"]} numbers, max |diff| {out["max_abs"]:.2e}, '
                  f'max rel {out["max_rel"]:.2e}')
            for line in (out['structure'] + out['differ'])[:10]:
                print('         ', line)
    sys.exit(1 if bad else 0)


if __name__ == '__main__':
    main()
